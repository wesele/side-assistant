package com.opencapture.openpocketcine.media

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.opencapture.openpocketcine.OperatorPrefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import com.opencapture.opencine.vocabulary.MediaHTTP
import com.opencapture.opencine.vocabulary.MediaFile
import com.opencapture.opencine.vocabulary.MediaCacheGrade

class MediaCache(
    private val filesDir: File,
    private val prefs: SharedPreferences,
    val root: com.opencapture.opencine.appkit.MonitorMediaCacheRoot =
        com.opencapture.opencine.appkit.MonitorMediaCacheRoot(File(filesDir, "OpenPocketCine/media")),
) {
    private var colorMapCameraId: String? = null
    private var colorMapCache: JSONObject? = null
    private var colorMapGeneration: Long? = null
    fun directory(cameraId: String) = root.directory(cameraId)
    fun cacheRoot(cameraId: String): File = directory(cameraId).root

    fun thumbnailFile(cameraId: String, file: MediaFile): File =
        File(File(cacheRoot(cameraId), "thumbs"), cacheName(file.thumbPath) + ".jpg")

    fun fileCache(cameraId: String, file: MediaFile): File =
        File(File(cacheRoot(cameraId), "files"), cacheName(file.path))

    fun playbackCache(cameraId: String, file: MediaFile, path: String): File {
        if (path == file.path) return fileCache(cameraId, file)
        return File(File(cacheRoot(cameraId), "play"), MediaHTTP.playbackCacheFileName(path))
    }

    fun catalogFile(cameraId: String): File = File(cacheRoot(cameraId), "index.json")

    fun existingFile(file: File): File? {
        if (!file.isFile || file.length() <= 0L) return null
        return file
    }

    fun isDownloaded(file: MediaFile, cameraId: String): Boolean {
        val onDisk = existingFile(fileCache(cameraId, file)) ?: return false
        return isCompleteDownload(onDisk.length(), file.sizeBytes)
    }

    fun localPlaybackFile(file: MediaFile, cameraId: String): File? {
        localProxyFile(file, cameraId)?.let { return it }
        if (isDownloaded(file, cameraId)) return fileCache(cameraId, file)
        return null
    }

    /** 720p LRF/XRF sidecar, never the 4K original. */
    fun localProxyFile(file: MediaFile, cameraId: String): File? {
        for (path in MediaHTTP.proxyPaths(file)) {
            existingFile(playbackCache(cameraId, file, path))?.let { return it }
        }
        return null
    }

    fun isAvailableOffline(file: MediaFile, cameraId: String): Boolean =
        localPlaybackFile(file, cameraId) != null

    fun cacheGrade(file: MediaFile, cameraId: String): MediaCacheGrade =
        MediaCacheGrade.resolve(
            hasOriginal = isDownloaded(file, cameraId),
            hasProxy = localProxyFile(file, cameraId) != null,
        )

    fun colorStoreFile(cameraId: String): File = File(cacheRoot(cameraId), "color.json")

    fun shotColor(path: String, cameraId: String, context: Context? = null): Int {
        migrateLegacyShotColors(cameraId, context)
        val map = loadColorMap(cameraId)
        return map.optInt(path, -1)
    }

    @Synchronized fun rememberShotColor(path: String, colorMode: Int, cameraId: String, expectedGeneration: Long? = null) {
        if (colorMode < 0 || (expectedGeneration != null && directory(cameraId).generation != expectedGeneration)) return
        val map = loadColorMap(cameraId)
        map.put(path, colorMode)
        persistColorMap(map, cameraId, expectedGeneration)
    }

    /** Read-only preparation never migrates or recreates deleted metadata. */
    @Synchronized fun readShotColor(path: String, cameraId: String): Int = loadColorMap(cameraId).optInt(path, -1)

    @Synchronized private fun loadColorMap(cameraId: String): JSONObject {
        val generation = directory(cameraId).generation
        if (colorMapCameraId == cameraId && colorMapGeneration == generation) colorMapCache?.let { return it }
        val dest = colorStoreFile(cameraId)
        val map =
            if (!dest.isFile) JSONObject()
            else runCatching { JSONObject(dest.readText()) }.getOrDefault(JSONObject())
        colorMapCameraId = cameraId
        colorMapCache = map
        colorMapGeneration = generation
        return map
    }

    private fun persistColorMap(map: JSONObject, cameraId: String, expectedGeneration: Long? = null) {
        val directory = directory(cameraId)
        if (expectedGeneration != null && directory.generation != expectedGeneration) return
        val writerGeneration = directory.generation
        if (expectedGeneration != null && writerGeneration != expectedGeneration) return
        directory.write(map.toString().toByteArray(Charsets.UTF_8), "color.json")
        if (directory.generation != writerGeneration) return
        colorMapCameraId = cameraId
        colorMapCache = map
        colorMapGeneration = writerGeneration
    }

    private fun migrateLegacyShotColors(cameraId: String, context: Context?) {
        val ctx = context ?: return
        val raw = OperatorPrefs.legacyClipShotColorJson(ctx) ?: return
        val map = loadColorMap(cameraId)
        val keys = raw.keys()
        while (keys.hasNext()) {
            val path = keys.next()
            if (!map.has(path)) map.put(path, raw.optInt(path, -1))
        }
        persistColorMap(map, cameraId)
        OperatorPrefs.clearLegacyClipShotColor(ctx)
    }

    fun persistCatalog(files: List<MediaFile>, cameraId: String) {
        val dest = catalogFile(cameraId)
        dest.parentFile?.mkdirs()
        dest.writeBytes(encodePocketMediaCatalog(files))
    }

    fun loadCatalog(cameraId: String): List<MediaFile> {
        val dest = catalogFile(cameraId)
        if (!dest.isFile) return emptyList()
        return runCatching { decodePocketMediaCatalog(dest.readBytes()) }.getOrDefault(emptyList())
    }

    fun loadFavorites(cameraId: String): Set<String> {
        val raw = prefs.getString(favoritesKey(cameraId), null) ?: return emptySet()
        return raw.split('\u001f').filter { it.isNotEmpty() }.toSet()
    }

    fun persistFavorites(cameraId: String, favorites: Set<String>) {
        prefs.edit { putString(favoritesKey(cameraId), favorites.sorted().joinToString("\u001f")) }
    }

    fun lastCameraId(): String? = prefs.getString(LAST_CAMERA_KEY, null)

    fun rememberCameraId(cameraId: String) {
        prefs.edit { putString(LAST_CAMERA_KEY, cameraId) }
    }

    fun writeAtomically(data: ByteArray, dest: File) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.parentFile, "${java.util.UUID.randomUUID()}.part")
        tmp.writeBytes(data)
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) {
            tmp.copyTo(dest, overwrite = true)
            tmp.delete()
        }
    }

    companion object {
        private const val LAST_CAMERA_KEY = "opc.media.lastCameraID"

        fun favoritesKey(cameraId: String): String = "opc.media.fav.$cameraId"

        fun cacheName(path: String): String = path.replace("/", "_")

        /** Complete only at the expected length (OpenZCine cache contract). */
        fun isCompleteDownload(onDisk: Long, sizeBytes: Long): Boolean {
            if (onDisk <= 0L) return false
            if (sizeBytes <= 0L) return true
            return onDisk == sizeBytes
        }
    }
}

/** Exact legacy JSON schema/array order; pure bytes reused by the canonical shared cache codec. */
internal fun encodePocketMediaCatalog(files: List<MediaFile>): ByteArray {
    val array = JSONArray()
    files.forEach { array.put(it.toJson()) }
    return array.toString().toByteArray(Charsets.UTF_8)
}

internal fun decodePocketMediaCatalog(bytes: ByteArray): List<MediaFile> {
    val array = JSONArray(bytes.toString(Charsets.UTF_8))
    return buildList(array.length()) {
        for (i in 0 until array.length()) add(MediaFile.fromJson(array.getJSONObject(i)))
    }
}

internal fun MediaFile.toJson(): JSONObject =
    JSONObject().apply {
        put("path", path)
        put("thumbPath", thumbPath)
        put("handle", handle)
        put("cmdHandle", cmdHandle)
        put("sizeBytes", sizeBytes)
        put("durationSeconds", durationSeconds)
        put("isStarred", isStarred)
        if (resolution != null) put("resolution", resolution) else put("resolution", JSONObject.NULL)
        if (fps != null) put("fps", fps) else put("fps", JSONObject.NULL)
        if (proxyPath != null) put("proxyPath", proxyPath) else put("proxyPath", JSONObject.NULL)
        put("storage", storage)
        put("storageKnown", storageKnown)
        put("group", group)
        put("handleShared", handleShared)
    }

internal fun com.opencapture.opencine.vocabulary.MediaFile.Companion.fromJson(obj: JSONObject): MediaFile =
    MediaFile(
        path = obj.optString("path"),
        thumbPath = obj.optString("thumbPath"),
        handle = obj.optLong("handle"),
        cmdHandle = obj.optLong("cmdHandle"),
        sizeBytes = obj.optLong("sizeBytes"),
        durationSeconds = obj.optInt("durationSeconds"),
        isStarred = obj.optBoolean("isStarred"),
        resolution = obj.optStringOrNull("resolution"),
        fps = if (obj.isNull("fps")) null else obj.optInt("fps"),
        proxyPath = obj.optStringOrNull("proxyPath"),
        storage = obj.optInt("storage"),
        storageKnown = obj.optBoolean("storageKnown", false),
        group = obj.optInt("group"),
        handleShared = obj.optBoolean("handleShared"),
    )

private fun JSONObject.optStringOrNull(key: String): String? {
    if (!has(key) || isNull(key)) return null
    val value = optString(key)
    return value.takeIf { it.isNotEmpty() }
}
