# Roadmap

Direction, not dates. Feature ideas belong in
[GitHub Discussions](https://github.com/erik-sutton95/OpenPocketCine/discussions/29).
Issues are for bugs only.

## Now

- BLE → Wi-Fi → DUML spine on iOS
- HEVC (Pocket) / AVC (Nano) live view
- Saved cameras, monitor chrome, GPU assists, media library
- Android Compose shell consuming the Swift core
- Public TestFlight ([join link](https://testflight.apple.com/join/1tmt3aEB))

## Next

- Camera control writes (record, ISO, white balance, tap-to-focus) proven on hardware
- Landing-page screenshots (reviewed, faces blurred)
- Play closed testing (waitlist → `alpha` track) when Android is operator-ready;
  GitHub Actions upload is in-tree (`docs/android-play-ci.md`)

## Later

- Wear OS companion (Apple Watch shipped; Wear follows when Android is operator-ready)
- Anonymous in-app bug reporter
- Dual-platform parity for every operator-visible feature
