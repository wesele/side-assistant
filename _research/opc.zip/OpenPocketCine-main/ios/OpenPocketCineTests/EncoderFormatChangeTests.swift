import OpenCineApple
import OpenPocketViewCore
import XCTest
import OpenCineMedia

@testable import OpenPocketCine

/// This app's `HevcDecoder` (its effects demand, Watch preview and runtime configuration) on
/// parameter-set changes.
@MainActor
final class EncoderFormatChangeTests: XCTestCase {
    func testSameRasterSpsDoesNotHoldIDR() {
        let decoder = HevcDecoder()
        var fired = 0
        decoder.onParameterSetsChanged = { fired += 1 }

        _ = decoder.decode(accessUnit: Self.annexB([Self.vps, Self.sps, Self.pps]))
        XCTAssertEqual(fired, 0)
        XCTAssertTrue(decoder.hasFormat)
        XCTAssertGreaterThan(decoder.pictureSize.width, 1)

        var flippedSPS = Self.sps
        flippedSPS[flippedSPS.count - 1] ^= 0x01
        _ = decoder.decode(accessUnit: Self.annexB([Self.vps, flippedSPS, Self.pps]))
        XCTAssertEqual(
            fired, 0, "same-raster SPS is zoom/FORMAT — not a GOP reset")
        XCTAssertFalse(
            decoder.awaitingIDR,
            "holding IDR without 0x09/0xa8 blacks the well while HUD/gimbal stay up")
    }

    func testIdenticalParameterSetsDoNotRetrigger() {
        let decoder = HevcDecoder()
        var fired = 0
        decoder.onParameterSetsChanged = { fired += 1 }
        let au = Self.annexB([Self.vps, Self.sps, Self.pps])
        _ = decoder.decode(accessUnit: au)
        _ = decoder.decode(accessUnit: au)
        XCTAssertEqual(fired, 0)
    }

    func testNewParameterSetsWithIDRDoNotRequestEnable() {
        let decoder = HevcDecoder()
        var fired = 0
        decoder.onParameterSetsChanged = { fired += 1 }
        _ = decoder.decode(accessUnit: Self.annexB([Self.vps, Self.sps, Self.pps]))

        var flippedSPS = Self.sps
        flippedSPS[flippedSPS.count - 1] ^= 0x01
        // Pocket IDR_N_LP (type 20) — the camera already cut this GOP.
        let idr: [UInt8] = [0x28, 0x01]
        _ = decoder.decode(accessUnit: Self.annexB([Self.vps, flippedSPS, Self.pps, idr]))
        XCTAssertEqual(fired, 0, "second 0x09/0xa8 on an IDR AU hangs the hold")
    }

    /// LUT / WAVE own VT. Same-raster new SPS (zoom, FORMAT, D-Log2 → D-Log hop)
    /// keeps the session only if VT takes the new format; otherwise every frame
    /// fails silently — frozen well, live HUD (#148, #194).
    func testVTSessionAlwaysAcceptsAdoptedFormat() throws {
        let decoder = HevcDecoder()
        decoder.effects.waveform = true
        _ = decoder.decode(accessUnit: Self.annexB([Self.vps, Self.sps, Self.pps]))
        try XCTSkipUnless(decoder.vtRebuildCount == 1, "no VT HEVC decoder on this host")
        XCTAssertTrue(decoder.vtSessionAcceptsCurrentFormat)

        var flippedSPS = Self.sps
        flippedSPS[flippedSPS.count - 1] ^= 0x01
        _ = decoder.decode(accessUnit: Self.annexB([Self.vps, flippedSPS, Self.pps]))
        XCTAssertTrue(decoder.hasFormat)
        XCTAssertTrue(
            decoder.vtSessionAcceptsCurrentFormat,
            "kept a VT session that refuses the new SPS — every frame would fail")
        XCTAssertFalse(decoder.awaitingIDR, "same-raster rebuild must not hold IDR")
    }

    func testWatchDemandStartsOneDecoderWithoutAssistsAndSurvivesReset() throws {
        let sets = Self.annexB([Self.vps, Self.sps, Self.pps])
        let control = HevcDecoder()
        control.effects = MonitorFrameEffects()
        _ = control.decode(accessUnit: sets)
        XCTAssertEqual(control.vtRebuildCount, 0, "Unpaired identity keeps its existing path")

        let capability = HevcDecoder()
        capability.effects.waveform = true
        _ = capability.decode(accessUnit: sets)
        try XCTSkipUnless(capability.vtRebuildCount == 1, "no VT HEVC decoder on this host")

        let decoder = HevcDecoder()
        decoder.effects = MonitorFrameEffects()
        decoder.needsWatchPreview = true
        var enables = 0
        decoder.onHandoffNeedsIDR = { enables += 1 }
        _ = decoder.decode(accessUnit: sets)
        XCTAssertEqual(decoder.vtRebuildCount, 1, "Watch needs pixels with AF-S and assists off")
        XCTAssertEqual(enables, 0, "Initial Watch demand must not cut the first GOP")

        decoder.needsWatchPreview = false
        XCTAssertEqual(decoder.vtRebuildCount, 1, "Keep the decoder through a companion change")
        XCTAssertEqual(enables, 0)
        decoder.needsWatchPreview = true
        decoder.reset()
        let beforeReconnect = decoder.vtRebuildCount
        _ = decoder.decode(accessUnit: sets)
        XCTAssertEqual(decoder.vtRebuildCount, beforeReconnect + 1)
        XCTAssertEqual(enables, 0, "Reconnect uses the normal first GOP")
    }

    private static func annexB(_ nals: [[UInt8]]) -> [UInt8] {
        nals.flatMap { [0, 0, 1] + $0 }
    }

    // Real Pocket live-view sets from `HevcTests`.
    private static let vps = hex(
        "40010c01ffff21600000030000030000030000030096ac0c0000030004000003006540")
    private static let sps = hex(
        "42010121600000030000030000030000030096a00280802d17aeedc9ae5d4d404040410000030001000003001908"
    )
    private static let pps = hex("4401c17312240890")
}

private func hex(_ s: String) -> [UInt8] {
    var out = [UInt8]()
    var i = s.startIndex
    while i < s.endIndex {
        let j = s.index(i, offsetBy: 2)
        out.append(UInt8(s[i..<j], radix: 16)!)
        i = j
    }
    return out
}
