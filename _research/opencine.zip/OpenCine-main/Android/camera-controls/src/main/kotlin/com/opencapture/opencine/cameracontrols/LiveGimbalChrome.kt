package com.opencapture.opencine.cameracontrols

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.opencapture.monitorui.GimbalCluster
import com.opencapture.monitorui.LiveChromeMetrics
import com.opencapture.monitorui.LiveMonitorLayout
import com.opencapture.monitorui.MonitorDrawerTabs
import com.opencapture.monitorui.MonitorDurationDial
import com.opencapture.monitorui.MonitorDurationDialMetrics
import com.opencapture.monitorui.MonitorFloatingDrag
import com.opencapture.monitorui.MonitorIcon
import com.opencapture.monitorui.MonitorInspector
import com.opencapture.monitorui.MonitorMaterial
import com.opencapture.monitorui.MonitorMotionDismissBackdrop
import com.opencapture.monitorui.MonitorOptionGroup
import com.opencapture.monitorui.MonitorPalette
import com.opencapture.monitorui.MonitorRect
import com.opencapture.monitorui.MonitorSwitchGraphic
import com.opencapture.monitorui.MonitorValueDrum
import com.opencapture.monitorui.monitorMaterial
import com.opencapture.monitorui.monitorReadoutShadow
import com.opencapture.monitorui.monitorScrollFade
import com.opencapture.opencine.appkit.LocalOperatorHaptics
import com.opencapture.opencine.motion.GimbalProgram
import com.opencapture.opencine.motion.GimbalProgramCurve
import com.opencapture.opencine.motion.GimbalWaypoint
import com.opencapture.opencine.motion.GimbalWaypointOverlay
import com.opencapture.opencine.motion.GimbalWaypointSlot
import com.opencapture.opencine.vocabulary.CameraLabelProfile
import com.opencapture.opencine.vocabulary.CameraStatus
import com.opencapture.opencine.vocabulary.GimbalDoubleTap
import com.opencapture.opencine.vocabulary.GimbalHudCopy
import com.opencapture.opencine.vocabulary.GimbalMode
import com.opencapture.opencine.vocabulary.GimbalRamp
import com.opencapture.opencine.vocabulary.GimbalSpeed
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withTimeoutOrNull

/**
 * What the gimbal chrome reads and drives: the app's panel and placement state, its gimbal
 * preferences and label profile, the lens's widest horizontal field of view for waypoint marks,
 * and the session's motion program. Each app's model implements it. [phase] is the session's
 * connection phase; the views only compare it.
 */
interface GimbalChromeHost {
    var liveGimbalPanel: LiveGimbalPanel
    var gimbalFloatCenter: Offset?
    val liveChromeInteractive: Boolean
    val isEditingChrome: Boolean
    val mirrorsHorizontally: Boolean
    val labelProfile: CameraLabelProfile
    val waypointWideHFovDeg: Double
    val gimbalRamp: GimbalRamp
    val gimbalDoubleTap: GimbalDoubleTap
    fun updateGimbalRamp(value: GimbalRamp)
    fun updateGimbalDoubleTap(value: GimbalDoubleTap)
    val connectedCameraId: String?
    val phase: Any
    val phaseFlow: StateFlow<Any>
    val gimbalMode: StateFlow<GimbalMode>
    val gimbalSpeed: StateFlow<GimbalSpeed>
    val gimbalProgram: StateFlow<GimbalProgram>
    val gimbalMoveRunning: StateFlow<Boolean>
    val gimbalMovePaused: StateFlow<Boolean>
    val gimbalMoveCountdown: StateFlow<Int?>
    val gimbalPoseInvertPan: StateFlow<Boolean>
    val chromeStatus: StateFlow<CameraStatus>
    val canRunProgrammedMove: Boolean
    fun predictedGimbalWaypoint(nowSeconds: Double): GimbalWaypoint?
    fun programmedZoomUnavailableReason(status: CameraStatus): String?
    fun setGimbalMode(mode: GimbalMode)
    fun setGimbalSpeed(speed: GimbalSpeed)
    fun setGimbalWaypoint(slot: GimbalWaypointSlot)
    fun clearGimbalWaypoint(slot: GimbalWaypointSlot)
    fun setGimbalLegDuration(ab: Double? = null, bc: Double? = null)
    fun setGimbalSmoothness(value: Double)
    fun setGimbalLoop(enabled: Boolean)
    fun clearGimbalProgram()
    fun runProgrammedMove()
    fun restartProgrammedMove()
    fun pauseProgrammedMove()
    fun resumeProgrammedMove()
    fun cancelProgrammedMove()
}

enum class LiveGimbalPanel {
    NONE,
    SHEET,
    EDITOR,
    RUN_PILL,
}

private const val EDITOR_WIDTH_DP = 340f
private const val EDITOR_HEIGHT_DP = 420f
private const val HOLD_MS = 300L

@Composable
fun LiveGimbalButton(
    locked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .size(LiveChromeMetrics.ZOOM_CHIP_DP.dp)
            .chromeClickable(enabled = !locked, onClick = onClick)
            .semantics { contentDescription = "Gimbal controls" },
        contentAlignment = Alignment.Center,
    ) {
        MonitorIcon(
            MonitorIcon.CROSSHAIR,
            contentDescription = null,
            modifier = Modifier.size(18.dp).alpha(if (locked) 0.4f else 1f).monitorReadoutShadow(),
            tint = LiveDesign.text,
        )
    }
}

/** Trailing gimbal inspector uses the shared monitor-ui frame. */
@Composable
@Suppress("UNUSED_PARAMETER")
fun LiveGimbalSheetHost(
    model: GimbalChromeHost,
    layout: LiveMonitorLayout,
    cluster: GimbalCluster,
    safeLeading: Float,
    safeTrailing: Float,
    safeTop: Float,
    safeBottom: Float,
) {
    var selectedTab by remember { mutableStateOf(GimbalSettingsTab.MODE) }
    val mode by model.gimbalMode.collectAsState()
    val speed by model.gimbalSpeed.collectAsState()
    val program by model.gimbalProgram.collectAsState()
    val phase by model.phaseFlow.collectAsState()
    val cameraId = model.connectedCameraId
    var revision by remember { mutableIntStateOf(0) }
    val canApply = !model.isEditingChrome && model.liveChromeInteractive &&
        model.liveGimbalPanel == LiveGimbalPanel.SHEET
    DisposableEffect(selectedTab, cameraId, phase, canApply) {
        revision += 1
        onDispose { revision += 1 }
    }
    val context = GimbalInteractionContext(cameraId, phase, selectedTab, revision, canApply)
    val haptics = LocalOperatorHaptics.current
    fun applyIfCurrent(block: () -> Unit) {
        if (!context.matches(model, selectedTab, revision)) return
        block()
    }
    MonitorInspector(
        title = "Gimbal",
        viewportWidth = layout.viewportWidth,
        viewportHeight = layout.viewportHeight,
        onDismiss = { model.liveGimbalPanel = LiveGimbalPanel.NONE },
        trailing = true,
        hasNavigation = false,
        safeLeading = safeLeading,
        safeTrailing = safeTrailing,
        safeTop = safeTop,
        safeBottom = safeBottom,
        footer = {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp)
                    .background(LiveDesign.accentDim, RoundedCornerShape(10.dp))
                    .chromeClickable {
                        applyIfCurrent { model.liveGimbalPanel = LiveGimbalPanel.EDITOR }
                    }
                    .padding(horizontal = 12.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Motion Control", style = LiveType.ui(11.5f, FontWeight.SemiBold))
                    Text("${program.summary} · Experimental", color = LiveDesign.muted, style = LiveType.ui(9f))
                }
                MonitorIcon(MonitorIcon.CHEVRON_RIGHT, null, Modifier.size(15.dp), LiveDesign.accent)
            }
        },
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MonitorDrawerTabs(
                tabs = GimbalSettingsTab.entries.map { tab -> tab.title },
                selected = selectedTab.ordinal,
                onSelect = { selectedTab = GimbalSettingsTab.entries[it] },
            )
            key(context) {
                MonitorOptionGroup {
                    when (selectedTab) {
                        GimbalSettingsTab.MODE ->
                            MonitorValueDrum(
                                GimbalMode.pickerOrder.map { it.label(model.labelProfile) }, mode.label(model.labelProfile),
                                interactive = canApply,
                                onDetent = { haptics.confirm() },
                            ) { label ->
                                applyIfCurrent {
                                    GimbalMode.pickerOrder.firstOrNull { it.label(model.labelProfile) == label }
                                        ?.let(model::setGimbalMode)
                                }
                            }
                        GimbalSettingsTab.SPEED ->
                            MonitorValueDrum(
                                GimbalSpeed.pickerOrder.map { it.label }, speed.label,
                                interactive = canApply,
                                onDetent = { haptics.confirm() },
                            ) { label ->
                                applyIfCurrent {
                                    GimbalSpeed.pickerOrder.firstOrNull { it.label == label }
                                        ?.let(model::setGimbalSpeed)
                                }
                            }
                        GimbalSettingsTab.RAMP ->
                            MonitorValueDrum(
                                GimbalRamp.pickerOrder.map { it.label }, model.gimbalRamp.label,
                                interactive = canApply,
                                onDetent = { haptics.confirm() },
                            ) { label ->
                                applyIfCurrent {
                                    GimbalRamp.pickerOrder.firstOrNull { it.label == label }
                                        ?.let(model::updateGimbalRamp)
                                }
                            }
                        GimbalSettingsTab.DOUBLE_TAP ->
                            MonitorValueDrum(
                                GimbalDoubleTap.pickerOrder.map { it.label }, model.gimbalDoubleTap.label,
                                interactive = canApply,
                                onDetent = { haptics.confirm() },
                            ) { label ->
                                applyIfCurrent {
                                    GimbalDoubleTap.pickerOrder.firstOrNull { it.label == label }
                                        ?.let(model::updateGimbalDoubleTap)
                                }
                            }
                    }
                }
            }
        }
    }
}

@Composable
fun LiveGimbalOverlay(
    model: GimbalChromeHost,
    layout: LiveMonitorLayout,
    feed: MonitorRect,
    uiLocked: Boolean,
    joystickBounds: MonitorRect = MonitorRect(0f, 0f, 0f, 0f),
    zoomBounds: MonitorRect = MonitorRect(0f, 0f, 0f, 0f),
) {
    if (uiLocked) return
    val panel = model.liveGimbalPanel
    val program by model.gimbalProgram.collectAsState()
    val running by model.gimbalMoveRunning.collectAsState()
    val phase by model.phaseFlow.collectAsState()
    val cameraId = model.connectedCameraId
    val bounds =
        MonitorRect(
            max(8f, layout.safeLeading),
            max(8f, layout.safeTop),
            max(
                1f,
                layout.viewportWidth - max(8f, layout.safeLeading) - max(8f, layout.safeTrailing),
            ),
            max(
                1f,
                layout.viewportHeight - max(8f, layout.safeTop) - max(8f, layout.safeBottom),
            ),
        )
    val defaultEditor = motionEditorDefaultFrame(bounds, zoomBounds, layout.viewportHeight > layout.viewportWidth)
    val editorMaximumHeight = defaultEditor.height
    val editorHeight = min(EDITOR_HEIGHT_DP, editorMaximumHeight)
    val defaultTopCenter = Offset(defaultEditor.midX, defaultEditor.minY)
    Box(Modifier.fillMaxSize().zIndex(if (panel == LiveGimbalPanel.EDITOR) 1f else 0f)) {
        if (panel == LiveGimbalPanel.EDITOR || panel == LiveGimbalPanel.RUN_PILL || running) {
            LiveGimbalWaypointMarks(model, feed, program)
        }
        if (panel == LiveGimbalPanel.EDITOR) {
            MonitorMotionDismissBackdrop(
                viewport = Rect(0f, 0f, layout.viewportWidth, layout.viewportHeight),
                excluding = listOf(joystickBounds, zoomBounds).map { rect ->
                    Rect(rect.minX, rect.minY, rect.minX + rect.width, rect.minY + rect.height)
                },
                onDismiss = { model.liveGimbalPanel = LiveGimbalPanel.RUN_PILL },
            )
            GimbalFloatMove(
                model = model,
                sizeHintW = min(EDITOR_WIDTH_DP, bounds.width),
                sizeHintH = editorHeight,
                bounds = bounds,
                defaultTopCenter = defaultTopCenter,
                identity = Triple(panel, cameraId, phase),
            ) {
                LiveGimbalEditor(model, program, running, maxWidthDp = bounds.width, maxHeightDp = editorMaximumHeight)
            }
        }
        if (panel == LiveGimbalPanel.RUN_PILL) {
            GimbalFloatMove(
                model = model,
                sizeHintW = 172f,
                sizeHintH = 44f,
                bounds = bounds,
                defaultTopCenter = defaultTopCenter,
                immediateDrag = true,
                identity = Triple(panel, cameraId, phase),
            ) {
                LiveGimbalRunPill(model, program, running)
            }
        }
    }
}

/** Keep the portrait default between system edge gestures and Zoom; manual drags use the full viewport. */
fun motionEditorDefaultFrame(bounds: MonitorRect, zoom: MonitorRect, portrait: Boolean): MonitorRect {
    val originalHeight = min(EDITOR_HEIGHT_DP, bounds.height)
    val reservedTop = if (portrait) max(bounds.minY, 44f) else bounds.minY
    val bottom = if (portrait && !zoom.isEmpty) min(bounds.maxY, max(reservedTop + 1f, zoom.minY - 8f)) else bounds.maxY
    val height = max(0f, min(originalHeight, bottom - reservedTop))
    // Not coerceIn: float rounding can put bottom - height an ULP below reservedTop, and coerceIn throws.
    val top = max(reservedTop, min(bounds.minY + (bounds.height - originalHeight) / 2f, bottom - height))
    val width = min(EDITOR_WIDTH_DP, bounds.width)
    return MonitorRect(bounds.midX - width / 2f, top, width, height)
}

/** The existing 25 Hz display prediction invalidates only marker content. */
@Composable
private fun LiveGimbalWaypointMarks(model: GimbalChromeHost, feed: MonitorRect, program: GimbalProgram) {
    val poseInvertPan by model.gimbalPoseInvertPan.collectAsState()
    var frameTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) { delay(40); frameTick += 1 }
    }
    val live = if (frameTick >= 0) {
        model.predictedGimbalWaypoint(android.os.SystemClock.elapsedRealtime() / 1000.0)
    } else null
    if (live != null) {
        val aspect = (feed.width / feed.height.coerceAtLeast(1f)).toDouble()
        val preview = remember(program) { GimbalProgramCurve.create(program)?.samples() }
        if (preview != null) {
            Canvas(Modifier.fillMaxSize()) {
                val path = Path()
                var connected = false
                for (sample in preview) {
                    val (nx, ny, onScreen) = GimbalWaypointOverlay.project(sample, live, aspect, model.waypointWideHFovDeg)
                    if (!onScreen) { connected = false; continue }
                    val x = (feed.minX + motionOverlayX(nx, poseInvertPan, model.mirrorsHorizontally).toFloat() * feed.width).dp.toPx()
                    val y = (feed.minY + ny.toFloat() * feed.height).dp.toPx()
                    if (connected) path.lineTo(x, y) else path.moveTo(x, y)
                    connected = true
                }
                drawPath(path, LiveDesign.text.copy(alpha = 0.3f), style = Stroke(
                    width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 5.dp.toPx()))))
            }
        }
        for (slot in GimbalWaypointSlot.entries) {
            val point = program.point(slot) ?: continue
            val (nx, ny, onScreen) = GimbalWaypointOverlay.project(point, live, aspect, model.waypointWideHFovDeg)
            Box(
                Modifier
                    .offset {
                        IntOffset(
                            (feed.minX + motionOverlayX(nx, poseInvertPan, model.mirrorsHorizontally).toFloat() * feed.width - 13f).dp.roundToPx(),
                            (feed.minY + ny.toFloat() * feed.height - 13f).dp.roundToPx(),
                        )
                    }
                    .size(26.dp)
                    .background(
                        LiveDesign.accent.copy(alpha = if (onScreen) 0.92f else 0.45f),
                        CircleShape,
                    )
                    .alpha(if (onScreen) 1f else 0.7f)
                    .zIndex(0f),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    slot.letter,
                    color = LiveDesign.text,
                    style = LiveType.ui(13f, FontWeight.Bold),
                )
            }
        }
    }
}

@Composable
fun GimbalFloatMove(
    model: GimbalChromeHost,
    sizeHintW: Float,
    sizeHintH: Float,
    bounds: MonitorRect,
    defaultTopCenter: Offset,
    immediateDrag: Boolean = false,
    identity: Any? = null,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    val haptics = LocalOperatorHaptics.current
    var measuredW by remember { mutableFloatStateOf(sizeHintW) }
    var measuredH by remember { mutableFloatStateOf(sizeHintH) }
    val placement = remember { MonitorFloatingDrag<Offset>() }
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    // Opening, minimizing and rotating do not turn a default into a manual
    // position. Only a real drag stores a center; defaults follow the viewport.
    val raw = model.gimbalFloatCenter ?: defaultTopCenter.copy(y = defaultTopCenter.y + measuredH / 2f)
    val center = clampCenter(raw, measuredW, measuredH, bounds)
    val currentCenter by rememberUpdatedState(center)
    DisposableEffect(identity) {
        onDispose { placement.cancel() }
    }
    val dragModifier = Modifier
            .pointerInput(bounds, measuredW, measuredH, immediateDrag, identity) {
                detectHoldThenDragAllowClicks(
                    holdMs = HOLD_MS,
                    immediate = immediateDrag,
                    onHold = {
                        placement.begin(currentCenter)
                        haptics.confirm()
                    },
                    onDrag = drag@{ translation ->
                        if (placement.preview == null && translation == Offset.Zero) return@drag
                        val start = placement.origin ?: currentCenter
                        val dx = translation.x / density.density
                        val dy = translation.y / density.density
                        val next =
                            clampCenter(
                                Offset(start.x + dx, start.y + dy),
                                measuredW,
                                measuredH,
                                bounds,
                            )
                        placement.move(next)
                    },
                    onEnd = { placement.end { model.gimbalFloatCenter = it } },
                    onCancel = { placement.cancel() },
                    toRoot = { local -> coords?.localToRoot(local) ?: local },
                )
            }

    Box(
        Modifier
            .offset {
                val shown = clampCenter(placement.preview ?: center, measuredW, measuredH, bounds)
                IntOffset(((shown.x - measuredW / 2f) * density.density).roundToInt(),
                    ((shown.y - measuredH / 2f) * density.density).roundToInt())
            }
            .onSizeChanged {
                measuredW = it.width / density.density
                measuredH = it.height / density.density
            }
            .onGloballyPositioned { coords = it }
            .then(dragModifier)
            .zIndex(1f),
    ) {
        content()
    }
}

private enum class GimbalSettingsTab(val title: String) {
    MODE("Mode"), SPEED("Speed"), RAMP("Ramp"), DOUBLE_TAP("Double-tap")
}

private data class GimbalInteractionContext(
    val cameraId: String?,
    val phase: Any,
    val tab: GimbalSettingsTab?,
    val revision: Int,
    val enabled: Boolean,
) {
    fun matches(model: GimbalChromeHost, liveTab: GimbalSettingsTab?, liveRevision: Int): Boolean {
        if (!enabled || revision != liveRevision || model.liveGimbalPanel != LiveGimbalPanel.SHEET) return false
        if (tab != null && tab != liveTab) return false
        if (model.connectedCameraId != cameraId) return false
        if (model.phase != phase) return false
        if (model.isEditingChrome || !model.liveChromeInteractive) return false
        return true
    }
}

@Composable
private fun LiveGimbalEditor(model: GimbalChromeHost, program: GimbalProgram, running: Boolean,
    maxWidthDp: Float, maxHeightDp: Float) {
    val countdown by model.gimbalMoveCountdown.collectAsState()
    val paused by model.gimbalMovePaused.collectAsState()
    val phase by model.phaseFlow.collectAsState()
    val status by model.chromeStatus.collectAsState()
    val zoomNote = model.programmedZoomUnavailableReason(status)
    val cameraId = model.connectedCameraId
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val remainingThreshold = with(density) { 2.dp.roundToPx() }
    val moreBelow by remember(scroll, remainingThreshold) {
        derivedStateOf { scroll.canScrollForward && scroll.maxValue - scroll.value > remainingThreshold }
    }
    Column(
        Modifier
            .width(min(EDITOR_WIDTH_DP, maxWidthDp).dp)
            .height(min(EDITOR_HEIGHT_DP, maxHeightDp).dp)
            .testTag("motion.editor")
            .monitorMaterial(MonitorMaterial.Expanded, RoundedCornerShape(16.dp)),
    ) {
        Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 12.dp).testTag("motion.header"),
            verticalAlignment = Alignment.CenterVertically) {
            Text("MOTION CONTROL", color = LiveDesign.text,
                style = LiveType.ui(9f, FontWeight.SemiBold).copy(letterSpacing = 1.6.sp),
                modifier = Modifier.weight(1f))
            Box(
                Modifier
                    .size(30.dp)
                    .chromeClickable(onClick = { model.liveGimbalPanel = LiveGimbalPanel.RUN_PILL }),
                contentAlignment = Alignment.Center,
            ) {
                MonitorIcon(
                    MonitorIcon.MINIMIZE,
                    contentDescription = "Minimize",
                    modifier = Modifier.size(16.dp),
                    tint = LiveDesign.text,
                )
            }
            LivePopupCloseButton(
                onClick = {
                    model.liveGimbalPanel = if (running) LiveGimbalPanel.RUN_PILL else LiveGimbalPanel.NONE
                },
                size = 30.dp,
                modifier = Modifier.testTag("motion.close"),
            )
        }
        Column(
            Modifier.weight(1f).fillMaxWidth()
                .testTag("motion.settings")
                .semantics { if (moreBelow) stateDescription = "More settings below" }
                .monitorScrollFade(scroll)
                .verticalScroll(scroll)
                .padding(horizontal = 12.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            waypointRow(model, program, GimbalWaypointSlot.A, duration = null, floor = null, running, cameraId, phase)
            waypointRow(model, program, GimbalWaypointSlot.B, duration = program.durationAB,
                floor = GimbalProgram.minTravelDuration(program.a, program.b), running, cameraId, phase)
            waypointRow(model, program, GimbalWaypointSlot.C, duration = program.durationBC,
                floor = GimbalProgram.minTravelDuration(program.b, program.c), running, cameraId, phase)
            if (program.b != null && program.c != null) {
                Text(String.format(java.util.Locale.US, "Smoothness %.2f", program.smoothness),
                    color = LiveDesign.text, style = LiveType.ui(13f, FontWeight.SemiBold))
                Slider(value = program.smoothness.toFloat(),
                    onValueChange = { model.setGimbalSmoothness(it.toDouble()) },
                    valueRange = 0f..1f, steps = 19)
            }
            Row(
                Modifier.fillMaxWidth().heightIn(min = 44.dp)
                    .testTag("motion.loop")
                    .toggleable(value = program.loop, enabled = !running, role = Role.Switch,
                        onValueChange = model::setGimbalLoop)
                    .alpha(if (running) .45f else 1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Loop", color = LiveDesign.text, style = LiveType.ui(13f, FontWeight.SemiBold))
                    Text("Repeat back and forth until Stop.", color = LiveDesign.secondary, style = LiveType.ui(9.5f))
                }
                MonitorSwitchGraphic(program.loop)
            }
        }
        zoomNote?.let {
            Text(it, color = LiveDesign.muted, style = LiveType.ui(10f),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).testTag("motion.zoomNote"))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp).testTag("motion.actions"),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!running) {
                Chip("Clear", selected = false, modifier = Modifier.weight(1f).height(44.dp).testTag("motion.clear")) {
                    model.clearGimbalProgram()
                }
                Chip(GimbalHudCopy.RUN, selected = model.canRunProgrammedMove,
                    modifier = Modifier.weight(1f).height(44.dp).testTag("motion.startStop"),
                    enabled = model.canRunProgrammedMove) { model.runProgrammedMove() }
            } else {
                if (countdown == null) {
                    if (paused) {
                        Chip("Restart", selected = false,
                            modifier = Modifier.weight(1f).height(44.dp).testTag("motion.restart")) {
                            model.restartProgrammedMove()
                        }
                    }
                    Chip(if (paused) "Resume" else "Pause", selected = true,
                        modifier = Modifier.weight(1f).height(44.dp).testTag("motion.pauseResume")) {
                        if (paused) model.resumeProgrammedMove() else model.pauseProgrammedMove()
                    }
                }
                Chip(countdown?.let { "Stop · $it" } ?: "Stop", selected = true,
                    modifier = Modifier.weight(1f).height(44.dp).testTag("motion.startStop")) { model.cancelProgrammedMove() }
            }
        }
    }
}

@Composable
private fun waypointRow(
    model: GimbalChromeHost,
    program: GimbalProgram,
    slot: GimbalWaypointSlot,
    duration: Double?,
    floor: Double?,
    running: Boolean,
    cameraId: String?,
    phase: Any,
) {
    val point = program.point(slot)
    val set = point != null
    val readout = point?.takeIf { it.yawDeg.isFinite() && it.pitchDeg.isFinite() && it.zoom.isFinite() }?.let {
        String.format(java.util.Locale.US, "PAN %+.0f°  TILT %+.0f°  %.1f×", it.yawDeg, it.pitchDeg, it.zoom)
    } ?: "Not set"
    MonitorOptionGroup {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.size(22.dp).background(
                if (set) LiveDesign.accentDim else LiveDesign.glassBright, CircleShape),
                contentAlignment = Alignment.Center) {
                Text(slot.letter, color = if (set) LiveDesign.accent else LiveDesign.muted,
                    style = LiveType.ui(10f, FontWeight.Bold))
            }
            Text(readout, color = if (set) LiveDesign.text else LiveDesign.secondary,
                style = LiveType.ui(10f, FontWeight.Medium), maxLines = 1,
                modifier = Modifier.weight(1f))
            Box(Modifier.height(44.dp).widthIn(min = 44.dp)
                .testTag("motion.waypoint.${slot.letter}")
                .chromeClickable(onClick = { model.setGimbalWaypoint(slot) })
                .semantics {
                    contentDescription = if (set) "Reset waypoint ${slot.letter}" else "Set waypoint ${slot.letter}"
                    role = Role.Button
                }, contentAlignment = Alignment.Center) {
                Text(if (set) "RESET" else "SET",
                    color = if (set) androidx.compose.ui.graphics.Color(0xFFDFE4E4)
                        else androidx.compose.ui.graphics.Color(0xFF08191F),
                    style = LiveType.ui(10f, FontWeight.Bold).copy(letterSpacing = .6.sp),
                    modifier = Modifier.background(
                        if (set) androidx.compose.ui.graphics.Color.White.copy(alpha = .07f) else LiveDesign.accent,
                        RoundedCornerShape(8.dp),
                    ).padding(horizontal = 11.dp, vertical = 7.dp))
            }
            if (set) {
                Box(Modifier.size(44.dp).chromeClickable(onClick = { model.clearGimbalWaypoint(slot) }),
                    contentAlignment = Alignment.Center) {
                    MonitorIcon(MonitorIcon.X, contentDescription = "Clear ${slot.letter}",
                        modifier = Modifier.size(12.dp), tint = LiveDesign.muted)
                }
            }
        }
        if (set && duration != null && floor != null) {
            Row(Modifier.fillMaxWidth().padding(bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (slot == GimbalWaypointSlot.B) "A → B" else "B → C",
                    style = LiveType.ui(8.5f, FontWeight.SemiBold), color = LiveDesign.muted,
                    modifier = Modifier.weight(1f))
                val haptics = LocalOperatorHaptics.current
                MonitorDurationDial(
                    value = duration,
                    onChange = { next ->
                        if (running) return@MonitorDurationDial
                        if (model.liveGimbalPanel != LiveGimbalPanel.EDITOR) return@MonitorDurationDial
                        if (model.connectedCameraId != cameraId) return@MonitorDurationDial
                        if (model.phase != phase) return@MonitorDurationDial
                        when (slot) {
                            GimbalWaypointSlot.B -> model.setGimbalLegDuration(ab = next)
                            GimbalWaypointSlot.C -> model.setGimbalLegDuration(bc = next)
                            GimbalWaypointSlot.A -> Unit
                        }
                    },
                    range = floor..MonitorDurationDialMetrics.MAX,
                    modifier = Modifier.testTag("motion.duration.${slot.letter}"),
                    source = listOf(slot, floor, running, cameraId, phase, LiveGimbalPanel.EDITOR),
                    enabled = !running,
                    onStep = { haptics.confirm() },
                )
            }
        }
    }
}

@Composable
private fun LiveGimbalRunPill(model: GimbalChromeHost, program: GimbalProgram, running: Boolean) {
    val countdown by model.gimbalMoveCountdown.collectAsState()
    val paused by model.gimbalMovePaused.collectAsState()
    Row(
        Modifier.widthIn(min = 172.dp).monitorGlass(RoundedCornerShape(50)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (running && countdown == null) {
            Text(if (paused) "RESUME" else "PAUSE", color = LiveDesign.text,
                style = LiveType.ui(13f, FontWeight.Bold),
                modifier = Modifier.testTag("motion.pauseResume")
                    .chromeClickable(onClick = {
                        if (paused) model.resumeProgrammedMove() else model.pauseProgrammedMove()
                    }).padding(horizontal = 14.dp, vertical = 12.dp))
        }
        Text(countdown?.let { "STOP · $it" } ?: if (running) "STOP" else GimbalHudCopy.RUN.uppercase(),
            color = LiveDesign.text, style = LiveType.ui(13f, FontWeight.Bold),
            modifier = Modifier.testTag("motion.startStop")
                .chromeClickable(enabled = model.canRunProgrammedMove || running,
                    onClick = { if (running) model.cancelProgrammedMove() else model.runProgrammedMove() })
                .padding(horizontal = 14.dp, vertical = 12.dp))
        Box(
            Modifier
                .size(44.dp, 40.dp)
                .testTag("motion.expand")
                .chromeClickable(onClick = { model.liveGimbalPanel = LiveGimbalPanel.EDITOR }),
            contentAlignment = Alignment.Center,
        ) {
            MonitorIcon(
                MonitorIcon.MAXIMIZE,
                contentDescription = "Expand Motion Control",
                modifier = Modifier.size(16.dp),
                tint = LiveDesign.text,
            )
        }
    }
}

@Composable
private fun section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title.uppercase(),
            color = LiveDesign.muted,
            style = LiveType.ui(11f, FontWeight.SemiBold).copy(letterSpacing = 0.8.sp),
        )
        content()
    }
}

@Composable
private fun Chip(
    title: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    compact: Boolean = false,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .background(
                if (selected) LiveDesign.accent else LiveDesign.glassBright,
                RoundedCornerShape(50),
            )
            .chromeClickable(enabled = enabled, onClick = onClick)
            .padding(vertical = if (compact) 7.dp else 8.dp, horizontal = if (compact) 12.dp else 0.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            title,
            color = if (selected) LiveDesign.background else LiveDesign.text,
            style = LiveType.ui(if (compact) 12f else 13f, FontWeight.SemiBold),
        )
    }
}

private fun clampCenter(point: Offset, width: Float, height: Float, bounds: MonitorRect): Offset {
    val halfW = max(width / 2f, 20f)
    val halfH = max(height / 2f, 16f)
    return Offset(
        min(max(point.x, bounds.minX + halfW), max(bounds.minX + halfW, bounds.maxX - halfW)),
        min(max(point.y, bounds.minY + halfH), max(bounds.minY + halfH, bounds.maxY - halfH)),
    )
}

/**
 * Direct drag like movable scopes. Children (SET, duration dial, smoothness)
 * keep the pointer when they consume it; a started drag consumes so the gimbal
 * stick under the window never sees the sequence. Pill hold-without-move still
 * claims so a long press on Start does not fire a click on lift.
 */
private suspend fun PointerInputScope.detectHoldThenDragAllowClicks(
    holdMs: Long,
    immediate: Boolean,
    onHold: () -> Unit,
    onDrag: (Offset) -> Unit,
    onEnd: () -> Unit,
    onCancel: () -> Unit,
    toRoot: (Offset) -> Offset,
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        val pointerId = down.id
        val downRoot = toRoot(down.position)
        val gesture = MotionControlDragGesture(immediate, 8.dp.toPx(), holdMs)
        var elapsed = 0L
        var started = false
        var released = false
        try {
            while (true) {
                val tracking = gesture.ownership == MotionControlDragGesture.Ownership.TRACKING
                val event = if (tracking && immediate) {
                    withTimeoutOrNull((holdMs - elapsed).coerceAtLeast(1)) {
                        awaitPointerEvent(PointerEventPass.Initial)
                    }
                } else {
                    awaitPointerEvent(PointerEventPass.Initial)
                }
                if (event == null) {
                    gesture.update(holdMs, 0f, childConsumed = false)
                    if (gesture.ownership == MotionControlDragGesture.Ownership.DRAGGING && !started) {
                        started = true
                        onHold()
                    }
                    continue
                }
                val change = event.changes.firstOrNull { it.id == pointerId } ?: break
                elapsed = change.uptimeMillis - down.uptimeMillis
                val translation = toRoot(change.position) - downRoot
                if (tracking) {
                    val final = awaitPointerEvent(PointerEventPass.Final)
                    val childConsumed = final.changes.any { it.isConsumed }
                    when (gesture.update(elapsed, translation.getDistance(), childConsumed)) {
                        MotionControlDragGesture.Ownership.YIELDED -> break
                        MotionControlDragGesture.Ownership.DRAGGING -> {
                            if (!started) { started = true; onHold() }
                            event.changes.forEach { it.consume() }
                            if (change.pressed) onDrag(translation)
                        }
                        MotionControlDragGesture.Ownership.TRACKING -> Unit
                    }
                } else if (gesture.ownership == MotionControlDragGesture.Ownership.DRAGGING) {
                    event.changes.forEach { it.consume() }
                    if (change.pressed) onDrag(translation)
                } else {
                    break
                }
                if (!change.pressed) { released = true; break }
            }
        } finally {
            if (started && released) onEnd() else onCancel()
        }
    }
}
