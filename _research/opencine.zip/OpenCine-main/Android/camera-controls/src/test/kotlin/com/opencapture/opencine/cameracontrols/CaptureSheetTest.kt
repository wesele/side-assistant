package com.opencapture.opencine.cameracontrols

import com.opencapture.opencine.vocabulary.CameraCommands
import com.opencapture.opencine.vocabulary.CameraModel
import com.opencapture.opencine.vocabulary.CameraStatus
import com.opencapture.opencine.vocabulary.ConnectionPhase
import com.opencapture.opencine.vocabulary.EvComp
import com.opencapture.opencine.vocabulary.FocusOption
import com.opencapture.opencine.vocabulary.FocusTrackMode
import com.opencapture.opencine.vocabulary.IsoLimit
import com.opencapture.opencine.vocabulary.ShutterAngle
import com.opencapture.opencine.vocabulary.VideoFormat
import com.opencapture.opencine.vocabulary.VideoFrameRate
import com.opencapture.opencine.vocabulary.VideoResolution
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class CaptureSheetTest {
    @Test
    fun formatPickerKeepsPortraitWhenCapabilitiesHaveNotArrived() {
        val status = CameraStatus(resolutionCode = 0x6C, fpsIndex = 2, fps = 25)
        assertEquals(
            listOf("3K"),
            CaptureLists.modeTabs(LiveSheet.FORMAT, status, offersIsoAuto = false),
        )
        assertNull(
            CaptureLists.nextVideoFormat(status, tab = 0, drum = "30p", fromDrum = true),
            "empty camcap is read-only; fps change must not invent a SET",
        )
    }

    @Test
    fun isoStarFollowsStatusTransferNotTeleHopGuess() {
        var status = CameraStatus(colorMode = CameraCommands.COLOR_DLOG2)
        assertEquals(setOf("1600"), CaptureLists.isoMarkedLabels(status))
        status = status.copy(colorMode = CameraCommands.COLOR_DLOG)
        assertEquals(
            setOf("400"),
            CaptureLists.isoMarkedLabels(status),
            "star follows status.colorMode after the body reports D-Log",
        )
        assertEquals(
            CameraCommands.COLOR_DLOG,
            CameraCommands.colorModeForZoom(3.0, CameraCommands.COLOR_DLOG2),
        )
        status = status.copy(colorMode = CameraCommands.COLOR_DLOG2)
        assertEquals(
            setOf("1600"),
            CaptureLists.isoMarkedLabels(status),
            "zoom tele hop guess must not flip the star while status is still D-Log2",
        )
        assertEquals(
            setOf("400"),
            CaptureLists.isoMarkedLabels(CameraStatus(colorMode = CameraCommands.COLOR_DLOG_M)),
        )
        assertTrue(CaptureLists.isoMarkedLabels(CameraStatus()).isEmpty())
    }

    @Test
    fun dLog2HasNoIsoAuto() {
        val status = CameraStatus(colorMode = CameraCommands.COLOR_DLOG2)
        assertTrue(!CaptureLists.offersIsoAuto(status))
        assertTrue(CaptureLists.isoAutoLabels(status, isoAutoRangeFloor = 100).isEmpty())
        assertTrue(!CaptureLists.isoFallback(status.colorMode).contains(0))
    }

    @Test
    fun isoAutoRangesFollowColorAndBody() {
        val dash = "\u2013"
        fun ladder(base: Int, vararg tops: Int) = tops.map { "$base$dash$it" }
        val full = intArrayOf(200, 400, 800, 1600, 3200, 6400, 12800, 25600)
        val dlog = CameraStatus(colorMode = CameraCommands.COLOR_DLOG)
        val normal = CameraStatus(colorMode = CameraCommands.COLOR_NORMAL)
        val hdr = CameraStatus(colorMode = CameraCommands.COLOR_HDR)
        val p3 = "Osmo Pocket 3"
        // why to (status, body name, expected labels)
        val cases = listOf(
            "D-Log starts at 400" to Triple(dlog, "", ladder(400, 800, 1600, 3200, 6400)),
            "Normal starts at 100" to Triple(normal, "", ladder(100, *full)),
            "HDR starts at 100" to Triple(hdr, "", ladder(100, *full)),
            "Pocket 3 starts at 50" to Triple(normal, p3, ladder(50, *full)),
        )
        for ((why, case) in cases) {
            val (status, body, expected) = case
            assertEquals(expected, CaptureLists.isoAutoLabels(status, body, isoAutoRangeFloor = if (body == p3) 50 else 100), why)
        }

        assertEquals(listOf(0x04, 0x05, 0x06, 0x07), CaptureLists.isoAutoLimits(dlog.colorMode).map { it.rawValue })
        assertEquals(IsoLimit.Max1600, CaptureLists.isoLimit("400${dash}1600", dlog, isoAutoRangeFloor = 100))
        assertTrue(CaptureLists.offersIsoAuto(dlog))

        assertEquals(IsoLimit.Max800, CaptureLists.isoLimit("100${dash}800", normal, isoAutoRangeFloor = 100))
        assertEquals(IsoLimit.Max25600, CaptureLists.isoLimit("100${dash}25600", hdr, isoAutoRangeFloor = 100))
        assertEquals(0x02, IsoLimit.Max200.rawValue)
        assertEquals(0x03, IsoLimit.Max400.rawValue)
        assertEquals(0x06, IsoLimit.Max3200.rawValue)
        assertEquals(0x08, IsoLimit.Max12800.rawValue)

        assertEquals(IsoLimit.Max400, CaptureLists.isoLimit("50${dash}400", normal, p3, isoAutoRangeFloor = 50))
        assertEquals(
            "50${dash}400",
            CaptureLists.isoAutoLabel(normal.copy(isoLimit = 0x03), p3, isoAutoRangeFloor = 50),
        )
        assertEquals("50${dash}200", CaptureLists.isoAutoLabels(normal, "Osmo Pocket 4", isoAutoRangeFloor = 50).first())
        assertEquals(
            "100${dash}200",
            CaptureLists.isoAutoLabels(normal, "Osmo Pocket 4 Pro", isoAutoRangeFloor = 100).first(),
        )
        assertEquals(
            IsoSheetLogic.Command.SetLimit(0x03),
            IsoSheetLogic.applyDrum("50${dash}400", normal, selectedMode = 0, bodyName = p3, isoAutoRangeFloor = 50),
        )
    }

    @Test
    fun evLabelsThirdStopsFromMinus3ToPlus3() {
        val minus = EvComp.MINUS
        val labels = CaptureLists.evLabels
        assertEquals(0x07, EvComp.fromLabel("${minus}3.0")?.rawValue)
        assertEquals(0x10, EvComp.fromLabel("0.0")?.rawValue)
        assertEquals(0x19, EvComp.fromLabel("+3.0")?.rawValue)
        assertEquals(
            listOf(
                "${minus}3.0",
                "${minus}2.7",
                "${minus}2.3",
                "${minus}2.0",
                "${minus}1.7",
                "${minus}1.3",
                "${minus}1.0",
                "${minus}0.7",
                "${minus}0.3",
                "0.0",
                "+0.3",
                "+0.7",
                "+1.0",
                "+1.3",
                "+1.7",
                "+2.0",
                "+2.3",
                "+2.7",
                "+3.0",
            ),
            labels,
        )
    }

    @Test
    fun shutterAngleLadderIsCalculatedNotCaptured() {
        assertEquals("5.6°", ShutterAngle.labels.first())
        assertEquals("360°", ShutterAngle.labels.last())
        assertTrue(ShutterAngle.labels.contains("180°"))
        assertTrue(ShutterAngle.labels.contains("86.4°"))
        assertTrue(ShutterAngle.labels.contains("172°"))
        assertEquals(180.0, ShutterAngle.parse("180°"))
        assertEquals(5.6, ShutterAngle.parse("5.6°"))
        assertEquals("180°", ShutterAngle.label(180.0))
        assertEquals("5.6°", ShutterAngle.label(5.6))
        assertEquals("11.2°", ShutterAngle.label(11.2))
        assertEquals(48, ShutterAngle.denom(180.0, 24))
        assertEquals(50, ShutterAngle.denom(180.0, 25))
        assertEquals(60, ShutterAngle.denom(180.0, 30))
        assertEquals(120, ShutterAngle.denom(180.0, 60))
        assertEquals(24, ShutterAngle.denom(360.0, 24))
        assertEquals(1_543, ShutterAngle.denom(5.6, 24))
        assertEquals(50, ShutterAngle.denom(180.0, 24, listOf(25, 50, 100)))
        assertEquals(48, ShutterAngle.denom(180.0, 24, emptyList()))
        assertEquals(24, ShutterAngle.effectiveFps(0))
        assertEquals(60, ShutterAngle.effectiveFps(60))
        assertEquals("180°", ShutterAngle.nearestLabel(48, 24))
        assertEquals("172°", ShutterAngle.nearestLabel(50, 24))
        assertEquals("360°", ShutterAngle.nearestLabel(24, 24))
        assertEquals("180°", ShutterAngle.nearestLabel(50, 25))
    }

    @Test
    fun emptyCapListUsesDocumentedVideoLadder() {
        val status = CameraStatus(shutterDenom = 80)
        val denoms = CaptureLists.shutterDenoms(status)
        assertTrue(denoms.contains(80))
        assertTrue(denoms.contains(50))
        assertTrue(denoms.contains(8000))
        assertTrue(CaptureLists.shutterLabels(status).contains("1/80"))
        assertTrue(CaptureLists.shutterLabels(status).contains("1/50"))
    }

    @Test
    fun autoExpoWheelIsEvLabelsAndAngleLadder() {
        val auto = CameraStatus(expoMode = CameraCommands.EXPO_AUTO, evComp = 0x10)
        val manual = CameraStatus(expoMode = CameraCommands.EXPO_MANUAL, shutterDenom = 50)
        assertTrue(CaptureLists.isEvSheet(LiveSheet.SHUTTER, auto.expoMode))
        assertTrue(!CaptureLists.isEvSheet(LiveSheet.SHUTTER, manual.expoMode))
        assertEquals("EV", CaptureLists.shutterHeaderTitle(true))
        assertEquals("SHUTTER", CaptureLists.shutterHeaderTitle(false))
        assertEquals("Compensation", CaptureLists.shutterHeaderSubtitle(true, false, false))
        assertEquals("Face priority", CaptureLists.shutterHeaderSubtitle(true, false, true))
        assertEquals("Speed", CaptureLists.shutterHeaderSubtitle(false, false, false))
        assertEquals("Angle", CaptureLists.shutterHeaderSubtitle(false, true, false))
        assertEquals(emptyList(), CaptureLists.shutterModeTabs(true))
        assertEquals(listOf("Speed", "Angle"), CaptureLists.shutterModeTabs(false))
        assertEquals(CaptureLists.evLabels, CaptureLists.shutterWheelOptions(auto, true, false))
        assertEquals(ShutterAngle.labels, CaptureLists.shutterWheelOptions(manual, false, true))
        assertEquals(
            CaptureLists.shutterLabels(manual),
            CaptureLists.shutterWheelOptions(manual, false, false),
        )
        assertEquals(null, CaptureLists.shutterTabAfterExpoChange(CameraCommands.EXPO_AUTO, true))
        assertEquals(1, CaptureLists.shutterTabAfterExpoChange(CameraCommands.EXPO_MANUAL, true))
        assertEquals(0, CaptureLists.shutterTabAfterExpoChange(CameraCommands.EXPO_MANUAL, false))
    }

    @Test
    fun reseatIgnoresLiveShutterDenomTicks() {
        assertTrue(
            !CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.SHUTTER_DENOM, false),
        )
        assertTrue(
            !CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.SHUTTER_DENOM, true),
        )
        assertTrue(
            CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.AVAILABLE_DENOMS, false),
        )
        assertTrue(!CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.AVAILABLE_DENOMS, true))
        assertTrue(CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.FPS, false))
        assertTrue(!CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.FPS, true))
        assertTrue(CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.EXPO_MODE, true))
        assertTrue(CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.EV_COMP, true))
        assertTrue(!CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.EV_COMP, false))
        assertTrue(CaptureLists.shouldReseatShutter(CaptureLists.ShutterReseatKey.FACE_PRIORITY, true))
    }

    @Test
    fun applyDrumAngleMapsToNearestLegalDenomAtLiveFps() {
        val status =
            CameraStatus(
                fps = 24,
                shutterDenom = 50,
                expoMode = CameraCommands.EXPO_MANUAL,
                availableShutterDenoms = listOf(25, 50, 100),
            )
        assertEquals(
            CaptureLists.ShutterDrumCommand.SetAngle(180.0, 50),
            CaptureLists.applyShutterDrum("180°", false, true, false, status),
        )
        val empty = status.copy(availableShutterDenoms = emptyList(), shutterDenom = 48)
        assertEquals(
            CaptureLists.ShutterDrumCommand.SetAngle(180.0, 48),
            CaptureLists.applyShutterDrum("180°", false, true, false, empty),
        )
    }

    @Test
    fun applyDrumEvThirdsAndFacePriorityGreysWrites() {
        val auto = CameraStatus(expoMode = CameraCommands.EXPO_AUTO, evComp = 0x10)
        assertEquals(
            CaptureLists.ShutterDrumCommand.SetEv(3),
            CaptureLists.applyShutterDrum("+1.0", true, false, false, auto),
        )
        assertEquals(
            CaptureLists.ShutterDrumCommand.SetEv(-9),
            CaptureLists.applyShutterDrum("${EvComp.MINUS}3.0", true, false, false, auto),
        )
        assertEquals(
            CaptureLists.ShutterDrumCommand.Ignored,
            CaptureLists.applyShutterDrum("+1.0", true, false, true, auto),
        )
        assertEquals("0.0", CaptureLists.reseatEv(auto).selection)
        assertEquals("+0.3", CaptureLists.reseatEv(auto.copy(evComp = 0x11)).selection)
        assertEquals("0.0", CaptureLists.reseatEv(CameraStatus()).selection)
    }

    @Test
    fun reseatAngleKeepsPreferredWhenMappedToLive() {
        val status =
            CameraStatus(
                fps = 24,
                shutterDenom = 50,
                availableShutterDenoms = listOf(25, 50, 100),
            )
        val seat = CaptureLists.reseatShutterAngle(status, 180.0)
        assertEquals("180°", seat.selection)
        assertEquals(180.0, seat.preferredAngle)
        assertTrue(!seat.persistAngle)
    }

    @Test
    fun reseatAngleDisplaysLiveValueWithoutReplacingOperatorIntent() {
        val status =
            CameraStatus(
                fps = 24,
                shutterDenom = 24,
                availableShutterDenoms = listOf(24, 48, 50),
            )
        val seat = CaptureLists.reseatShutterAngle(status, 180.0)
        assertEquals("360°", seat.selection)
        assertEquals(180.0, seat.preferredAngle)
        assertTrue(!seat.persistAngle)
        val speed = CaptureLists.reseatShutterSpeed(CameraStatus(shutterDenom = 80))
        assertEquals("1/80", speed.selection)
    }

    @Test
    fun rematchShutterDenomAfterFpsKeepsAngle() {
        assertEquals(
            60,
            CaptureLists.rematchShutterDenomAfterFps(
                usesAngle = true,
                degrees = 180.0,
                previousFps = 24,
                nextFps = 30,
                expoMode = CameraCommands.EXPO_MANUAL,
                currentDenom = 48,
                available = emptyList(),
            ),
        )
        assertEquals(
            null,
            CaptureLists.rematchShutterDenomAfterFps(
                usesAngle = true,
                degrees = 180.0,
                previousFps = 24,
                nextFps = 24,
                expoMode = CameraCommands.EXPO_MANUAL,
                currentDenom = 48,
                available = emptyList(),
            ),
        )
        assertEquals(
            null,
            CaptureLists.rematchShutterDenomAfterFps(
                usesAngle = true,
                degrees = 180.0,
                previousFps = 24,
                nextFps = 30,
                expoMode = CameraCommands.EXPO_AUTO,
                currentDenom = 48,
                available = emptyList(),
            ),
        )
        assertEquals(
            50,
            CaptureLists.rematchShutterDenomAfterFps(
                usesAngle = true,
                degrees = 180.0,
                previousFps = 24,
                nextFps = 25,
                expoMode = CameraCommands.EXPO_MANUAL,
                currentDenom = 48,
                available = listOf(25, 50, 100),
            ),
        )
    }

    @Test
    fun lowerCaptureValuesHideForBottomPickersAndStripQuickOnly() {
        assertTrue(!LiveSheet.MODE.isRecordingSetup)
        assertTrue(!hidesLowerCaptureValues(LiveSheet.FORMAT, stripQuick = false, topQuick = false))
        assertTrue(!hidesLowerCaptureValues(LiveSheet.MODE, stripQuick = false, topQuick = false))
        assertTrue(!hidesLowerCaptureValues(null, stripQuick = false, topQuick = true))
        assertTrue(hidesLowerCaptureValues(LiveSheet.ISO, stripQuick = false, topQuick = false))
        assertTrue(hidesLowerCaptureValues(null, stripQuick = true, topQuick = false))
    }

    @Test
    fun kelvinLabelsRoundTripToValues() {
        assertEquals("5600K", CaptureLists.kelvinLabels[CaptureLists.kelvinValues.indexOf(5600)])
        assertEquals(3200, CaptureLists.kelvinFromLabel("3200K"))
        assertEquals(10000, CaptureLists.kelvinFromLabel("10000K"))
    }

    @Test
    fun wbSheetTabsModeKelvinTint() {
        assertEquals(listOf("Mode", "Kelvin", "Tint"), CaptureLists.wbTabs)
        assertEquals("Kelvin / auto / tint", LiveSheet.WB.subtitle)
        assertEquals(listOf("Auto", "Custom"), CaptureLists.wbModeRows)
        assertEquals(
            CaptureLists.WB_TAB_MODE,
            CaptureLists.wbInitialTab(CameraStatus(wbMode = CameraCommands.WB_AUTO)),
        )
        assertEquals(
            CaptureLists.WB_TAB_MODE,
            CaptureLists.wbInitialTab(CameraStatus()),
        )
        assertEquals(
            CaptureLists.WB_TAB_KELVIN,
            CaptureLists.wbInitialTab(
                CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 3200),
            ),
        )
        assertEquals("Auto", CaptureLists.wbModeRowSelected(CameraStatus()))
        assertEquals(
            "Custom",
            CaptureLists.wbModeRowSelected(CameraStatus(wbMode = CameraCommands.WB_CUSTOM)),
        )
        assertTrue(CaptureLists.wbSendsAuto("Auto"))
        assertTrue(!CaptureLists.wbSendsAuto("Custom"))
        assertEquals(
            listOf("Mode", "Kelvin", "Tint"),
            CaptureLists.modeTabs(LiveSheet.WB, CameraCommands.EXPO_MANUAL, false),
        )
    }

    @Test
    fun wbCustomRowSendsCurrentKelvinAndTint() {
        val custom =
            CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 3200, wbTint = -20)
        assertEquals(3200 to -20, CaptureLists.wbCustomFromStatus(custom))
        val autoCleared =
            CameraStatus(wbMode = CameraCommands.WB_AUTO, wbKelvin = -1, wbTint = 0)
        assertEquals(5600 to 0, CaptureLists.wbCustomFromStatus(autoCleared))
        val unknownKelvin = CameraStatus(wbMode = CameraCommands.WB_AUTO, wbKelvin = 0, wbTint = 7)
        assertEquals(5600, CaptureLists.currentKelvin(unknownKelvin))
        assertEquals(7, CaptureLists.currentTint(unknownKelvin))
        assertEquals("5600K", CaptureLists.wbDrumSelection(autoCleared))
        assertEquals("3200K", CaptureLists.wbDrumSelection(custom))
        val autoKeepsLast =
            CameraStatus(wbMode = CameraCommands.WB_AUTO, wbKelvin = 4200, wbTint = 20)
        assertEquals(4200 to 20, CaptureLists.wbCustomFromStatus(autoKeepsLast))
        assertEquals("4200K", CaptureLists.wbDrumSelection(autoKeepsLast))
    }

    @Test
    fun wbKelvinDrumAppliesOnlyOnKelvinTab() {
        val status = CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 5600, wbTint = 12)
        assertEquals(null, CaptureLists.wbKelvinDrumApply(CaptureLists.WB_TAB_MODE, "3200K", status))
        assertEquals(null, CaptureLists.wbKelvinDrumApply(CaptureLists.WB_TAB_TINT, "3200K", status))
        assertEquals(3200 to 12, CaptureLists.wbKelvinDrumApply(CaptureLists.WB_TAB_KELVIN, "3200K", status))
        assertEquals(10000 to 12, CaptureLists.wbKelvinDrumApply(CaptureLists.WB_TAB_KELVIN, "10000K", status))
        assertEquals(null, CaptureLists.wbKelvinDrumApply(CaptureLists.WB_TAB_KELVIN, "nope", status))
    }

    @Test
    fun wbTintPadIsMinus100To100WithNeutral() {
        assertEquals("Neutral", CaptureLists.tintLabel(0))
        assertEquals("+10", CaptureLists.tintLabel(10))
        assertEquals("-5", CaptureLists.tintLabel(-5))
        assertEquals(-100, CaptureLists.roundedTint(-100.4f))
        assertEquals(100, CaptureLists.roundedTint(100.6f))
        val status = CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 5600, wbTint = 0)
        assertEquals(5600 to -10, CaptureLists.wbCustomFromTint(-10f, status))
        assertEquals(5600 to 100, CaptureLists.wbCustomFromTint(140f, status))
        assertTrue(
            !CaptureLists.wbTintStaysAuto(
                CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 5600),
            ),
        )
        assertTrue(CaptureLists.wbTintStaysAuto(CameraStatus(wbMode = CameraCommands.WB_AUTO)))
        assertTrue(CaptureLists.wbTintStaysAuto(CameraStatus()))
    }

    @Test
    fun focusTrackChipsMatchIosCopy() {
        assertEquals(CaptureLists.FOCUS_TAB_SINGLE, "AF-S")
        assertEquals(CaptureLists.FOCUS_TAB_CONTINUOUS, "AF-C")
        assertEquals(
            listOf(
                "Default",
                "Product Showcase",
                "Subject Lock Tracking",
                "Registered Subject Priority",
            ),
            FocusTrackMode.entries.map { it.label },
        )
        assertEquals(0x00, FocusTrackMode.DEFAULT.raw)
        assertEquals(0x01, FocusTrackMode.PRODUCT_SHOWCASE.raw)
        assertEquals(0x02, FocusTrackMode.SUBJECT_LOCK.raw)
        assertEquals(0x03, FocusTrackMode.REGISTERED_PRIORITY.raw)
        assertEquals("AF-S", FocusOption.resolve(CameraCommands.FOCUS_SINGLE, 2)?.chip)
        assertEquals("AF-C", FocusOption.resolve(CameraCommands.FOCUS_CONTINUOUS, -1)?.chip)
        assertEquals("AF-C", FocusOption.resolve(CameraCommands.FOCUS_CONTINUOUS, 0)?.chip)
        assertEquals("Showcase", FocusOption.resolve(CameraCommands.FOCUS_CONTINUOUS, 1)?.chip)
        assertEquals("Lock", FocusOption.resolve(CameraCommands.FOCUS_CONTINUOUS, 2)?.chip)
        assertEquals("Priority", FocusOption.resolve(CameraCommands.FOCUS_CONTINUOUS, 3)?.chip)
        assertEquals(
            "Showcase",
            CameraStatus(focusMode = CameraCommands.FOCUS_CONTINUOUS, focusTrack = 1).focusLabel,
        )
        assertEquals("AF-S", CameraStatus(focusMode = CameraCommands.FOCUS_SINGLE, focusTrack = 2).focusLabel)
        assertEquals("AF-C", CameraStatus(focusMode = CameraCommands.FOCUS_CONTINUOUS, focusTrack = -1).focusLabel)
        assertEquals("—", CameraStatus().focusLabel)

        val afs = CameraStatus(focusMode = CameraCommands.FOCUS_SINGLE, focusTrack = -1)
        val afc = CameraStatus(focusMode = CameraCommands.FOCUS_CONTINUOUS, focusTrack = -1)
        val lock = CameraStatus(focusMode = CameraCommands.FOCUS_CONTINUOUS, focusTrack = 2)
        assertTrue(!CaptureLists.focusIsContinuous(afs))
        assertTrue(!CaptureLists.focusShowsTrackChips(afs))
        assertTrue(CaptureLists.focusIsContinuous(afc))
        assertTrue(CaptureLists.focusShowsTrackChips(afc))
        assertTrue(CaptureLists.shouldRefreshFocusTrack(afc, supportsFocus = true))
        assertTrue(!CaptureLists.shouldRefreshFocusTrack(lock, supportsFocus = true))
        assertTrue(!CaptureLists.shouldRefreshFocusTrack(afc, supportsFocus = false))
    }

    @Test
    fun fpsDrumParsesAndColorWheelFiltersByBody() {
        assertEquals(VideoFrameRate.FPS48, VideoFrameRate.fromDrumLabel("48p"))
        assertEquals(VideoFrameRate.FPS120, VideoFrameRate.fromDrumLabel("120p"))
        assertTrue(!CaptureLists.fpsDrumLabels.contains("120p"))
        assertEquals(
            listOf("Normal", "HDR", "D-Log"),
            CaptureLists.colorWheelLabels(CameraStatus(), profile = CaptureTestProfiles.base),
        )
        assertEquals(
            listOf("Normal", "HDR", "D-Log", "D-Log2"),
            CaptureLists.colorWheelLabels(
                CameraStatus(),
                family = "pocket",
                name = "Osmo Pocket 4 Pro", profile = CaptureTestProfiles.pro
            ),
        )
        assertEquals(
            listOf("Normal", "HDR", "D-Log M"),
            CaptureLists.colorWheelLabels(
                CameraStatus(),
                family = "pocket",
                name = "Osmo Pocket 3", profile = CaptureTestProfiles.lowLight
            ),
        )
        assertEquals(
            listOf("Normal", "HDR", "D-Log"),
            CaptureLists.colorWheelLabels(
                CameraStatus(),
                family = "pocket",
                name = "Osmo Pocket 4", profile = CaptureTestProfiles.base
            ),
        )
        assertEquals(CameraCommands.COLOR_DLOG2, CaptureLists.colorModeFromLabel("D-Log2"))
        assertEquals(CameraCommands.COLOR_DLOG_M, CaptureLists.colorModeFromLabel("D-Log M"))
        assertEquals(
            listOf("Normal", "HDR", "D-Log", "D-Log2"),
            CaptureLists.colorWheel(
                "pocket",
                listOf(
                    CameraCommands.COLOR_DLOG2,
                    CameraCommands.COLOR_DLOG,
                    CameraCommands.COLOR_HDR,
                    CameraCommands.COLOR_NORMAL,
                ),
                "Osmo Pocket 4 Pro", profile = CaptureTestProfiles.pro
            ).map { it.second },
        )
        assertTrue(
            CaptureLists.colorWheel(
                "pocket",
                listOf(
                    CameraCommands.COLOR_DLOG2,
                    CameraCommands.COLOR_DLOG,
                    CameraCommands.COLOR_HDR,
                    CameraCommands.COLOR_NORMAL,
                ),
                "Osmo Pocket 3", profile = CaptureTestProfiles.lowLight
            ).none { it.first == CameraCommands.COLOR_DLOG2 },
        )
        assertTrue(
            CaptureLists.colorWheel(
                "pocket",
                listOf(
                    CameraCommands.COLOR_DLOG2,
                    CameraCommands.COLOR_DLOG,
                    CameraCommands.COLOR_HDR,
                    CameraCommands.COLOR_NORMAL,
                ),
                "Osmo Pocket 4", profile = CaptureTestProfiles.base
            ).none { it.first == CameraCommands.COLOR_DLOG2 },
        )
        assertNull(CaptureLists.colorModeFromLabel("N-Log"))
    }

    @Test
    fun nanoColorWheelUsesCamcapFamily() {
        assertEquals(
            listOf("Normal 8-bit", "Normal 10-bit", "D-Log M 10-bit"),
            CaptureLists.colorWheelLabels(CameraStatus(), family = "nano", profile = CaptureTestProfiles.fixed),
        )
        assertEquals(CameraCommands.COLOR_NORMAL, CaptureLists.colorModeFromLabel("Normal 8-bit", "nano", profile = CaptureTestProfiles.fixed))
        assertEquals(CameraCommands.COLOR_NORMAL10, CaptureLists.colorModeFromLabel("Normal 10-bit", "nano", profile = CaptureTestProfiles.fixed))
        assertEquals(CameraCommands.COLOR_DLOG_M, CaptureLists.colorModeFromLabel("D-Log M 10-bit", "nano", profile = CaptureTestProfiles.fixed))
        assertEquals("Normal 8-bit", CameraCommands.colorLabel(CameraCommands.COLOR_NORMAL, "nano", CaptureTestProfiles.fixed))
        assertEquals("Normal", CameraCommands.colorLabel(CameraCommands.COLOR_NORMAL, "pocket"))
        assertEquals(
            listOf("Normal 8-bit", "Normal 10-bit", "D-Log M 10-bit"),
            CaptureLists.colorWheel(
                "nano",
                listOf(
                    CameraCommands.COLOR_DLOG_M,
                    CameraCommands.COLOR_NORMAL,
                    CameraCommands.COLOR_NORMAL10,
                ), profile = CaptureTestProfiles.fixed
            ).map { it.second },
        )
        assertEquals(
            listOf("Normal 8-bit", "Normal 10-bit", "D-Log M 10-bit"),
            CaptureLists.colorWheelLabels(
                CameraStatus(
                    availableColorModes =
                        listOf(
                            CameraCommands.COLOR_DLOG_M,
                            CameraCommands.COLOR_NORMAL,
                            CameraCommands.COLOR_NORMAL10,
                        ),
                ),
                family = "nano", profile = CaptureTestProfiles.fixed
            ),
        )
        assertTrue(
            CaptureLists.colorWheel("pocket", listOf(CameraCommands.COLOR_NORMAL, 0x99), profile = CaptureTestProfiles.base)
                .none { it.first == 0x99 },
        )
    }

    @Test
    fun expoModeSheetIsAutoManualOnly() {
        assertEquals(listOf("Auto", "Manual"), CaptureLists.expoLabels)
        assertEquals("Auto", CameraStatus(expoMode = CameraCommands.EXPO_AUTO).expoLabel)
        assertEquals("Manual", CameraStatus(expoMode = CameraCommands.EXPO_MANUAL).expoLabel)
        assertEquals("Auto", CaptureLists.expoSelectedLabel(CameraCommands.EXPO_AUTO))
        assertEquals("Manual", CaptureLists.expoSelectedLabel(CameraCommands.EXPO_MANUAL))
        assertEquals(null, CaptureLists.expoSelectedLabel(-1))
        // AE-L sits left of Auto while locked; Auto or Manual releases it.
        assertEquals(listOf("AE-L", "Auto", "Manual"), CaptureLists.expoLabels(aeLocked = true))
        assertEquals("AE-L", CaptureLists.expoSelectedLabel(CameraCommands.EXPO_MANUAL, aeLocked = true))
        assertEquals(null, CaptureLists.expoModeFromLabel("AE-L"))
    }

    @Test
    fun awbLockIsAModeStopLeftOfAutoAndStaysSelectedWhileLocked() {
        val auto = CameraStatus(wbMode = CameraCommands.WB_AUTO)
        assertEquals(listOf("AWB Lock", "Auto", "Custom"), CaptureLists.wbModeRows(offersLock = true))
        assertEquals(listOf("Auto", "Custom"), CaptureLists.wbModeRows(offersLock = false))
        assertEquals("Auto", CaptureLists.wbModeRowSelected(auto))
        // Locked: the camera is Custom, but the stop, tab and tile stay AWB Lock.
        val locked = CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 4_900)
        assertEquals("AWB Lock", CaptureLists.wbModeRowSelected(locked, awbLocked = true))
        assertEquals(CaptureLists.WB_TAB_MODE, CaptureLists.wbInitialTab(locked, awbLocked = true))
        assertEquals("AWB-L", CaptureLists.wbChipValue(locked, awbLocked = true))
        // Unlocked Custom returns to the Kelvin tab and value.
        assertEquals(CaptureLists.WB_TAB_KELVIN, CaptureLists.wbInitialTab(locked))
        assertEquals("4900K", CaptureLists.wbChipValue(locked))
        assertEquals(CameraCommands.EXPO_AUTO, CaptureLists.expoModeFromLabel("Auto"))
        assertEquals(CameraCommands.EXPO_MANUAL, CaptureLists.expoModeFromLabel("Manual"))
        assertEquals(null, CaptureLists.expoModeFromLabel("Video"))
        assertEquals(null, CaptureLists.expoModeFromLabel("Photo"))
    }

    @Test
    fun audioSheetMatchesIosChannelWindDirVocal() {
        assertEquals("AUDIO", LiveSheet.AUDIO.headerLabel)
        assertEquals("Channel · wind · direction · vocal", LiveSheet.AUDIO.subtitle)
        assertEquals(listOf("Channel", "Wind", "Dir", "Vocal"), CaptureLists.audioTabs)
        assertEquals(
            CaptureLists.audioTabs,
            CaptureLists.modeTabs(LiveSheet.AUDIO, CameraCommands.EXPO_MANUAL, false),
        )
        assertEquals(0, CaptureLists.audioInitialTab())
        assertTrue(CaptureLists.shouldRefreshAudio(LiveSheet.AUDIO))
        assertTrue(!CaptureLists.shouldRefreshAudio(LiveSheet.EXPO))

        val channels = listOf(
            "Stereo" to CameraCommands.AUDIO_STEREO,
            "Mono" to CameraCommands.AUDIO_MONO,
            "Spatial" to CameraCommands.AUDIO_SPATIAL,
        )
        assertEquals(channels.map { it.first }, CaptureLists.audioChannelLabels)
        for ((label, value) in channels) {
            assertEquals(label, CaptureLists.audioChannelLabel(value), "channel $value")
            assertEquals(value, CaptureLists.audioChannelValue(label), "channel $label")
            assertEquals(label, CameraStatus(audioChannel = value).audioLabel, "status channel $value")
        }
        assertEquals(null, CaptureLists.audioChannelLabel(-1))
        assertEquals(null, CaptureLists.audioChannelValue("Surround"))
        assertEquals("\u2014", CameraStatus().audioLabel)

        // Index-coded lists: the raw value is the position in the list.
        val indexed = listOf(
            Triple("wind", listOf("Off", "On"), CaptureLists::audioWindLabel),
            Triple("dir", listOf("All", "Front", "Front+back"), CaptureLists::audioDirLabel),
            Triple("vocal", listOf("Off", "On"), CaptureLists::audioVocalLabel),
        )
        assertEquals(indexed[0].second, CaptureLists.audioWindLabels)
        assertEquals(indexed[1].second, CaptureLists.audioDirLabels)
        assertEquals(indexed[2].second, CaptureLists.audioVocalLabels)
        for ((name, labels, labelFor) in indexed) {
            for ((raw, label) in labels.withIndex()) {
                assertEquals(label, labelFor(raw), "$name $raw")
            }
        }
        assertEquals(null, CaptureLists.audioWindLabel(-1))
        assertEquals(null, CaptureLists.audioVocalLabel(-1))
        for ((raw, label) in indexed[1].second.withIndex()) {
            assertEquals(raw, CaptureLists.audioDirValue(label), "dir $label")
        }
        assertEquals(null, CaptureLists.audioDirValue("Rear"))
    }

    @Test
    fun autoExpoTurnsShutterSheetIntoEv() {
        assertTrue(CaptureLists.isEvSheet(LiveSheet.SHUTTER, CameraCommands.EXPO_AUTO))
        assertTrue(!CaptureLists.isEvSheet(LiveSheet.SHUTTER, CameraCommands.EXPO_MANUAL))
        assertTrue(!CaptureLists.isEvSheet(LiveSheet.SHUTTER, -1))
        assertTrue(!CaptureLists.isEvSheet(LiveSheet.EXPO, CameraCommands.EXPO_AUTO))
        assertEquals("EV", CaptureLists.headerTitle(LiveSheet.SHUTTER, CameraCommands.EXPO_AUTO))
        assertEquals("Compensation", CaptureLists.headerSubtitle(LiveSheet.SHUTTER, CameraCommands.EXPO_AUTO, 0, false))
        assertEquals(
            "Face priority",
            CaptureLists.headerSubtitle(LiveSheet.SHUTTER, CameraCommands.EXPO_AUTO, 0, true),
        )
        assertEquals(emptyList(), CaptureLists.modeTabs(LiveSheet.SHUTTER, CameraCommands.EXPO_AUTO, true))
        assertEquals(null, CaptureLists.shutterTabAfterExpoChange(CameraCommands.EXPO_AUTO, true))
        assertEquals("MODE", CaptureLists.headerTitle(LiveSheet.EXPO, CameraCommands.EXPO_AUTO))
        assertEquals("Exposure", CaptureLists.headerSubtitle(LiveSheet.EXPO, CameraCommands.EXPO_AUTO, 0, false))
        assertEquals(emptyList(), CaptureLists.modeTabs(LiveSheet.EXPO, CameraCommands.EXPO_AUTO, true))
    }

    @Test
    fun manualExpoRestoresShutterSpeedOrAngle() {
        assertEquals("SHUTTER", CaptureLists.headerTitle(LiveSheet.SHUTTER, CameraCommands.EXPO_MANUAL))
        assertEquals("Speed", CaptureLists.headerSubtitle(LiveSheet.SHUTTER, CameraCommands.EXPO_MANUAL, 0, false))
        assertEquals("Angle", CaptureLists.headerSubtitle(LiveSheet.SHUTTER, CameraCommands.EXPO_MANUAL, 1, false))
        assertEquals(
            listOf("Speed", "Angle"),
            CaptureLists.modeTabs(LiveSheet.SHUTTER, CameraCommands.EXPO_MANUAL, true),
        )
        assertEquals(0, CaptureLists.shutterTabAfterExpoChange(CameraCommands.EXPO_MANUAL, false))
        assertEquals(1, CaptureLists.shutterTabAfterExpoChange(CameraCommands.EXPO_MANUAL, true))
        assertTrue(!CaptureLists.isAngleSheet(LiveSheet.SHUTTER, CameraCommands.EXPO_AUTO, 1))
        assertTrue(CaptureLists.isAngleSheet(LiveSheet.SHUTTER, CameraCommands.EXPO_MANUAL, 1))
        assertTrue(!CaptureLists.isAngleSheet(LiveSheet.SHUTTER, CameraCommands.EXPO_MANUAL, 0))
    }

    @Test
    fun isoAutoChipAndLimitGetMatchIos() {
        assertEquals("Auto", CaptureLists.isoChipValue(CameraStatus(isoIndex = 0, iso = 400)))
        assertEquals("1600", CaptureLists.isoChipValue(CameraStatus(isoIndex = 0x07, iso = 1600)))
        assertTrue(CaptureLists.shouldGetIsoLimit(CameraStatus(colorMode = CameraCommands.COLOR_NORMAL)))
        assertTrue(CaptureLists.shouldGetIsoLimit(CameraStatus(colorMode = CameraCommands.COLOR_DLOG)))
        assertTrue(CaptureLists.shouldGetIsoLimit(CameraStatus(colorMode = -1)))
        assertTrue(!CaptureLists.shouldGetIsoLimit(CameraStatus(colorMode = CameraCommands.COLOR_DLOG2)))
    }

    @Test
    fun nativeIsoHopOnlyWhenStillOnBase() {
        data class Hop(val why: String, val from: Int, val to: Int, val index: Int, val enabled: Boolean, val expected: Int?)
        val cases = listOf(
            Hop("D-Log2 base 1600 hops to D-Log base", CameraCommands.COLOR_DLOG2, CameraCommands.COLOR_DLOG, 0x07, true, 0x05),
            Hop("D-Log base 400 hops to D-Log2 base", CameraCommands.COLOR_DLOG, CameraCommands.COLOR_DLOG2, 0x05, true, 0x07),
            Hop("off-base index stays", CameraCommands.COLOR_DLOG2, CameraCommands.COLOR_DLOG, 0x06, true, null),
            Hop("auto index stays", CameraCommands.COLOR_DLOG, CameraCommands.COLOR_DLOG2, 0, true, null),
            Hop("hop disabled", CameraCommands.COLOR_DLOG2, CameraCommands.COLOR_DLOG, 0x07, false, null),
            Hop("log to normal", CameraCommands.COLOR_DLOG2, CameraCommands.COLOR_NORMAL, 0x07, true, null),
            Hop("normal to log", CameraCommands.COLOR_NORMAL, CameraCommands.COLOR_DLOG2, 0x03, true, null),
            Hop("same color", CameraCommands.COLOR_DLOG2, CameraCommands.COLOR_DLOG2, 0x07, true, null),
            Hop("unknown from", -1, CameraCommands.COLOR_DLOG, 0x07, true, null),
            Hop("D-Log M is not a pair", CameraCommands.COLOR_DLOG_M, CameraCommands.COLOR_DLOG2, 0x05, true, null),
        )
        for (case in cases) {
            assertEquals(
                case.expected,
                CaptureLists.nativeIsoHop(from = case.from, to = case.to, currentIndex = case.index, hopEnabled = case.enabled),
                case.why,
            )
        }
    }

    @Test
    fun colorDrumHopsNativeIsoAfterColorSetAndRejectsOffFamily() {
        val pro = "Osmo Pocket 4 Pro"
        val dlog2Native =
            CameraStatus(colorMode = CameraCommands.COLOR_DLOG2, isoIndex = 0x07)
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_DLOG, 0x05),
            CaptureLists.applyColorDrum("D-Log", "pocket", dlog2Native, hopEnabled = true, name = pro, profile = CaptureTestProfiles.pro),
        )
        val dlogNative = CameraStatus(colorMode = CameraCommands.COLOR_DLOG, isoIndex = 0x05)
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_DLOG2, 0x07),
            CaptureLists.applyColorDrum("D-Log2", "pocket", dlogNative, hopEnabled = true, name = pro, profile = CaptureTestProfiles.pro),
        )
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_DLOG, null),
            CaptureLists.applyColorDrum(
                "D-Log",
                "pocket",
                CameraStatus(colorMode = CameraCommands.COLOR_DLOG2, isoIndex = 0x06),
                hopEnabled = true,
                name = pro, profile = CaptureTestProfiles.pro
            ),
        )
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_DLOG2, null),
            CaptureLists.applyColorDrum(
                "D-Log2", "pocket", dlogNative, hopEnabled = false, name = pro, profile = CaptureTestProfiles.pro
            ),
        )
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_DLOG, null),
            CaptureLists.applyColorDrum(
                "D-Log",
                "pocket",
                CameraStatus(colorMode = CameraCommands.COLOR_DLOG2, isoIndex = 0),
                hopEnabled = true,
                name = pro, profile = CaptureTestProfiles.pro
            ),
        )
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_NORMAL, null),
            CaptureLists.applyColorDrum(
                "Normal", "pocket", dlog2Native, hopEnabled = true, name = pro, profile = CaptureTestProfiles.pro
            ),
        )
        assertNull(CaptureLists.applyColorDrum("D-Log2", "nano", CameraStatus(), hopEnabled = true, profile = CaptureTestProfiles.fixed))
        assertNull(CaptureLists.applyColorDrum("D-Log2", "pocket", CameraStatus(), hopEnabled = true, profile = CaptureTestProfiles.base))
        assertNull(
            CaptureLists.applyColorDrum(
                "D-Log2", "pocket", CameraStatus(), hopEnabled = true, name = "Osmo Pocket 4", profile = CaptureTestProfiles.base
            ),
        )
        assertNull(
            CaptureLists.applyColorDrum(
                "D-Log2", "pocket", CameraStatus(), hopEnabled = true, name = "Osmo Pocket 3", profile = CaptureTestProfiles.lowLight
            ),
        )
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_DLOG_M, null),
            CaptureLists.applyColorDrum(
                "D-Log M", "pocket", CameraStatus(), hopEnabled = true, name = "Osmo Pocket 3", profile = CaptureTestProfiles.lowLight
            ),
        )
        assertNull(CaptureLists.applyColorDrum("N-Log", "pocket", CameraStatus(), hopEnabled = true, profile = CaptureTestProfiles.base))
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_NORMAL, null),
            CaptureLists.applyColorDrum("Normal 8-bit", "nano", CameraStatus(), hopEnabled = true, profile = CaptureTestProfiles.fixed),
        )
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_DLOG_M, null),
            CaptureLists.applyColorDrum("D-Log M 10-bit", "nano", CameraStatus(), hopEnabled = true, profile = CaptureTestProfiles.fixed),
        )
        val pocketCap =
            CameraStatus(
                availableColorModes = listOf(CameraCommands.COLOR_NORMAL, CameraCommands.COLOR_HDR),
            )
        assertNull(CaptureLists.applyColorDrum("D-Log2", "pocket", pocketCap, hopEnabled = true, profile = CaptureTestProfiles.base))
        assertEquals(
            ColorDrumCommand(CameraCommands.COLOR_HDR, null),
            CaptureLists.applyColorDrum("HDR", "pocket", pocketCap, hopEnabled = true, profile = CaptureTestProfiles.base),
        )
        val nanoWithDLog =
            CameraStatus(
                availableColorModes =
                    listOf(CameraCommands.COLOR_NORMAL, CameraCommands.COLOR_DLOG),
            )
        assertNull(CaptureLists.applyColorDrum("D-Log", "nano", nanoWithDLog, hopEnabled = true, profile = CaptureTestProfiles.fixed))
    }

    @Test
    fun isoDrumFallsBackToColorTableAndKeepsAutoOnlyCap() {
        val dlog2 = CameraStatus(colorMode = CameraCommands.COLOR_DLOG2)
        assertEquals(
            listOf("100", "200", "400", "800", "1600", "3200"),
            CaptureLists.isoDrumLabels(dlog2),
        )
        assertTrue(!CaptureLists.isoDrumLabels(dlog2).contains("Auto"))
        val dlog = CameraStatus(colorMode = CameraCommands.COLOR_DLOG)
        assertEquals(listOf("400", "800", "1600", "3200", "6400"), CaptureLists.isoDrumLabels(dlog))
        assertTrue(CaptureLists.isoFallback(CameraCommands.COLOR_DLOG).contains(0))
        val autoOnly =
            CameraStatus(colorMode = CameraCommands.COLOR_DLOG, availableIsoIndices = listOf(0))
        assertEquals(listOf(0), CaptureLists.isoIndices(autoOnly))
        assertTrue(CaptureLists.isoDrumLabels(autoOnly).isEmpty())
        assertEquals(
            0,
            CaptureLists.isoIndexFromLabel("Auto"),
        )
        assertEquals(0x07, CaptureLists.isoIndexFromLabel("1600"))
        assertEquals(1600, CameraCommands.isoValue(0x07))
        assertEquals(null, CameraCommands.isoValue(0))
    }

    @Test
    fun isoSheetSendsIndexNotNumberAndAutoIsZero() {
        val dash = "\u2013"
        val dlog =
            CameraStatus(
                colorMode = CameraCommands.COLOR_DLOG,
                isoIndex = 0x05,
                iso = 400,
                availableIsoIndices = listOf(0, 0x05, 0x06, 0x07, 0x08, 0x09),
            )
        assertEquals(
            IsoSheetLogic.Command.SetIndex(0x07),
            IsoSheetLogic.applyDrum("1600", dlog, selectedMode = 1, isoAutoRangeFloor = 100),
        )
        assertEquals(null, IsoSheetLogic.applyDrum("Auto", dlog, selectedMode = 1, isoAutoRangeFloor = 100))
        val auto =
            CameraStatus(
                colorMode = CameraCommands.COLOR_DLOG,
                isoIndex = 0,
                isoLimit = 0x05,
            )
        assertEquals(
            IsoSheetLogic.Command.SetLimit(0x05),
            IsoSheetLogic.applyDrum("400${dash}1600", auto, selectedMode = 0, isoAutoRangeFloor = 100),
        )
        val (autoTab, autoCmd) = IsoSheetLogic.handleModeChange(0, dlog, isoAutoRangeFloor = 100)
        assertEquals(0, autoTab.selectedMode)
        assertEquals(IsoSheetLogic.Command.SetIndex(0), autoCmd)
        val (manualTab, manualCmd) = IsoSheetLogic.handleModeChange(1, auto.copy(iso = 400), isoAutoRangeFloor = 100)
        assertEquals(1, manualTab.selectedMode)
        assertEquals(IsoSheetLogic.Command.SetIndex(0x05), manualCmd)
        val dlog2 = CameraStatus(colorMode = CameraCommands.COLOR_DLOG2, isoIndex = 0x07, iso = 1600)
        assertEquals(0, IsoSheetLogic.reseat(dlog2, isoAutoRangeFloor = 100).selectedMode)
        assertEquals("1600", IsoSheetLogic.reseat(dlog2, isoAutoRangeFloor = 100).drumSelection)
        assertTrue(!CaptureLists.offersIsoAuto(dlog2))
    }

    @Test
    fun isoSheetReseatsOnlyOnCamcapAndColorNotLiveIndex() {
        val base =
            CameraStatus(
                colorMode = CameraCommands.COLOR_DLOG,
                isoIndex = 0x05,
                availableIsoIndices = listOf(0, 0x05, 0x06, 0x07),
            )
        assertTrue(
            !IsoSheetLogic.shouldReseat(base, base.copy(isoIndex = 0, iso = 800)),
            "live isoIndex ticks must not reseat the drum",
        )
        assertTrue(!IsoSheetLogic.shouldReseat(base, base.copy(iso = 1600, isoLimit = 0x07)))
        assertTrue(IsoSheetLogic.shouldReseat(base, base.copy(colorMode = CameraCommands.COLOR_DLOG2)))
        assertTrue(
            IsoSheetLogic.shouldReseat(
                base,
                base.copy(availableIsoIndices = listOf(0x03, 0x04, 0x05, 0x06, 0x07, 0x08)),
            ),
        )
        val autoSeat = IsoSheetLogic.reseat(base.copy(isoIndex = 0, isoLimit = 0x05), isoAutoRangeFloor = 100)
        assertEquals(0, autoSeat.selectedMode)
        val dash = "\u2013"
        assertEquals("400${dash}1600", autoSeat.drumSelection)
        assertTrue(CaptureLists.shouldGetIsoLimit(CameraStatus(colorMode = -1)))
        assertTrue(!CaptureLists.shouldGetIsoLimit(CameraStatus(colorMode = CameraCommands.COLOR_DLOG2)))
        assertTrue(CameraCommands.shouldGetIsoLimit(-1))
        assertTrue(!CameraCommands.shouldGetIsoLimit(CameraCommands.COLOR_DLOG2))
    }

    @Test
    fun recFormatChipMatchesIosChipLabel() {
        assertEquals(
            "4K · 25p",
            CaptureLists.recFormatChipLabel(
                CameraStatus(resolutionCode = CameraCommands.RES_4K, fps = 25),
            ),
        )
        assertEquals(
            "4K · 25p",
            CaptureLists.recFormatChipLabel(
                CameraStatus(resolutionCode = CameraCommands.RES_4K, fpsIndex = 2),
            ),
        )
        assertEquals(
            "1080p · 24p",
            CaptureLists.recFormatChipLabel(
                CameraStatus(resolutionCode = CameraCommands.RES_1080, fps = 24),
            ),
        )
        assertEquals(
            "4K · 25p",
            VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS25).chipLabel,
        )
        assertEquals(
            "1080p · 24p",
            VideoFormat(VideoResolution.P1080, VideoFrameRate.FPS24).chipLabel,
        )
        assertEquals("— · —", CaptureLists.recFormatChipLabel(CameraStatus()))
        assertEquals(
            "4K · 120p",
            CaptureLists.recFormatChipLabel(
                CameraStatus(resolutionCode = CameraCommands.RES_4K, fps = 120, fpsIndex = 7),
            ),
        )
        assertEquals(
            "120p",
            CaptureLists.fpsDrumLabel(
                CameraStatus(resolutionCode = CameraCommands.RES_4K, fps = 120, fpsIndex = 7),
            ),
        )
    }

    @Test
    fun formatPickerTabsAndDrumMatchIos() {
        val live =
            CameraStatus(
                fps = 24,
                resolutionCode = CameraCommands.RES_1080,
                fpsIndex = 1,
            )
        assertEquals(VideoFormat(VideoResolution.P1080, VideoFrameRate.FPS24), VideoFormat.current(live))
        val boot = VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS25)
        assertEquals(
            VideoFormat(VideoResolution.P1080, VideoFrameRate.FPS25),
            VideoFormat.firstPictureEncoderKick(boot),
        )
        assertTrue(!VideoFormat.hasKnownRecordingFormat(CameraStatus()))
        assertTrue(
            VideoFormat.hasKnownRecordingFormat(
                CameraStatus(fps = 25, resolutionCode = CameraCommands.RES_4K, fpsIndex = 2),
            ),
        )
        val p3Video =
            listOf(
                VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS25),
                VideoFormat(VideoResolution.P1080, VideoFrameRate.FPS25),
            )
        assertEquals(
            VideoFormat(VideoResolution.P1080, VideoFrameRate.FPS25),
            VideoFormat.firstPictureEncoderKick(
                VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS30),
                p3Video,
            ),
            "illegal 1080 30 on a 25p table must pick a legal pair",
        )
        assertEquals(
            boot,
            VideoFormat.firstPictureOriginal(
                CameraStatus(
                    fps = 25,
                    resolutionCode = CameraCommands.RES_4K,
                    fpsIndex = 2,
                ),
            ),
        )
        assertEquals(
            VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS30),
            VideoFormat.firstPictureOriginal(CameraStatus()),
            "unknown falls back to 4K 30, not 1080 24",
        )
        assertEquals(VideoResolution.P4K, VideoResolution.fromTabIndex(1))
        assertEquals(VideoResolution.P1080, VideoResolution.fromTabIndex(0))
        assertEquals(
            listOf("1080"),
            CaptureLists.modeTabs(LiveSheet.FORMAT, live.copy(expoMode = -1), offersIsoAuto = false),
            "empty FORMAT table is the current pair only, not invented 1080/4K tabs",
        )
        val fourKOnly =
            live.copy(
                resolutionCode = CameraCommands.RES_4K,
                fpsIndex = 1,
                fps = 24,
                availableVideoFormats =
                    listOf(
                        VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS24),
                        VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS25),
                    ),
            )
        assertEquals(
            listOf("4K"),
            CaptureLists.modeTabs(LiveSheet.FORMAT, fourKOnly, offersIsoAuto = false),
        )
        assertEquals(
            listOf("24p", "25p"),
            CaptureLists.fpsDrumLabels(fourKOnly, tab = 0),
        )
        assertEquals(
            VideoFormat(VideoResolution.P4K, VideoFrameRate.FPS25),
            CaptureLists.nextVideoFormat(fourKOnly, tab = 0, drum = "25p", fromDrum = true),
        )
        assertNull(
            CaptureLists.nextVideoFormat(fourKOnly, tab = 0, drum = "60p", fromDrum = true),
        )
    }

    @Test
    fun formatChangeRewritesShutterAngleLikeIos() {
        assertEquals(
            50,
            CaptureLists.shutterDenomAfterFormatChange(
                previousFps = 24,
                nextFps = 25,
                expoMode = CameraCommands.EXPO_MANUAL,
                shutterUsesAngle = true,
                angleDegrees = 180.0,
                currentDenom = 48,
                available = listOf(25, 50, 100),
            ),
        )
        assertNull(
            CaptureLists.shutterDenomAfterFormatChange(
                previousFps = 24,
                nextFps = 25,
                expoMode = CameraCommands.EXPO_MANUAL,
                shutterUsesAngle = false,
                angleDegrees = 180.0,
                currentDenom = 48,
                available = listOf(25, 50, 100),
            ),
        )
        assertNull(
            CaptureLists.shutterDenomAfterFormatChange(
                previousFps = 24,
                nextFps = 25,
                expoMode = CameraCommands.EXPO_AUTO,
                shutterUsesAngle = true,
                angleDegrees = 180.0,
                currentDenom = 48,
                available = listOf(25, 50, 100),
            ),
        )
        assertNull(
            CaptureLists.shutterDenomAfterFormatChange(
                previousFps = 24,
                nextFps = 24,
                expoMode = CameraCommands.EXPO_MANUAL,
                shutterUsesAngle = true,
                angleDegrees = 180.0,
                currentDenom = 48,
                available = listOf(25, 50, 100),
            ),
        )
    }

    @Test
    fun storagePrefersStorageThenSdLikeIos() {
        val mixed =
            CameraStatus(
                storageFreeMb = 2048,
                storageTotalMb = 4096,
                sdFreeMb = 512,
                sdTotalMb = 1024,
            )
        assertEquals("2 GB · 50%", CaptureLists.storageLabel(mixed, showDuration = false))
        val sdOnly = CameraStatus(sdFreeMb = 1024, sdTotalMb = 2048)
        assertEquals("1 GB · 50%", CaptureLists.storageLabel(sdOnly, showDuration = false))
        val duration = CameraStatus(recordRemainingSec = 180)
        assertEquals("3 Min", CaptureLists.storageLabel(duration, showDuration = true))
        assertEquals("— Min", CaptureLists.storageLabel(CameraStatus(), showDuration = true))
    }

    @Test
    fun wbChipShowsCustomKelvinAndAuto() {
        assertEquals("Auto", CaptureLists.wbChipValue(CameraStatus(wbMode = CameraCommands.WB_AUTO)))
        assertEquals(
            "5600K",
            CaptureLists.wbChipValue(CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 5600)),
        )
        assertEquals(
            "10000K",
            CaptureLists.wbChipValue(CameraStatus(wbMode = CameraCommands.WB_CUSTOM, wbKelvin = 10_000)),
        )
        assertEquals("Custom", CaptureLists.wbChipValue(CameraStatus(wbMode = CameraCommands.WB_CUSTOM)))
        assertEquals("—", CaptureLists.wbChipValue(CameraStatus()))
        assertTrue(CaptureLists.wbIsAuto(CameraStatus(wbMode = CameraCommands.WB_AUTO)))
        assertTrue(CaptureLists.wbIsAuto(CameraStatus()))
        assertTrue(!CaptureLists.wbIsAuto(CameraStatus(wbMode = CameraCommands.WB_CUSTOM)))
    }

    @Test
    fun nanoHasNoFocusMode() {
        assertTrue(!CaptureLists.supportsFocusMode("Osmo Nano"))
        assertTrue(!CaptureLists.supportsFocusMode("OsmoNano-ABCD"))
        assertTrue(CaptureLists.supportsFocusMode("Osmo Pocket 4 Pro", flag = true))
        assertFalse(CaptureLists.supportsFocusMode(null))
        assertTrue(
            !CaptureLists.supportsFocusMode(
                CameraModel(name = "Osmo Nano", family = "nano", supportsFocusMode = false, captureProfile = com.opencapture.opencine.vocabulary.CameraCaptureProfile(supportsFocusMode = false)),
            ),
        )
        assertTrue(
            !CaptureLists.supportsFocusMode(
                CameraModel(name = "Osmo", family = "nano", supportsFocusMode = true, captureProfile = com.opencapture.opencine.vocabulary.CameraCaptureProfile(supportsFocusMode = false)),
            ),
        )
        assertTrue(
            !CaptureLists.supportsFocusMode(
                CameraModel(name = "Osmo Nano", family = "pocket", supportsFocusMode = true, captureProfile = com.opencapture.opencine.vocabulary.CameraCaptureProfile(supportsFocusMode = false)),
            ),
        )
        assertTrue(
            CaptureLists.supportsFocusMode(
                CameraModel(name = "Osmo Pocket 4 Pro", family = "pocket", supportsFocusMode = true, captureProfile = com.opencapture.opencine.vocabulary.CameraCaptureProfile(supportsFocusMode = true)),
            ),
        )
        assertFalse(CaptureLists.supportsFocusModeOrDefault(null))
        assertTrue(
            !CaptureLists.supportsFocusModeOrDefault(
                CameraModel(name = "Osmo Nano", family = "nano", supportsFocusMode = false, captureProfile = com.opencapture.opencine.vocabulary.CameraCaptureProfile(supportsFocusMode = false)),
            ),
        )
        assertTrue(
            !CaptureLists.shouldRefreshFocusTrack(
                CameraStatus(focusTrack = -1),
                supportsFocus = CaptureLists.supportsFocusMode("Osmo Nano"),
            ),
        )
    }

    @Test
    fun holdFpsIgnoresHundredthTick() {
        assertEquals("25.00", LiveChromeReadout.holdFPS("25.13", "25.00"))
        assertEquals("25.00", LiveChromeReadout.holdFPS("24.70", "25.00"))
        assertEquals("25.50", LiveChromeReadout.holdFPS("25.50", "25.00"))
        assertEquals("RECOV", LiveChromeReadout.holdFPS("RECOV", "25.00"))
        assertEquals("25.00", LiveChromeReadout.holdFPS("25.00", "LINK"))
        assertEquals("\u2014", LiveChromeReadout.holdFPS("\u2014", "25.00"))
    }

    @Test
    fun fpsChipLabelIsLiveViewHealthNotRecordFps() {
        data class Chip(
            val why: String,
            val connection: ConnectionPhase,
            val recovering: Boolean,
            val measured: Double,
            val expected: String,
        )
        val live = ConnectionPhase.LIVE
        val cases = listOf(
            Chip("idle hides fps", ConnectionPhase.IDLE, false, 0.0, "\u2014"),
            Chip("live without frames", live, false, 0.0, "LINK"),
            Chip("recovering", live, true, 12.0, "RECOV"),
            Chip("failed", ConnectionPhase.FAILED, false, 25.0, "FAIL"),
            Chip("live with frames", live, false, 25.0, "25.00"),
        )
        for (case in cases) {
            assertEquals(
                case.expected,
                LiveViewLink.fpsChipLabel(
                    connection = case.connection,
                    recovering = case.recovering,
                    formattedFPS = "25.00",
                    measuredFPS = case.measured,
                ),
                case.why,
            )
        }
    }

    @Test fun fpsTelemetryAndPickerReseatingCannotReplaceTheChosenAngle() {
        var preferred = 180.0
        for ((fps, shutter) in listOf(24 to 48, 60 to 48, 60 to 120, 30 to 120, 30 to 60)) {
            val status = CameraStatus(
                fps = fps, shutterDenom = shutter, expoMode = CameraCommands.EXPO_MANUAL,
                availableShutterDenoms = listOf(24, 48, 50, 60, 120),
            )
            val seat = CaptureLists.reseatShutterAngle(status, preferred)
            // This is the same assignment performed by LiveControlSheet.applySeat.
            preferred = seat.preferredAngle
            assertEquals(180.0, preferred, "FPS=$fps with delayed shutter=1/$shutter")
            assertFalse(seat.persistAngle, "Telemetry is not an operator preference edit")
        }
    }
}
