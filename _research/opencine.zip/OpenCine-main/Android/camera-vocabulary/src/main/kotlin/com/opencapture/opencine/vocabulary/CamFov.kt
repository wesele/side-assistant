package com.opencapture.opencine.vocabulary

import com.opencapture.opencine.core.CameraValuePin
import java.util.Locale
import kotlin.math.abs
import kotlin.math.round
import kotlin.math.roundToInt

/**
 * iOS `CamFov`. Operator 1×…12× from `cam_fov` `@0` + lens `@14`.
 *
 * `cam_fov / 1024` runs backwards and jumps at the 3× hop; never show that
 * as the chip number. Writes are slider `0A 4E` + lens (217 / 651 / 1302 / 2604).
 */
object CamFov {
    const val MIN_FACTOR = 1.0
    const val MAX_FACTOR = 12.0
    val JUMPS: List<Double> = listOf(1.0, 3.0, 6.0, 12.0)

    const val RAW_AT_1X = 12_287
    const val RAW_AT_3X = 9_368
    const val RAW_AT_12X = 2_341

    const val LENS_1X = 217
    const val LENS_3X = 651
    const val LENS_6X = 1_302
    const val LENS_12X = 2_604

    const val SLEW_TELE = 100
    const val SLEW_WIDE = 300
    /** iOS `CameraSetMailbox.zoomCoalesceHold`; Mimo pinch is 20 Hz. */
    const val SLIDER_COALESCE_MS = 50L
    /** Camera can pause HEVC while the lens slews. Same 4 s as AF-C. */
    const val VIDEO_GRACE_SEC = 4.0

    fun shouldHoldWatchdog(secondsSinceSet: Double?, pinchActive: Boolean = false): Boolean {
        if (pinchActive) return true
        val s = secondsSinceSet ?: return false
        return s >= 0.0 && s < VIDEO_GRACE_SEC
    }

    fun factor(raw: Int): Double {
        if (raw == 0) return MIN_FACTOR
        if (raw >= RAW_AT_1X) return MIN_FACTOR
        if (raw <= RAW_AT_12X) return MAX_FACTOR
        if (raw >= RAW_AT_3X) {
            val t = (RAW_AT_1X - raw).toDouble() / (RAW_AT_1X - RAW_AT_3X).toDouble()
            return clamp(MIN_FACTOR + t * 2)
        }
        val t = (RAW_AT_3X - raw).toDouble() / (RAW_AT_3X - RAW_AT_12X).toDouble()
        return clamp(3 + t * 9)
    }

    fun factorFromLens(lens: Int): Double? {
        if (lens <= 0) return null
        if (lens <= LENS_1X) return MIN_FACTOR
        if (lens >= LENS_12X) return MAX_FACTOR
        if (lens <= LENS_3X) {
            val t = (lens - LENS_1X).toDouble() / (LENS_3X - LENS_1X).toDouble()
            return clamp(MIN_FACTOR + t * 2)
        }
        val t = (lens - LENS_3X).toDouble() / (LENS_12X - LENS_3X).toDouble()
        return clamp(3 + t * 9)
    }

    fun clamp(factor: Double, max: Double = MAX_FACTOR): Double =
        factor.coerceIn(MIN_FACTOR, max)

    /**
     * The remembered chip stop, kept inside what the current FORMAT allows.
     *
     * A FORMAT change can drop the ceiling under a stop the operator already picked; 2.7K offers
     * 3×, 4K stops at 2×. The stop is only the readout's last resort, before any `cam_fov` lands,
     * but even then it must not advertise a factor this FORMAT would refuse.
     */
    fun stopWithinCycle(stop: Double, stops: List<Double>): Double =
        clamp(stop, stops.lastOrNull() ?: MIN_FACTOR)

    /**
     * The line to show when a new FORMAT pulls the zoom ceiling out from under the factor the
     * operator is already holding.
     *
     * The body does not refuse: it walks the lens back to whatever the new capture size allows, so
     * without a word the chip just falls to 1x and nothing on screen says why. [size] is
     * [VideoResolution.sizeTitle]. Null while the held factor still fits, which is the usual case.
     */
    fun ceilingNote(size: String, held: Double, stops: List<Double>): String? {
        val ceiling = stops.lastOrNull() ?: return null
        if (displayTenths(held) <= ceiling + 0.05) return null
        return "$size caps zoom at ${displayLabel(ceiling)}"
    }

    fun lensPosition(factor: Double): Int {
        val f = clamp(factor)
        if (abs(f - MIN_FACTOR) < 0.001) return LENS_1X
        if (abs(f - MAX_FACTOR) < 0.001) return LENS_12X
        if (f <= 3) return lerpLens(LENS_1X, LENS_3X, (f - MIN_FACTOR) / 2)
        return lerpLens(LENS_3X, LENS_12X, (f - 3) / 9)
    }

    fun displayLabel(raw: Int): String = displayLabel(factor(raw))

    fun displayLabel(factor: Double): String {
        val shown = displayTenths(factor)
        if (abs(shown - MAX_FACTOR) < 0.05) return "12×"
        val nearest = shown.roundToInt()
        if (abs(shown - nearest) < 0.05 && nearest in 1..12) return "${nearest}×"
        return String.format(Locale.US, "%.1f×", shown)
    }

    fun nextJump(from: Double, stops: List<Double> = JUMPS): Double {
        val cycle = if (stops.isEmpty()) JUMPS else stops
        for (stop in cycle) {
            if (from < stop - 0.05) return stop
        }
        return cycle[0]
    }

    /** Next lower chip stop. Stays on the wide end; does not wrap to tele. */
    fun previousJump(from: Double, stops: List<Double> = JUMPS): Double {
        val cycle = if (stops.isEmpty()) JUMPS else stops
        for (stop in cycle.asReversed()) {
            if (from > stop + 0.05) return stop
        }
        return cycle[0]
    }

    sealed class ChipWrite {
        data class Lens(val position: Int) : ChipWrite()
        data class Slew(val value: Int) : ChipWrite()
    }

    fun chipWrite(forJump: Double): ChipWrite? =
        when {
            abs(forJump - 1) < 0.1 -> ChipWrite.Lens(LENS_1X)
            abs(forJump - 2) < 0.1 -> ChipWrite.Lens(lensPosition(2.0))
            abs(forJump - 3) < 0.1 -> ChipWrite.Lens(LENS_3X)
            abs(forJump - 4) < 0.1 -> ChipWrite.Lens(lensPosition(4.0))
            abs(forJump - 6) < 0.1 -> ChipWrite.Lens(LENS_6X)
            abs(forJump - MAX_FACTOR) < 0.1 -> ChipWrite.Lens(LENS_12X)
            else -> null
        }

    fun displayTenths(factor: Double): Double = round(clamp(factor) * 10.0) / 10.0

    fun pinchFactor(anchor: Double, magnification: Double, max: Double = MAX_FACTOR): Double =
        clamp(anchor * magnification, max)

    /** Right trigger minus left trigger onto −1…1 (positive = zoom in). */
    fun triggerZoomAxis(left: Double, right: Double): Double {
        val l = left.coerceIn(0.0, 1.0)
        val r = right.coerceIn(0.0, 1.0)
        return r - l
    }

    /** Full R2/L2: this many operator × per second. Light press crawls. */
    const val ZOOM_RATE_PER_SECOND = 3.0
    const val ZOOM_STEP_INTERVAL_MS = 50L

    /** Hold-to-zoom: `y` is R2−L2 (−1…1). Integrate `dt` seconds of analog rate. */
    fun zoomStep(current: Double, y: Double, dt: Double, max: Double = MAX_FACTOR): Double {
        if (dt <= 0.0) return clamp(current, max)
        val t = CameraCommands.gimbalLinearThrow(y.toFloat()).toDouble()
        return clamp(current + t * ZOOM_RATE_PER_SECOND * dt, max)
    }

    fun pinchLens(factor: Double): Int = lensPosition(factor)

    fun readout(
        live: Double?,
        preview: Double?,
        fallback: Double,
        optimistic: Double? = null,
    ): Double = displayTenths(continuousReadout(live, preview, fallback, optimistic))

    /** Unrounded lens factor for the zoom disc. The chip still uses [readout]. */
    fun continuousReadout(
        live: Double?,
        preview: Double?,
        fallback: Double,
        optimistic: Double? = null,
    ): Double {
        if (preview != null) return clamp(preview)
        if (optimistic != null) return clamp(optimistic)
        if (live != null) return clamp(live)
        return clamp(fallback)
    }

    fun hybridFactor(raw: Int, lens: Int?): Double? {
        if (lens != null) factorFromLens(lens)?.let { return it }
        return if (raw == 0) null else factor(raw)
    }

    /**
     * Confirmation test for the chip pin ([CameraValuePin]): the live factor comes back off a lens
     * position and lands a hair off what was asked, so exact equality would never release the pin.
     */
    fun matches(live: Double, target: Double): Boolean =
        abs(displayTenths(live) - displayTenths(target)) < 0.15

    /**
     * D-Log2 rejects every zoom SET. Hop on the first step off 1×.
     * `current` is unpinned live color, not an optimistic HUD pin.
     */
    fun colorModeForZoom(factor: Double, current: Int): Int? {
        if (current != CameraCommands.COLOR_DLOG2) return null
        return if (factor > MIN_FACTOR) CameraCommands.COLOR_DLOG else null
    }

    /** Hold 0xB8 until D-Log2→D-Log is on the body, not only until the color ACK. */
    fun holdZoomWrite(factor: Double, current: Int, hopPending: Boolean): Boolean {
        if (hopPending) return true
        return colorModeForZoom(factor, current) != null
    }

    /** Body will not change color while rolling, so D-Log2 cannot leave 1×. */
    fun zoomNeedsColorHopWhileRecording(
        factor: Double,
        current: Int,
        isRecording: Boolean,
    ): Boolean = isRecording && colorModeForZoom(factor, current) != null

    fun shouldRestoreDLog2(factor: Double): Boolean = displayTenths(factor) <= 1.05

    fun absorb(status: CameraStatus): CameraStatus {
        val factor = hybridFactor(status.zoomFactorRaw, status.zoomLens.takeIf { it >= 0 })
        return if (factor == status.zoomFactor) status else status.copy(zoomFactor = factor)
    }

    private fun lerpLens(a: Int, b: Int, t: Double): Int {
        val u = t.coerceIn(0.0, 1.0)
        return (a + u * (b - a)).roundToInt()
    }
}
