package com.opencapture.opencine.dji

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log

import com.opencapture.opencine.motion.GimbalProgram
import com.opencapture.opencine.vocabulary.ApertureStrategy
import com.opencapture.opencine.vocabulary.CameraCommands
import com.opencapture.opencine.vocabulary.CameraModel
import com.opencapture.opencine.vocabulary.CameraStatus
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.random.Random
import com.opencapture.opencine.media.AccessUnitDiscontinuity
import com.opencapture.opencine.media.CompressedAccessUnitAdmission
import com.opencapture.opencine.media.LivePipelineCadence
import com.opencapture.opencine.media.FeedIncidentIngress
import com.opencapture.opencine.media.FeedIngressMetrics

internal fun isForwardReliableCursor(current: Int, candidate: Int): Boolean {
    val delta = (candidate - current) and 0xFFFF
    return delta != 0 && delta < 0x8000
}

/** Latest-value native stream. Scheduling and writes run on one serial TX executor.
 * Caller operations never hold this lock across a write, so STOP can fence queued work immediately.
 */
internal class NativeCurveDispatch(
    private val nowMs: () -> Long,
    private val schedule: (Long, () -> Unit) -> Unit,
    private val send: (ByteArray) -> Unit,
) {
    private val lock = Any()
    private var generation = 0L
    private var pending: Pair<ByteArray, Long>? = null
    private var drainQueued = false
    private var lastCompletedAt: Long? = null
    private var lastPayload: ByteArray? = null

    fun note(payload: ByteArray) {
        synchronized(lock) {
            pending = payload.copyOf() to nowMs()
            if (!drainQueued) enqueueLocked(generation, 0)
        }
    }

    fun clear() {
        synchronized(lock) {
            generation += 1
            pending = null
            drainQueued = false
            lastPayload = null
        }
    }

    private fun enqueueLocked(token: Long, delay: Long) {
        drainQueued = true
        schedule(delay) { drain(token) }
    }

    private fun drain(token: Long) {
        val payload = synchronized(lock) {
            if (token != generation) return
            val next = pending
            if (next == null || nowMs() - next.second > 120 ||
                lastPayload?.contentEquals(next.first) == true) {
                pending = null
                drainQueued = false
                return
            }
            val remaining = lastCompletedAt?.let { 40 - (nowMs() - it) } ?: 0
            if (remaining > 0) {
                enqueueLocked(token, remaining)
                return
            }
            pending = null
            drainQueued = false
            next.first
        }
        // A clear may race this already executing write. Serial TX orders it before STOP;
        // subsequent queued drains carry the invalidated generation and cannot send after STOP.
        send(payload)
        synchronized(lock) {
            lastCompletedAt = nowMs()
            if (token == generation) lastPayload = payload
        }
    }
}

/** One queued ACK-pump tick; its TX callback reads current stick state, never captured axes. */
internal class CoalescedGimbalTick(
    private val schedule: (() -> Unit) -> Unit,
    private val tick: () -> Unit,
) {
    private val lock = Any()
    private var generation = 0L
    private var pending = false

    fun request() {
        synchronized(lock) {
            if (pending) return
            pending = true
            val token = generation
            schedule {
                synchronized(lock) {
                    if (token != generation) return@schedule
                    pending = false
                }
                tick()
            }
        }
    }

    fun invalidate() {
        synchronized(lock) {
            generation += 1
            pending = false
        }
    }
}

/** Closing fences callers synchronously, but STOP and socket teardown stay on serial TX. */
internal class DatalinkCloseSequence(
    private val closed: AtomicBoolean,
    private val fence: () -> Unit,
    private val enqueue: (() -> Unit) -> Unit,
    private val stop: () -> Unit,
    private val teardown: () -> Unit,
) {
    fun close() {
        if (!closed.compareAndSet(false, true)) return
        fence()
        enqueue {
            try {
                runCatching { stop() }
            } finally {
                teardown()
            }
        }
    }
}

/** iOS `DatalinkError.noHandshake`; recoverable, never `error()` / crash. */
class DatalinkHandshakeException(message: String) : IOException(message)

/** Session history survives replacement UDP counters and held-picture reconnects. */
class LiveSessionVideoHistory {
    private val receivedVideo = AtomicBoolean(false)
    fun noteVideoPacket() { receivedVideo.set(true) }
    fun reset() { receivedVideo.set(false) }
    fun hadVideo(endpointPackets: Int, endpointVideoAgeMs: Long?): Boolean =
        receivedVideo.get() || LiveViewEnablePolicy.hadVideo(endpointPackets, endpointVideoAgeMs)
}

/**
 * DUML-over-UDP datalink. Byte builders live in Swift; this owns the socket,
 * session/seq counters, 40 Hz ACK pump, and HEVC depacketizer handle.
 */
class DatalinkDriver(
    private val joiner: CameraNetworkPath,
    private val port: Int,
    private val tcpPoke: Boolean,
    private val pairingToken: String,
    private val cadence: LivePipelineCadence = LivePipelineCadence(),
    private val videoHistory: LiveSessionVideoHistory = LiveSessionVideoHistory(),
    private val cameraModel: CameraModel = CameraModel.default,
    private val debugVideoPacketAdmission: (() -> Boolean)? = null,
    /** Camera SoftAP by default; Multiview passes the verified shared-Wi-Fi address. */
    private val host: String = CAMERA_HOST,
) {
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val sendLock = Any()
    private val txThread = AtomicReference<Thread?>()
    private val sendExecutor = Executors.newSingleThreadScheduledExecutor {
        Thread(it, "opc.datalink.tx").also(txThread::set)
    }
    private val ackDispatch = CoalescedGimbalTick(::enqueueTx, ::sendWindowAckOnTx)
    private val nativeCurveDispatch = NativeCurveDispatch(
        nowMs = SystemClock::elapsedRealtime,
        schedule = { delay, action ->
            if (!sendExecutor.isShutdown) {
                runCatching { sendExecutor.schedule(action, delay, TimeUnit.MILLISECONDS) }
            }
        },
        send = { payload ->
            if (!closed.get()) sendDumlLocked(0x04, CameraCommands.CMD_GIMBAL_ANGLE, payload, 0,
                CameraCommands.RX_GIMBAL, CameraCommands.SENDER_APP)
        },
    )
    private val nativeProgramUsed = AtomicBoolean(false)
    private var closeNeedsStickRest = false
    private val nativeFeedbackEpoch = AtomicLong(0)
    private val ingressMetrics = DatalinkIngressMetrics(nativeFeedbackEpoch)
    private val nativeProgramFeedback = AtomicReference<Pair<Long, NativeGimbalFeedback>?>(null)
    private val nativeZoomStatus = AtomicReference<Pair<Long, NativeProgramZoomObservation>?>(null)
    private val nativeZoomOwned = AtomicBoolean(false)
    private val lastNativeZoomWriteAt = AtomicLong(0)
    val lastProgrammedZoomAt: Long? get() = lastNativeZoomWriteAt.get().takeIf { it > 0L }
    private val nativeProgramProgress = AtomicReference<(() -> Unit)?>(null)
    private val nativeProgramProgressQueued = AtomicBoolean(false)
    private val nativeProgramRunner = NativeGimbalProgramRunner(
        now = { SystemClock.elapsedRealtimeNanos() / 1e9 },
        schedule = { delay, action ->
            if (!sendExecutor.isShutdown) {
                runCatching { sendExecutor.schedule(action, (delay * 1e9).toLong(), TimeUnit.NANOSECONDS) }
            }
        },
        feedback = ::readNativeProgramFeedback,
        send = { target, duration ->
            val payload = CameraCommands.gimbalTimedTarget(target, duration)
            if (closed.get() || payload == null || !nativeGimbalTargetIsSafe(target,
                    readNativeProgramFeedback(), SystemClock.elapsedRealtimeNanos() / 1e9)) false else {
                sendDumlLocked(0x04, CameraCommands.CMD_GIMBAL_ANGLE, payload, 0,
                    CameraCommands.RX_GIMBAL, CameraCommands.SENDER_APP)
            }
        },
        stop = {
            if (!closed.get()) sendDumlLocked(0x04, CameraCommands.CMD_GIMBAL_ANGLE,
                CameraCommands.gimbalTimedStop(), 0, CameraCommands.RX_GIMBAL, CameraCommands.SENDER_APP)
        },
        zoomFailure = ::programmedZoomFailure,
        zoomTargetFailure = { factor, program -> nativeProgramZoomFailure(program, cameraModel, readNativeZoomStatus(), factor) },
        sendZoom = { lens, program ->
            if (closed.get() || programmedZoomFailure(program) != null) false else {
                sendDumlLocked(0x02, CameraCommands.CMD_ZOOM, CameraCommands.zoomLens(lens), CameraCommands.FLAG_REQUEST,
                    CameraCommands.RX_CAMERA, CameraCommands.SENDER_APP).also { sent ->
                    if (sent) {
                        nativeZoomOwned.set(true)
                        lastNativeZoomWriteAt.set(SystemClock.elapsedRealtime())
                    }
                }
            }
        },
        stopZoom = {
            if (nativeZoomOwned.getAndSet(false) && !closed.get()) {
                sendDumlLocked(0x02, CameraCommands.CMD_ZOOM, CameraCommands.zoomStop(), CameraCommands.FLAG_REQUEST,
                    CameraCommands.RX_CAMERA, CameraCommands.SENDER_APP)
            }
        },
        noteZoomPause = { now ->
            nativeZoomStatus.updateAndGet { current ->
                current?.takeIf { it.first == nativeFeedbackEpoch.get() }?.let { it.first to it.second.notePause(now) }
            }
        },
        zoomResumeReady = { readNativeZoomObservation().canResume(it) },
        usesHighRateZoom = CameraModel.looksLikePocket4Pro(cameraModel.name),
        sendNativeZoom = { command, program ->
            val now = SystemClock.elapsedRealtimeNanos() / 1e9
            if (closed.get() || programmedZoomFailure(program) != null ||
                nativeProgramZoomFeedbackFailure(readNativeZoomObservation().receivedAt, now) != null) false else {
                sendDumlLocked(0x02, CameraCommands.CMD_ZOOM, command.payload, CameraCommands.FLAG_REQUEST,
                    CameraCommands.RX_CAMERA, CameraCommands.SENDER_APP).also { sent ->
                    if (sent) {
                        nativeZoomOwned.set(true)
                        lastNativeZoomWriteAt.set(SystemClock.elapsedRealtime())
                    }
                }
            }
        },
    )
    /** One hop at a time; admission already caps pending AUs. Unbounded execute would replay a GOP. */
    private val decodeExecutor = Executors.newSingleThreadExecutor { Thread(it, "opc.hevc") }
    private var socket: DatagramSocket? = null
    private val pokeLock = Any()
    private var pokeSocket: Socket? = null
    private var receiver: Thread? = null
    private var ackThread: Thread? = null

    private var sessionId = 0
    private var baseSeq = 0
    private var udpSeq = 0
    private var dumlSeq = 0xA000
    private var cmdCounter = 0
    /** Latest video transport seq; ACK pump must echo this (iOS `videoAssembler.peerCursor`). */
    private val peerCursor = AtomicInteger(0)
    private val hasVideoSeq = AtomicBoolean(false)
    /** Shared reliable command/download window. Mimo ACK group 1. */
    private val ackedDataCursor = AtomicInteger(0)
    private val hasAckedData = AtomicBoolean(false)
    /** Third ACK group, seeded from 34-byte pktType 0x01 telemetry. */
    private val extraCursor = AtomicInteger(0)
    private val hasExtra = AtomicBoolean(false)
    private val handshakeAdmission = DatalinkHandshakeAdmission()
    private val handshakeAcked: Boolean get() = handshakeAdmission.initialCommandSequence() != null
    @Volatile private var liveViewEnabled = false
    private val mediaBrowsing = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private var depacketizer = 0L
    private val inboundLogs = AtomicInteger(0)
    private val rawVideoPackets = AtomicInteger(0)
    private val leftoverVideoPackets = AtomicInteger(0)
    private val loggedLeftoverGop = AtomicBoolean(false)
    private val lastVideoElapsed = AtomicLong(0)
    private val lastStatusElapsed = AtomicLong(0)
    private val lastAccessUnitElapsed = AtomicLong(0)
    private val lastRebuildElapsed = AtomicLong(0)
    private val lastEnableSentElapsed = AtomicLong(0)
    private val lastLiveViewReplyElapsed = AtomicLong(0)
    @Volatile private var rebuilding = false
    private val sendFailLogs = AtomicInteger(0)
    private val socketHealth = DatalinkSocketHealth()
    private val gimbalLock = Any()
    private val gimbalTickDispatch = CoalescedGimbalTick(::enqueueTx, ::tickGimbalStickOnTx)
    @Volatile private var gimbalAxis0 = CameraCommands.GIMBAL_STICK_CENTER
    @Volatile private var gimbalAxis1 = CameraCommands.GIMBAL_STICK_CENTER
    @Volatile private var gimbalStickHeld = false
    @Volatile private var gimbalSendRest = false
    private val lastGimbalStickElapsed = AtomicLong(0)

    var onStatusFrame: ((DumlFrame) -> Unit)? = null
    val mediaIngress = DjiAndroidMediaIngressSlot()
    var onAccessUnit: ((ByteArray, Long) -> Unit)? = null
    var onReferenceDiscontinuity: ((Long) -> Unit)? = null
    var onVideoEpochChanged: ((Long) -> Unit)? = null
    private val lastIncompleteDropped = AtomicInteger(0)
    private val admission = CompressedAccessUnitAdmission()

    val videoPackets: Int get() = rawVideoPackets.get()
    val droppedIncomplete: Int
        get() = if (depacketizer != 0L && DjiNative.isAvailable) DjiNative.depacketizerDropped(depacketizer) else 0
    val pendingAccessUnits: Int get() = admission.pendingCount
    val pendingAccessUnitBytes: Int get() = admission.queuedBytes
    val admissionDrops: Int get() = admission.drops
    val admissionIrapSeen: Int get() = admission.irapSeen
    val admissionParameterSetsSeen: Int get() = admission.parameterSetsSeen
    val admissionGateDrops: Int get() = admission.gateDrops
    val admissionAwaitingRandomAccess: Boolean get() = admission.isAwaitingRandomAccess
    val lastVideoPacketAt: Long? get() = lastVideoElapsed.get().takeIf { it > 0 }
    val lastStatusAt: Long? get() = lastStatusElapsed.get().takeIf { it > 0 }
    fun ingressSnapshot(now: Double): FeedIncidentIngress? =
        if (closed.get()) null else ingressMetrics.snapshot(now, liveViewEnabled)

    private fun recordIngress(event: FeedIngressMetrics.Event, generation: Long) {
        if (!closed.get()) {
            ingressMetrics.record(event, SystemClock.elapsedRealtime() / 1000.0, generation)
        }
    }
    val lastAccessUnitAt: Long? get() = lastAccessUnitElapsed.get().takeIf { it > 0 }
    val lastRebuildAt: Long? get() = lastRebuildElapsed.get().takeIf { it > 0 }
    val isTcpPokeReady: Boolean get() = synchronized(pokeLock) {
        pokeSocket?.let { it.isConnected && !it.isClosed } == true
    }
    val isRebuilding: Boolean get() = rebuilding
    val needsRebuild: Boolean get() = socketHealth.needsRebuild
    fun setMediaBrowsing(browsing: Boolean) {
        mediaBrowsing.set(browsing)
    }

    val isClosed: Boolean get() = closed.get()

    /**
     * iOS `DatalinkDriver.open(afterHandshake:)`: handshake, register,
     * subscribe, 40 Hz ACK pump, then `0x09/0xa8`, then ingest 0x02.
     * Do not sit on a 2 s ACK settle; that drops the camera GOP.
     */
    fun open(identityOnly: Boolean = false, afterHandshake: (() -> Unit)? = null) {
        check(DjiNative.isAvailable) { "Swift core is not loaded" }
        check(!closed.get()) { "datalink closed" }
        val lifetime = DatalinkOpenLoop(SystemClock::elapsedRealtime,
            LiveViewEnablePolicy.handshakeOpenTimeoutMs(), closed::get)
        onTxBlocking { discardUdp(keepPoke = true) }
        lifetime.ensureActive()
        if (tcpPoke) ensurePoke(lifetime)
        lifetime.ensureActive()
        liveViewEnabled = false
        loggedLeftoverGop.set(false)
        inboundLogs.set(0)
        rawVideoPackets.set(0)
        leftoverVideoPackets.set(0)
        lastIncompleteDropped.set(0)
        lastVideoElapsed.set(0)
        lastStatusElapsed.set(0)
        lastAccessUnitElapsed.set(0)
        lastEnableSentElapsed.set(0)
        lastLiveViewReplyElapsed.set(0)
        sendFailLogs.set(0)
        if (depacketizer == 0L) depacketizer = DjiNative.depacketizerCreate()
        else runCatching { DjiNative.depacketizerReset(depacketizer) }

        var rebinds = 0
        var keepBind = false
        lifetime.run {
            lifetime.ensureActive()
            if (!keepBind) {
                onTxBlocking {
                    lifetime.ensureActive()
                    resetHandshakeSession()
                    startUdpReceiver()
                }
            }
            keepBind = false
            val handshake = DjiNative.handshakePayload(baseSeq) ?: error("handshake payload")
            for (send in 1..HANDSHAKE_SENDS_PER_BIND) {
                lifetime.ensureActive()
                if (handshakeAcked) break
                val receiveArmed = running.get() && receiver?.isAlive == true
                val connectionReady = socket != null && !closed.get()
                if (!LiveViewEnablePolicy.canSendHandshake(receiveArmed, connectionReady)) {
                    Log.i(
                        TAG,
                        "datalink: handshake UDP not ready reader=$receiveArmed — will rebind",
                    )
                    break
                }
                sendRaw(0x00, handshake)
                val deadline = SystemClock.elapsedRealtime() + HANDSHAKE_SEND_INTERVAL_MS
                while (SystemClock.elapsedRealtime() < deadline) {
                    lifetime.ensureActive()
                    if (handshakeAcked) break
                    Thread.sleep(HANDSHAKE_POLL_MS)
                }
                if (handshakeAcked) break
            }
            if (handshakeAcked) {
                Log.i(TAG, "datalink: handshake acked session=$sessionId")
                udpSeq = checkNotNull(handshakeAdmission.initialCommandSequence())
                sendAck()
                // Multiview registers only after the LAN peer proves it is the
                // camera paired over BLE ([completeRegistration]).
                if (!identityOnly) {
                    register()
                    subscribe()
                }
                startAckPump()
                // Mimo 20260828: HEVC 17 ms after DHCP, 0xa8 at +3 s. Arm ingest
                // on handshake ack; do not wait subscribe settle or enable.
                armLiveVideo()
                // Subscribe is fire-and-forget. Enable in the same 9 ms burst is
                // ignored (iOS hops to MainActor after subscribe; Mimo comes
                // from gallery). Always wait the settle; leftover 0x01 must
                // not collapse it to 0 ms.
                if (!identityOnly) settleAfterSubscribe(SUBSCRIBE_SETTLE_MS)
                // Stay on this IO thread. Posting 0x09/0xa8 to Main trips
                // StrictMode (NetworkOnMainThread) and the camera never
                // starts HEVC; pkts=0, WAITING FOR LIVE VIEW.
                lifetime.ensureActive()
                afterHandshake?.invoke()
                armLiveVideo()
                return@run true
            }
            val inbound = inboundLogs.get()
            val evidence = handshakeAdmission.evidence()
            Log.i(TAG, "datalink: negotiation miss ack=${evidence.acknowledged} window=${evidence.windowKnown}")
            when (
                LiveViewEnablePolicy.handshakeTimeoutStep(
                    pathReady = joiner.isProcessBound(),
                    rebindsUsed = rebinds,
                    inboundDatagrams = inbound,
                    rebindLimit = HANDSHAKE_REBIND_LIMIT,
                )
            ) {
                LiveViewEnablePolicy.HandshakeTimeoutStep.KEEP_SOCKET -> {
                    Log.i(TAG, "datalink: handshake miss inbound=$inbound — keep UDP, retry sends")
                    keepBind = true
                    return@run false
                }
                LiveViewEnablePolicy.HandshakeTimeoutStep.FAIL -> {
                    Log.i(TAG, "datalink: handshake never acked inbound=$inbound")
                    throw handshakeTimeoutFailure()
                }
                LiveViewEnablePolicy.HandshakeTimeoutStep.REBIND_UDP -> {
                    rebinds += 1
                    Log.i(
                        TAG,
                        "datalink: handshake miss inbound=$inbound — SoftAP up, rebind UDP " +
                            "($rebinds/$HANDSHAKE_REBIND_LIMIT)",
                    )
                    onTxBlocking { discardUdp(keepPoke = true) }
                    Thread.sleep(HANDSHAKE_RETRY_PAUSE_MS)
                }
            }
            false
        }
    }

    /**
     * The camera stops video ~10 s after the last registration while telemetry
     * continues and ignores enables until it sees one again. Re-registering on the
     * same socket restarted video with no new handshake (Pocket 4 Pro, 2026-09-22).
     */
    fun reRegister() {
        enqueueTx {
            if (!rebuilding && handshakeAcked) {
                sendCommandLocked(DjiNative.CMD_APP_DEVICE_INFO, null)
                sendCommandLocked(DjiNative.CMD_APP_PRESENCE, null)
                sendWindowAckOnTx()
            }
        }
    }

    /** iOS `completeRegistration`: only after station discovery verifies the BLE identity. */
    fun completeRegistration() {
        if (closed.get()) return
        register()
        subscribe()
    }

    fun keepalive() {
        enqueueTx {
            // Check at emission, since a repair can begin after this tick queued.
            // open() owns registration and ACKs until the endpoint is negotiated.
            if (!rebuilding && handshakeAcked) {
                sendCommandLocked(DjiNative.CMD_APP_PRESENCE, null)
                sendWindowAckOnTx()
            }
        }
    }

    private fun settleAfterSubscribe(timeoutMs: Long) {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline) {
            Thread.sleep(10)
        }
        val status = if (lastStatusElapsed.get() > 0) 1 else 0
        Log.i(TAG, "datalink: subscribe settled ${timeoutMs}ms status=$status")
    }

    fun startLiveView(receiver: Int = CameraCommands.LIVE_VIEW_ENABLE_RECEIVER_POCKET) {
        val extra = receiver.toString()
        if (receiver == CameraCommands.LIVE_VIEW_ENABLE_RECEIVER_POCKET) {
            sendCommand(DjiNative.CMD_LIVE_VIEW_ENABLE, extra)
        } else {
            sendDuml(
                cmdSet = 0x09,
                cmdId = CameraCommands.CMD_LIVE_VIEW,
                payload = CameraCommands.liveViewEnablePayload(),
                receiver = receiver,
            )
        }
        lastEnableSentElapsed.set(SystemClock.elapsedRealtime())
        Log.i(
            TAG,
            "datalink: sent 0x09/0xa8 rcv=0x${receiver.toString(16)} " +
                "videoPkts=$videoPackets tcp=${if (isTcpPokeReady) 1 else 0}",
        )
        // Accept 0x02 on this write, not after an ACK. Recover enables must
        // also ingest the next VPS (iOS `startLiveView` does not wait).
        armLiveVideo()
    }

    /** iOS `DatalinkDriver.exitPlayback`. Live enable ACKs E0 while the body is in playback. */
    fun exitPlayback() {
        sendCommand(DjiNative.CMD_EXIT_PLAYBACK)
        Log.i(TAG, "datalink: sent exit playback")
    }

    /** iOS `armLiveVideo`: first arm resets leftover GOP; re-arm only raises the gate. */
    fun armLiveVideo() {
        val first = !liveViewEnabled
        if (first && depacketizer != 0L && DjiNative.isAvailable) {
            runCatching { DjiNative.depacketizerReset(depacketizer) }
        }
        liveViewEnabled = true
        loggedLeftoverGop.set(false)
        if (first) Log.i(TAG, "datalink: armed pktType 0x02 ingest")
    }

    /** Nano `0x02/0x09` start/stop. No CMD kind yet; encodeDuml. */
    fun sendNanoGate(start: Boolean) {
        sendDuml(
            cmdSet = 0x02,
            cmdId = CameraCommands.CMD_NANO_GATE,
            payload = CameraCommands.nanoLiveViewGate(start),
        )
    }

    /**
     * A new local UDP port must negotiate a new camera endpoint. Reuse the normal
     * bounded handshake/register/subscribe path, retaining ready TCP 7001 and the
     * caller's decoder. The caller owns one live enable after successful negotiation.
     */
    private fun scheduleAdmissionDrain(receiveEpoch: Long) {
        if (closed.get() || decodeExecutor.isShutdown) {
            admission.releaseScheduledHop(receiveEpoch)
            return
        }
        val enqueuedAt = cadence.queued()
        runCatching {
            decodeExecutor.execute {
                cadence.dequeued(enqueuedAt)
                admission.drain(
                    receiveEpoch,
                    isCurrent = { !closed.get() && receiveEpoch == nativeFeedbackEpoch.get() },
                    onDiscontinuity = { onReferenceDiscontinuity?.invoke(receiveEpoch) },
                    onAccessUnit = { onAccessUnit?.invoke(it, receiveEpoch) },
                )
            }
        }.onFailure {
            cadence.dequeued(enqueuedAt)
            admission.releaseScheduledHop(receiveEpoch)
        }
    }

    fun rebuildUdp() {
        synchronized(this) {
            if (closed.get() || rebuilding) throw DatalinkHandshakeException("datalink repair unavailable")
            if (!joiner.isProcessBound()) throw DatalinkHandshakeException("camera network unavailable")
            rebuilding = true
        }
        lastRebuildElapsed.set(SystemClock.elapsedRealtime())
        try {
            Log.i(TAG, "datalink: rebuilding UDP with fresh handshake (keep TCP 7001)")
            // open() first stops the old ACK/RX and discards the old endpoint,
            // then resets session/window state. It must run off serial TX so
            // handshake writes can progress while this caller waits for replies.
            open()
        } catch (error: Exception) {
            // Cancellation may leave the IO thread interrupted. Queue cleanup
            // without a blocking wait; epoch fencing keeps it off a newer bind.
            enqueueTx { discardUdp(keepPoke = true) }
            throw error
        } finally {
            rebuilding = false
        }
    }

    private fun onTxBlocking(body: () -> Unit) {
        if (Thread.currentThread() === txThread.get()) { body(); return }
        if (closed.get() || sendExecutor.isShutdown) return
        val epoch = nativeFeedbackEpoch.get()
        awaitDatalinkTx(sendExecutor, { !closed.get() && epoch == nativeFeedbackEpoch.get() }, work = body)
    }

    /**
     * Send a CRC-valid DUML request over the datalink. Payloads come from
     * [CameraCommands]; this only wraps [DjiNative.encodeDuml] the same way
     * the predefined command kinds are sent.
     */
    fun sendDuml(
        cmdSet: Int,
        cmdId: Int,
        payload: ByteArray = ByteArray(0),
        flags: Int = CameraCommands.FLAG_REQUEST,
        receiver: Int = CameraCommands.RX_CAMERA,
        sender: Int = CameraCommands.SENDER_APP,
    ) {
        if (closed.get() || !DjiNative.isAvailable) return
        enqueueTx { sendDumlLocked(cmdSet, cmdId, payload, flags, receiver, sender) }
    }

    private fun readNativeProgramFeedback(): NativeGimbalFeedback? =
        nativeProgramFeedback.get()?.takeIf { it.first == nativeFeedbackEpoch.get() }?.second?.let { sample ->
            val zoom = readNativeZoomObservation()
            zoom.status.zoomFactor?.let { sample.copy(pose = sample.pose.copy(zoom = it), zoomReceivedAt = zoom.receivedAt) } ?: sample
        }

    private fun readNativeZoomObservation(): NativeProgramZoomObservation =
        nativeZoomStatus.get()?.takeIf { it.first == nativeFeedbackEpoch.get() }?.second ?: NativeProgramZoomObservation()

    private fun readNativeZoomStatus(): CameraStatus =
        readNativeZoomObservation().status

    fun programmedZoomFailure(program: GimbalProgram): String? =
        nativeProgramZoomFailure(program, cameraModel, readNativeZoomStatus())

    val latestNativeProgramFeedback: NativeGimbalFeedback?
        get() = readNativeProgramFeedback()

    fun startNativeProgram(program: GimbalProgram,
        onProgress: (NativeGimbalProgramRunner.Progress) -> Unit): Long {
        nativeProgramUsed.set(true)
        return nativeProgramRunner.start(program) { progress ->
            if (progress.finished) nativeZoomOwned.set(false)
            // A stalled UI only retains the newest immutable progress snapshot.
            nativeProgramProgress.set { if (nativeProgramRunner.isCurrentProgress(progress)) onProgress(progress) }
            if (nativeProgramProgressQueued.compareAndSet(false, true)) {
                main.post {
                    nativeProgramProgressQueued.set(false)
                    nativeProgramProgress.getAndSet(null)?.invoke()
                }
            }
        }

    }

    fun cancelNativeProgram(token: Long) = nativeProgramRunner.cancel(token)
    fun pauseNativeProgram(token: Long) = nativeProgramRunner.pause(token)
    fun resumeNativeProgram(token: Long) = nativeProgramRunner.resume(token)

    /** Coalesce, deduplicate and pace curve targets on the serial TX executor. */
    fun noteNativeCurveTarget(payload: ByteArray) {
        if (closed.get() || !DjiNative.isAvailable) return
        nativeProgramUsed.set(true)
        nativeCurveDispatch.note(payload)
    }

    fun clearNativeCurveTargets() = nativeCurveDispatch.clear()

    private fun enqueueTx(body: () -> Unit) {
        if (closed.get() || sendExecutor.isShutdown) return
        val epoch = nativeFeedbackEpoch.get()
        runCatching {
            sendExecutor.execute {
                if (!closed.get() && epoch == nativeFeedbackEpoch.get()) body()
            }
        }
    }

    private fun sendDumlLocked(
        cmdSet: Int,
        cmdId: Int,
        payload: ByteArray,
        flags: Int,
        receiver: Int,
        sender: Int,
    ): Boolean {
        synchronized(sendLock) {
            if (socket == null) return false
            val frameBytes =
                DjiNative.encodeDuml(sender, receiver, dumlSeq, flags, cmdSet, cmdId, payload)
                    ?: return false
            cmdCounter = (cmdCounter + 1) and 0xFF
            val routing = DjiNative.routingHeader(udpSeq, cmdCounter, false) ?: return false
            val header =
                DjiNative.transportHeader(0x05, routing.size + frameBytes.size, sessionId, udpSeq)
                    ?: return false
            val sendEpoch = nativeFeedbackEpoch.get()
            val accepted = writeOnNetwork(header + routing + frameBytes)
            if (accepted && cmdSet == 0x00 && cmdId == 0x88) {
                recordIngress(FeedIngressMetrics.Event.RegistrationSubmission, sendEpoch)
            }
            dumlSeq = (dumlSeq + 1) and 0xFFFF
            udpSeq = (udpSeq + 8) and 0xFFFF
            return accepted
        }
    }

    private val closeSequence = DatalinkCloseSequence(
        closed = closed,
        fence = {
            nativeProgramRunner.invalidate()
            retireVideoEpoch()
            nativeProgramFeedback.set(null)
            nativeZoomStatus.set(null)
            nativeProgramProgress.set(null)
            clearNativeCurveTargets()
            synchronized(gimbalLock) {
                gimbalTickDispatch.invalidate()
                closeNeedsStickRest = gimbalStickHeld || gimbalSendRest
                gimbalStickHeld = false
                gimbalSendRest = false
                gimbalAxis0 = CameraCommands.GIMBAL_STICK_CENTER
                gimbalAxis1 = CameraCommands.GIMBAL_STICK_CENTER
            }
            running.set(false)
            liveViewEnabled = false
            onAccessUnit = null
            onReferenceDiscontinuity = null
            onVideoEpochChanged = null
            onStatusFrame = null
            mediaIngress.capture()?.let(mediaIngress::retire)
        },
        // This is the sole send admitted after closed=true. The executor is shut
        // down only by this queued task, after its best-effort STOP has run.
        enqueue = { action -> sendExecutor.execute(action) },
        stop = {
            if (DjiNative.isAvailable) {
                if (nativeProgramUsed.get()) sendDumlLocked(0x04, CameraCommands.CMD_GIMBAL_ANGLE,
                    CameraCommands.gimbalTimedStop(), 0, CameraCommands.RX_GIMBAL, CameraCommands.SENDER_APP)
                if (nativeZoomOwned.getAndSet(false)) sendDumlLocked(0x02, CameraCommands.CMD_ZOOM,
                    CameraCommands.zoomStop(), CameraCommands.FLAG_REQUEST, CameraCommands.RX_CAMERA, CameraCommands.SENDER_APP)
                if (closeNeedsStickRest) synchronized(sendLock) {
                    sendGimbalStickLocked(CameraCommands.GIMBAL_STICK_CENTER, CameraCommands.GIMBAL_STICK_CENTER)
                }
            }
        },
        teardown = {
            discardUdp(keepPoke = false)
            sendExecutor.shutdownNow()
            // Drain queued epoch-fenced callbacks so cadence queue accounting settles.
            decodeExecutor.shutdown()
            if (depacketizer != 0L && DjiNative.isAvailable) {
                DjiNative.depacketizerDestroy(depacketizer)
                depacketizer = 0L
            }
        },
    )

    fun close() = closeSequence.close()

    private fun resetHandshakeSession() {
        sessionId = Random.nextInt(0x1000, 0xFFFE)
        baseSeq = Random.nextInt(0x1000, 0xF000) and 0xFFF8
        udpSeq = 0
        dumlSeq = 0xA000
        cmdCounter = 0
        peerCursor.set(0)
        hasVideoSeq.set(false)
        ackedDataCursor.set(0)
        hasAckedData.set(false)
        extraCursor.set(0)
        hasExtra.set(false)
        handshakeAdmission.reset(nativeFeedbackEpoch.get())
    }

    private fun startUdpReceiver() {
        // Handbook: unbound → Network.bindSocket → bind 0.0.0.0:0 → connect
        // 192.168.2.1:9004. iOS binds DHCP + ephemeral
        // (`NWParameters.requiredLocalEndpoint` port 0). Mimo live-entry uses
        // an ephemeral client port (63270 in mimo-disconnect-20260822). Device
        // logs that actually presented a picture used local=/192.168.2.71:34273
        // (ephemeral). Binding local :9004 accepted handshake + 0x01 and
        // dropped every pktType 0x02 (WAITING FOR LIVE VIEW, videoPkts=0).
        val sock = DatagramSocket(null)
        sock.reuseAddress = true
        sock.soTimeout = 250
        runCatching { sock.receiveBufferSize = 512 * 1024 }
        joiner.bindSocket(sock)
        val bindHost = Inet4Address.getByName(WILDCARD_BIND_HOST)
        sock.bind(InetSocketAddress(bindHost, UDP_BIND_PORT))
        runCatching { sock.connect(InetSocketAddress(InetAddress.getByName(host), port)) }
            .onFailure { Log.w(TAG, "datalink: UDP connect failed — sending unconnected", it) }
        val dhcp = joiner.cameraLocalIPv4() ?: "-"
        val label = if (sock.isConnected) "connected" else "unconnected"
        Log.i(
            TAG,
            "datalink: UDP $label ${if (host == CAMERA_HOST) host else "station"}:$port dhcp=$dhcp " +
                "local=${sock.localSocketAddress} rcvbuf=${sock.receiveBufferSize}",
        )
        socket = sock
        socketHealth.noteReceiverStarted()
        running.set(true)
        val ingressEpoch = nativeFeedbackEpoch.get()
        receiver =
            Thread({ receiveLoop(ingressEpoch) }, "opc.datalink.rx").also { it.isDaemon = true; it.start() }
    }

    /** iOS `startAckPump`: pktType 0x04 every 25 ms on its own loop, latest video seq. */
    private fun startAckPump() {
        if (ackThread?.isAlive == true) return
        ackThread =
            Thread(
                {
                    var flipTicks = 0
                    while (running.get()) {
                        sendWindowAck()
                        tickGimbalStick()
                        flipTicks += 1
                        if (flipTicks >= 40) {
                            flipTicks = 0
                            if (!mediaBrowsing.get()) sendCommand(DjiNative.CMD_GET_SELFIE_FLIP)
                        }
                        try {
                            Thread.sleep(ACK_INTERVAL_MS)
                        } catch (_: InterruptedException) {
                            break
                        }
                    }
                },
                "opc.datalink.ack",
            ).also { it.isDaemon = true; it.start() }
    }

    /** Drop the live UDP socket only. TCP 7001 stays up when [keepPoke] is true. */
    private fun discardUdp(keepPoke: Boolean) {
        if (!closed.get()) nativeProgramRunner.interrupt()
        // Best effort on the retiring socket, before its epoch can be replaced.
        if (nativeZoomOwned.getAndSet(false)) sendDumlLocked(0x02, CameraCommands.CMD_ZOOM,
            CameraCommands.zoomStop(), CameraCommands.FLAG_REQUEST, CameraCommands.RX_CAMERA, CameraCommands.SENDER_APP)
        retireVideoEpoch()
        ackDispatch.invalidate()
        nativeProgramFeedback.set(null)
        nativeZoomStatus.set(null)
        nativeZoomOwned.set(false)
        nativeCurveDispatch.clear()
        synchronized(gimbalLock) {
            gimbalTickDispatch.invalidate()
            gimbalStickHeld = false
            gimbalSendRest = false
            gimbalAxis0 = CameraCommands.GIMBAL_STICK_CENTER
            gimbalAxis1 = CameraCommands.GIMBAL_STICK_CENTER
        }
        liveViewEnabled = false
        running.set(false)
        val rx = receiver
        val ack = ackThread
        receiver = null
        ackThread = null
        runCatching { socket?.close() }
        socket = null
        rx?.interrupt()
        ack?.interrupt()
        runCatching { rx?.join(200) }
        runCatching { ack?.join(200) }
        if (!keepPoke) synchronized(pokeLock) {
            runCatching { pokeSocket?.close() }
            pokeSocket = null
        }
    }

    private fun retireVideoEpoch() {
        val epoch = ingressMetrics.retireGeneration()
        handshakeAdmission.reset(epoch)
        // Fence decoder mutation independently of queue ownership. Never hold
        // admission's lock while waiting for the decoder's existing lock.
        onVideoEpochChanged?.invoke(epoch)
        admission.reset(epoch)
    }

    private fun ensurePoke(lifetime: DatalinkOpenLoop) {
        if (isTcpPokeReady) {
            Log.i(TAG, "datalink: TCP 7001 poke already ready")
            return
        }
        val ready = openDatalinkPoke(
            resource = Socket(),
            ensureActive = lifetime::ensureActive,
            connect = { sock ->
                joiner.bindSocket(sock)
                sock.connect(InetSocketAddress(host, 7001), 2_000)
            },
            initialize = { sock ->
                val frame = DjiNative.command(DjiNative.CMD_SET_PAIRING_PIN, extra = pairingToken)
                sock.getOutputStream().write(frame)
                sock.getOutputStream().flush()
            },
            settle = { Thread.sleep(400) },
            publish = { sock ->
                synchronized(pokeLock) {
                    // close() invalidates lifetime before its queued teardown.
                    // The same lock prevents publication after teardown missed it.
                    lifetime.ensureActive()
                    pokeSocket = sock
                }
            },
            onFailure = { Log.w(TAG, "datalink: TCP 7001 poke failed — trying UDP", it) },
        )
        if (ready) Log.i(TAG, "datalink: TCP 7001 poke ready")
    }

    private fun register() {
        sendCommand(DjiNative.CMD_APP_DEVICE_INFO)
        sendAck()
        sendCommand(DjiNative.CMD_APP_PRESENCE)
        sendAck()
        sendCommand(DjiNative.CMD_GIMBAL_INIT)
        sendAck()
    }

    private fun subscribe() {
        var subId = 0x69DFL
        for (key in subscriptionKeys(cameraModel)) {
            sendCommand(DjiNative.CMD_SUBSCRIBE, "$key\u001f$subId")
            subId += 1
        }
        sendAck()
    }

    private fun sendRaw(pktType: Int, payload: ByteArray) {
        onSendThread {
            synchronized(sendLock) {
                if (socket == null) return@synchronized
                val header =
                    DjiNative.transportHeader(pktType, payload.size, sessionId, udpSeq)
                        ?: return@synchronized
                writeOnNetwork(header + payload)
                udpSeq = (udpSeq + 8) and 0xFFFF
            }
        }
    }

    fun sendCommand(kind: Int, extra: String? = null) {
        if (closed.get()) return
        onSendThread { sendCommandLocked(kind, extra) }
    }

    private fun sendCommandLocked(kind: Int, extra: String?) {
        synchronized(sendLock) {
            if (socket == null) return
            val frameBytes = DjiNative.command(kind, dumlSeq, extra)
            val routing = DjiNative.routingHeader(udpSeq, (cmdCounter + 1) and 0xFF, false) ?: return
            val header =
                DjiNative.transportHeader(0x05, routing.size + frameBytes.size, sessionId, udpSeq)
                    ?: return
            cmdCounter = (cmdCounter + 1) and 0xFF
            val sendEpoch = nativeFeedbackEpoch.get()
            val dispatched = writeOnNetwork(header + routing + frameBytes)
            // Native APP_PRESENCE is 0x00/0x88. This counts local sends, not peer ACKs.
            if (dispatched && kind == DjiNative.CMD_APP_PRESENCE) {
                recordIngress(FeedIngressMetrics.Event.RegistrationSubmission, sendEpoch)
            }
            dumlSeq = (dumlSeq + 1) and 0xFFFF
            udpSeq = (udpSeq + 8) and 0xFFFF
        }
    }

    /** Latest `0x04/0x01` axes. ACK ticks request one coalesced TX read of this state. */
    fun noteGimbalStick(axis0: Int, axis1: Int) {
        if (closed.get()) return
        if (axis0 == CameraCommands.GIMBAL_STICK_CENTER &&
            axis1 == CameraCommands.GIMBAL_STICK_CENTER
        ) {
            restGimbalStick()
            return
        }
        synchronized(gimbalLock) {
            gimbalAxis0 = axis0
            gimbalAxis1 = axis1
            gimbalStickHeld = true
            gimbalSendRest = false
        }
    }

    /** Invalidate queued throws; the next TX tick emits one center packet, then silence. */
    fun restGimbalStick() {
        synchronized(gimbalLock) {
            gimbalTickDispatch.invalidate()
            gimbalAxis0 = CameraCommands.GIMBAL_STICK_CENTER
            gimbalAxis1 = CameraCommands.GIMBAL_STICK_CENTER
            gimbalStickHeld = false
            gimbalSendRest = true
        }
    }

    private fun tickGimbalStick() {
        if (!closed.get() && DjiNative.isAvailable) gimbalTickDispatch.request()
    }

    private fun tickGimbalStickOnTx() {
        val now = SystemClock.elapsedRealtime()
        val packet: Pair<Int, Int>? =
            synchronized(gimbalLock) {
                val last = lastGimbalStickElapsed.get()
                if (!CameraCommands.shouldEmitGimbalStick(
                        gimbalStickHeld, gimbalSendRest, now, last,
                    )
                ) {
                    return@synchronized null
                }
                if (!CameraCommands.shouldEmitGimbalStickOnSocket(
                        rest = gimbalSendRest,
                        liveAccepting = liveViewEnabled,
                        hasConnection = socket != null,
                    )
                ) {
                    return@synchronized null
                }
                lastGimbalStickElapsed.set(now)
                val rest = gimbalSendRest
                val axis0 = if (rest) CameraCommands.GIMBAL_STICK_CENTER else gimbalAxis0
                val axis1 = if (rest) CameraCommands.GIMBAL_STICK_CENTER else gimbalAxis1
                if (rest) {
                    gimbalSendRest = false
                    gimbalStickHeld = false
                }
                axis0 to axis1
            }
        val axes = packet ?: return
        synchronized(sendLock) { sendGimbalStickLocked(axes.first, axes.second) }
    }

    private fun sendGimbalStickLocked(axis0: Int, axis1: Int) {
        if (socket == null) return
        val payload = CameraCommands.gimbalStickPayload(axis0, axis1)
        val frame =
            DjiNative.encodeDuml(
                DjiNative.SENDER_APP,
                DjiNative.RX_GIMBAL,
                dumlSeq,
                DjiNative.FLAG_NOTIFY,
                0x04,
                0x01,
                payload,
            ) ?: return
        val routing = DjiNative.routingHeader(udpSeq, (cmdCounter + 1) and 0xFF, false) ?: return
        val header =
            DjiNative.transportHeader(0x05, routing.size + frame.size, sessionId, udpSeq) ?: return
        cmdCounter = (cmdCounter + 1) and 0xFF
        writeOnNetwork(header + routing + frame)
        dumlSeq = (dumlSeq + 1) and 0xFFFF
        udpSeq = (udpSeq + 8) and 0xFFFF
    }

    private fun sendAck() {
        sendWindowAck()
    }

    /** Merge pktType 0x03 replies and the telemetry download cursor into ACK group 1. */
    private fun noteAckWindows(datagram: ByteArray) {
        if (datagram.size < 8) return
        when (datagram[6].toInt() and 0xFF) {
            0x01 -> if (datagram.size >= 34) {
                val acked =
                    (datagram[18].toInt() and 0xFF) or ((datagram[19].toInt() and 0xFF) shl 8)
                val extra =
                    (datagram[26].toInt() and 0xFF) or ((datagram[27].toInt() and 0xFF) shl 8)
                advanceReliableCursor(acked)
                extraCursor.set(extra)
                hasExtra.set(true)
            }
            0x03 -> {
                val seq = DjiNative.transportSeq(datagram)
                if (seq >= 0) {
                    advanceReliableCursor(seq)
                }
            }
        }
    }

    /** Group 1 is shared by command replies and media downloads; advance from either source. */
    private fun advanceReliableCursor(candidate: Int) {
        val next = candidate and 0xFFFF
        if (!hasAckedData.get()) {
            ackedDataCursor.set(next)
            hasAckedData.set(true)
            return
        }
        while (true) {
            val current = ackedDataCursor.get()
            if (next == current || !isForwardReliableCursor(current, next)) return
            if (ackedDataCursor.compareAndSet(current, next)) return
        }
    }

    /** Handbook / iOS `sendWindowAck`: 34 B pktType 0x04 echoing video + reliable cursors. */
    private fun sendWindowAck() = ackDispatch.request()

    /** Read all cursors at emission time; delayed ACKs cannot queue stale windows. */
    private fun sendWindowAckOnTx() {
        val cursor = peerCursor.get()
        val acked = if (hasAckedData.get()) ackedDataCursor.get() else baseSeq
        val extra = if (hasExtra.get()) extraCursor.get() else baseSeq
        val payload = DjiNative.ackPayload(cursor, acked, extra) ?: return
        val header = DjiNative.transportHeader(0x04, payload.size, sessionId, 0) ?: return
        if (writeOnNetwork(header + payload)) cadence.note(LivePipelineCadence.Stage.ACK)
    }

    /** Every caller shares TX, including the ACK pump and background open/keepalive. */
    private fun onSendThread(body: () -> Unit) {
        if (Thread.currentThread() === txThread.get()) {
            if (!closed.get()) body()
        } else enqueueTx(body)
    }

    private fun writeOnNetwork(bytes: ByteArray): Boolean {
        val sock = socket ?: return false
        val packet =
            if (sock.isConnected) {
                DatagramPacket(bytes, bytes.size)
            } else {
                DatagramPacket(bytes, bytes.size, InetAddress.getByName(host), port)
            }
        synchronized(sendLock) {
            val attempt = runCatching { sock.send(packet) }
                .onSuccess { socketHealth.noteWriteSucceeded() }
                .onFailure { err ->
                    socketHealth.noteWriteRejected()
                    if (sendFailLogs.incrementAndGet() <= 3) {
                        Log.w(TAG, "datalink: UDP send failed", err)
                    }
                }
            return attempt.isSuccess
        }
    }

    private fun receiveLoop(ingressEpoch: Long) {
        val buf = ByteArray(2048)
        while (running.get()) {
            val sock = socket ?: break
            val receiveEpoch = nativeFeedbackEpoch.get()
            val packet = DatagramPacket(buf, buf.size)
            try {
                sock.receive(packet)
                recordIngress(FeedIngressMetrics.Event.Datagram(
                    video = packet.length > 6 && packet.data[packet.offset + 6] == 0x02.toByte(),
                ), ingressEpoch)
                if (packet.length > 0 && !closed.get() && receiveEpoch == nativeFeedbackEpoch.get()) {
                    socketHealth.noteWriteSucceeded()
                    ingest(packet.data.copyOf(packet.length), receiveEpoch, ingressEpoch)
                }
            } catch (_: java.net.SocketTimeoutException) {
            } catch (e: Exception) {
                if (!running.get() || closed.get() || receiveEpoch != nativeFeedbackEpoch.get()) break
                if (e !is InterruptedException && e !is java.io.InterruptedIOException &&
                    e !is java.util.concurrent.CancellationException
                ) {
                    recordIngress(FeedIngressMetrics.Event.ReceiveError, ingressEpoch)
                }
                socketHealth.noteReceiverFailed()
                running.set(false)
                Log.w(TAG, "datalink: UDP receive stopped — current bind failed", e)
                // Permanent socket errors must not spin/log at receive-loop speed.
                // Stale receive ages and write health hand repair to the watchdog.
                break
            }
        }
    }

    private fun ingest(datagram: ByteArray, receiveEpoch: Long, ingressEpoch: Long) {
        val nIn = inboundLogs.incrementAndGet()
        val pktType = if (datagram.size > 6) datagram[6].toInt() and 0xFF else -1
        if (nIn <= 16) {
            val head =
                datagram.take(24).joinToString("") { b ->
                    (b.toInt() and 0xFF).toString(16).padStart(2, '0')
                }
            Log.i(
                TAG,
                "datalink: inbound #$nIn bytes=${datagram.size} pktType=0x${pktType.toString(16)} hex=$head",
            )
        }
        handshakeAdmission.receive(datagram, receiveEpoch)
        noteAckWindows(datagram)
        if (datagram.size == 34 && datagram[6] == 0x01.toByte()) {
            if (!hasVideoSeq.get()) {
                peerCursor.set(
                    (datagram[10].toInt() and 0xFF) or ((datagram[11].toInt() and 0xFF) shl 8),
                )
            }
        } else if (datagram.size >= 7 && datagram[6] == 0x02.toByte()) {
            val seq = DjiNative.transportSeq(datagram)
            if (seq >= 0) {
                peerCursor.set(seq)
                hasVideoSeq.set(true)
            }
        }
        if (datagram.size > 20 && datagram[6] == 0x02.toByte()) {
            if (!liveViewEnabled) {
                recordIngress(FeedIngressMetrics.Event.VideoGateDrop, ingressEpoch)
                val dropped = leftoverVideoPackets.incrementAndGet()
                if (loggedLeftoverGop.compareAndSet(false, true) || dropped <= 8) {
                    Log.i(
                        TAG,
                        "datalink: drop leftover video before ingest #$dropped bytes=${datagram.size}",
                    )
                }
                return
            }
            cadence.note(LivePipelineCadence.Stage.VIDEO)
            lastVideoElapsed.set(SystemClock.elapsedRealtime())
            videoHistory.noteVideoPacket()
            val n = rawVideoPackets.incrementAndGet()
            // Local post-ACK impairment, not an RF or camera-side ACK-loss simulation.
            // Release builds cannot activate it (the app passes the gate only in debug builds);
            // instrumentation owns the bounded gate.
            if (debugVideoPacketAdmission?.invoke() == false) {
                recordIngress(FeedIngressMetrics.Event.InjectedVideoDrop, ingressEpoch)
                return
            }
            if (n <= 8) {
                Log.i(TAG, "datalink: video pktType=0x02 #$n bytes=${datagram.size}")
            }
            if (depacketizer != 0L) {
                val au = DjiNative.depacketizerFeed(depacketizer, datagram)
                val dropped = droppedIncomplete
                val previous = lastIncompleteDropped.getAndSet(dropped)
                var hop = false
                if (AccessUnitDiscontinuity.shouldNote(previous, dropped)) {
                    hop = admission.noteIncompleteLoss(receiveEpoch) || hop
                }
                if (au != null) {
                    lastAccessUnitElapsed.set(SystemClock.elapsedRealtime())
                    cadence.note(LivePipelineCadence.Stage.AU)
                    hop = admission.offer(au, receiveEpoch) || hop
                }
                if (hop) scheduleAdmissionDrain(receiveEpoch)
            }
            return
        }
        val packed = DjiNative.scanDuml(datagram) ?: return
        val frames = DumlCodec.unpackFrames(packed)
        if (frames.isEmpty()) return
        lastStatusElapsed.set(SystemClock.elapsedRealtime())
        frames.forEach { frame ->
            if (!closed.get() && receiveEpoch == nativeFeedbackEpoch.get()) {
                nativeZoomStatus.updateAndGet { current ->
                    if (closed.get() || receiveEpoch != nativeFeedbackEpoch.get()) current else {
                        val status = current?.takeIf { it.first == receiveEpoch }?.second ?: NativeProgramZoomObservation()
                        receiveEpoch to status.observing(frame, cameraModel, SystemClock.elapsedRealtimeNanos() / 1e9)
                    }
                }
            }
            NativeGimbalFeedback.from(frame, SystemClock.elapsedRealtimeNanos() / 1e9,
                readNativeZoomStatus().zoomFactor ?: 1.0)?.let {
                if (!closed.get() && receiveEpoch == nativeFeedbackEpoch.get()) {
                    nativeProgramFeedback.set(receiveEpoch to it)
                }
            }
            if (frame.cmdSet == 0x09 && (frame.cmdId and 0xFF) == 0xA8) {
                val pay0 = frame.payload.firstOrNull()?.toInt()?.and(0xFF) ?: -1
                lastLiveViewReplyElapsed.set(SystemClock.elapsedRealtime())
                Log.i(
                    TAG,
                    "datalink: 0x09/0xa8 reply flags=0x${(frame.flags and 0xFF).toString(16)} " +
                        "pay0=0x${pay0.toString(16)} bytes=${frame.payload.size}",
                )
            }
        }
        // Capture on the raw receive thread; never admit an old packet into a successor query.
        val mediaBatch = DjiAndroidMediaReceiveBatch.capture(frames, mediaIngress, receiveEpoch)
        main.post {
            mediaBatch.deliver(nativeFeedbackEpoch::get, closed::get) { frame -> onStatusFrame?.invoke(frame) }
        }
    }

    /**
     * Recoverable datalink failures. iOS `DatalinkDriver.DatalinkError`.
     * Do not use Kotlin `error()` here; that is `IllegalStateException` and
     * Play Vitals treats an uncaught one as a crash (#189).
     */
    sealed class DatalinkError(message: String) : Exception(message) {
        class NoHandshake : DatalinkError("camera never answered the datalink handshake")
    }

    companion object {
        private const val TAG = "DatalinkDriver"
        const val CAMERA_HOST = "192.168.2.1"
        const val WILDCARD_BIND_HOST = "0.0.0.0"

        /** Handshake miss after rebind/path-lost. Pairing or recovery, not a crash. */
        fun handshakeTimeoutFailure(): Exception = DatalinkError.NoHandshake()

        /** Ephemeral local port. Camera 9004 is the remote, not the client bind. */
        internal const val UDP_BIND_PORT = 0

        /**
         * Android UDP bind host after `Network.bindSocket`. Always the wildcard;
         * the SoftAP Network pin is the path, not a DHCP bind. [localIPv4] is
         * logged as `dhcp=` only. Local port is ephemeral (0), matching iOS
         * and Mimo; not camera 9004.
         */
        fun udpBindPort(): Int = UDP_BIND_PORT

        fun udpBindHost(@Suppress("UNUSED_PARAMETER") localIPv4: String?): String =
            WILDCARD_BIND_HOST

        private const val HANDSHAKE_SENDS_PER_BIND = 20
        private const val HANDSHAKE_SEND_INTERVAL_MS = 350L
        private const val HANDSHAKE_POLL_MS = 20L
        private const val HANDSHAKE_REBIND_LIMIT = 3
        private const val HANDSHAKE_RETRY_PAUSE_MS = 500L
        private const val ACK_INTERVAL_MS = 25L
        /** Camera ignores 0x09/0xa8 until subscribe is processed. */
        private const val SUBSCRIBE_SETTLE_MS = 150L
        /** Core `Commands.subscriptionKeys(for:)`: body-only keys append so base subIds never move. */
        fun subscriptionKeys(model: CameraModel): List<String> =
            if (model.supportsAperture) {
                SUBSCRIPTION_KEYS + listOf(ApertureStrategy.STATE_KEY, ApertureStrategy.CAPABILITY_KEY)
            } else {
                SUBSCRIPTION_KEYS
            }

        private val SUBSCRIPTION_KEYS =
            listOf(
                "camcap_mode_profile",
                "camcap_video_format",
                "camcap_fov",
                "camcap_iso",
                "camcap_shutter",
                "camcap_photo_storage_format",
                "camcap_color_mode",
                "cam_storage",
                "cam_status",
                "timecode_info",
                "cam_expo_param",
                "cam_video_param_v2",
                "cam_record_time",
                "cam_image_effect",
                "cam_lens_state",
                "cam_fov",
                "cam_audio_status_v2",
            )
    }
}
