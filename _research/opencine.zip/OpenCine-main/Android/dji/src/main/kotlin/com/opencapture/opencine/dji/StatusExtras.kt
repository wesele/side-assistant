package com.opencapture.opencine.dji

import com.opencapture.opencine.vocabulary.ApertureStrategy
import com.opencapture.opencine.vocabulary.CamFov
import com.opencapture.opencine.vocabulary.CameraCommands
import com.opencapture.opencine.vocabulary.CameraModel
import com.opencapture.opencine.vocabulary.CameraStatus
import com.opencapture.opencine.vocabulary.FocusTrackMode
import com.opencapture.opencine.vocabulary.VideoFormat
import com.opencapture.opencine.vocabulary.VideoResolution

/**
 * Overlay fields the JNI status JSON does not yet carry, parsed from the same
 * subscribe pushes / GET replies the camera already sends.
 *
 * `cam_expo_param` uses applied shutter `@20–22` in Auto, configured `@2–3` otherwise,
 * ISO index `@5`, configured EV `@6`, expo mode `@7`, metered EV `@15`, ISO number `@16`.
 */
object StatusExtras {
    fun apply(
        frame: DumlFrame,
        status: CameraStatus,
        cameraName: String = "",
        family: String = "",
    ): CameraStatus {
        return when {
            frame.cmdSet == 0x00 && frame.cmdId == 0x99 ->
                applySubscribe(frame.payload, status, cameraName, family)
            frame.cmdSet == 0x02 && frame.cmdId == CameraCommands.CMD_PARAM -> applyParamReply(frame.payload, status)
            frame.cmdSet == 0x02 && frame.cmdId == CameraCommands.CMD_AUDIO_DSP_GET ->
                applyAudioDsp(frame.payload, status).first
            frame.cmdSet == 0x04 && frame.cmdId == CameraCommands.CMD_GIMBAL_PARAMS ->
                applyGimbalParams(frame.payload, status)
            else -> status
        }
    }

    fun applySubscribe(
        payload: ByteArray,
        status: CameraStatus,
        cameraName: String = "",
        family: String = "",
    ): CameraStatus {
        val item = parseSubscribe(payload) ?: return status
        return when (item.name) {
            "cam_expo_param" -> {
                val next = applyExpo(item.value, status)
                if (!CameraModel.looksLikeAction6(cameraName)) next
                else next.copy(irisHundredths = ApertureStrategy.irisHundredths(item.value) ?: -1)
            }
            ApertureStrategy.STATE_KEY ->
                ApertureStrategy.parseState(item.value)?.let { status.copy(apertureStrategy = it) } ?: status
            ApertureStrategy.CAPABILITY_KEY ->
                ApertureStrategy.parseCapability(item.value).takeIf { it.isNotEmpty() }
                    ?.let { status.copy(availableApertureStrategies = it) } ?: status
            "cam_video_param_v2" -> applyVideo(item.value, status)
            "cam_image_effect" -> applyImageEffect(item.value, status, cameraName, family)
            "cam_lens_state" -> applyLens(item.value, status)
            "cam_fov" -> applyFov(item.value, status)
            "camcap_shutter" -> applyShutterCap(item.value, status)
            "camcap_iso" -> applyIsoCap(item.value, status)
            "camcap_color_mode" -> applyColorCap(item.value, status, cameraName, family)
            "camcap_video_format" -> applyVideoCap(item.value, status)
            else -> status
        }
    }

    fun applyExpo(value: ByteArray, status: CameraStatus): CameraStatus {
        if (value.size < 8) return status.copy(meteredEv = -1)
        val meter = value.getOrNull(15)?.toInt()?.and(0xFF) ?: -1
        var next = status.copy(meteredEv = meter.takeIf { it in 0x07..0x19 } ?: -1)
        if (value.size > 7) {
            val mode = value[7].toInt() and 0xFF
            if (mode == CameraCommands.EXPO_AUTO || mode == CameraCommands.EXPO_MANUAL) {
                next = next.copy(expoMode = mode)
            }
        }
        if (value.size > 5) {
            next = next.copy(isoIndex = CameraCommands.djiIsoIndex(value[5].toInt() and 0xFF))
        }
        if (value[7].toInt() == CameraCommands.EXPO_AUTO) {
            // The manual setting stays fixed in Auto. Never use it as a fallback.
            val raw = if (value.size >= 23) u16(value, 20) else 0
            val denom = raw and 0x7FFF
            val supported = value.size >= 23 && raw and 0x8000 != 0 &&
                value[22].toInt() == 0 && denom in 1..16_000
            next = next.copy(shutterDenom = if (supported) denom else -1)
        } else {
            val shutterRaw = u16(value, 2)
            if (shutterRaw and 0x8000 != 0) {
                val denom = shutterRaw and 0x7FFF
                if (denom in 1..16_000) next = next.copy(shutterDenom = denom)
            }
        }
        if (value.size >= 18) {
            val iso = u16(value, 16)
            if (iso in 50..102_400) next = next.copy(iso = iso)
        }
        if (value.size > 6) {
            val ev = value[6].toInt() and 0xFF
            next = next.copy(evComp = if (ev in 0x07..0x19) ev else -1)
        }
        return next
    }

    fun applyVideo(value: ByteArray, status: CameraStatus): CameraStatus {
        if (value.size < 2) return status
        val resRaw = value[0].toInt() and 0xFF
        val fpsIdx = value[1].toInt() and 0xFF
        var next = status
        CameraCommands.fpsFromSubscribeIndex(fpsIdx)?.let { fps ->
            next = next.copy(fps = fps, fpsIndex = fpsIdx)
        }
        VideoResolution.fromDjiRaw(resRaw)?.let { res ->
            next = next.copy(resolutionCode = res.rawValue)
        }
        VideoFormat.parseDji(resRaw, fpsIdx)?.let { format ->
            next =
                next.copy(
                    resolutionCode = format.resolution.rawValue,
                    fpsIndex = format.frameRate.rawValue,
                    fps = format.frameRate.fps,
                )
        }
        return next
    }

    fun applyImageEffect(
        value: ByteArray,
        status: CameraStatus,
        cameraName: String = "",
        family: String = "",
    ): CameraStatus {
        if (value.size < 5) return status
        var next =
            status.copy(
                colorMode = CameraCommands.parseColorMode(
                    value[2].toInt() and 0xFF,
                    cameraName,
                    family,
                ),
            )
        if (value.size >= 9) {
            val mode = value[4].toInt() and 0xFF
            if (mode == CameraCommands.WB_AUTO || mode == CameraCommands.WB_CUSTOM) {
                val tint = i16(value, 7)
                next =
                    if (mode == CameraCommands.WB_CUSTOM) {
                        val kelvin = u16(value, 5) * 100
                        next.copy(
                            wbMode = mode,
                            wbKelvin = if (kelvin in 2_000..10_000) kelvin else next.wbKelvin,
                            wbTint = tint,
                        )
                    } else {
                        next.copy(wbMode = mode, wbTint = tint)
                    }
            }
        }
        return next
    }

    fun applyShutterCap(value: ByteArray, status: CameraStatus): CameraStatus {
        val denoms = CameraCommands.parseShutterDenoms(value)
        return if (denoms.isEmpty()) status else status.copy(availableShutterDenoms = denoms)
    }

    fun applyIsoCap(value: ByteArray, status: CameraStatus): CameraStatus {
        val indices = CameraCommands.parseIsoIndices(value)
        return if (indices.isEmpty()) status else status.copy(availableIsoIndices = indices)
    }

    fun applyColorCap(
        value: ByteArray,
        status: CameraStatus,
        cameraName: String = "",
        family: String = "",
    ): CameraStatus {
        val modes = CameraCommands.parseColorModes(value, cameraName, family)
        return if (modes.isEmpty()) status else status.copy(availableColorModes = modes)
    }

    fun applyVideoCap(value: ByteArray, status: CameraStatus): CameraStatus {
        val formats = CameraCommands.parseVideoFormats(value)
        return if (formats.isEmpty()) status else status.copy(availableVideoFormats = formats)
    }

    fun applyFov(value: ByteArray, status: CameraStatus): CameraStatus {
        val raw = CamFov.rawAt0(value) ?: return status
        return CamFov.absorb(status.copy(zoomFactorRaw = raw))
    }

    fun applyLens(value: ByteArray, status: CameraStatus): CameraStatus {
        if (value.isEmpty()) return status
        var next = status
        when (value[0].toInt() and 0xFF) {
            0xB1 -> next = next.copy(focusMode = CameraCommands.FOCUS_SINGLE)
            0xB2 -> next = next.copy(focusMode = CameraCommands.FOCUS_CONTINUOUS)
        }
        CamFov.lensAt14(value)?.let { lens -> next = next.copy(zoomLens = lens) }
        return CamFov.absorb(next)
    }

    fun isGimbalParamsReply(payload: ByteArray): Boolean =
        payload.size >= 8 && payload[0] == 0.toByte() && payload[1] == 0x01.toByte() &&
            payload[2] == 0x04.toByte() && payload[3] == 0x01.toByte() &&
            payload[5] == 0x05.toByte() && payload[6] == 0x01.toByte()

    fun applyGimbalParams(payload: ByteArray, status: CameraStatus): CameraStatus {
        if (!isGimbalParamsReply(payload)) return status
        val tilt = payload[4].toInt() and 0xFF
        val speed = payload[7].toInt() and 0xFF
        return status.copy(
            gimbalTiltLock = if (tilt == 0 || tilt == 1) tilt else status.gimbalTiltLock,
            gimbalSpeed = if (speed in 0..2) speed else status.gimbalSpeed,
        )
    }

    fun applyParamReply(payload: ByteArray, status: CameraStatus): CameraStatus {
        FocusTrackMode.parseReply(payload)?.let { return status.copy(focusTrack = it.raw) }
        if (payload.size < 7) return status
        val pid = (payload[3].toInt() and 0xFF) or ((payload[4].toInt() and 0xFF) shl 8)
        val value = payload[6].toInt() and 0xFF
        return when (pid) {
            CameraCommands.PID_AUDIO_CHANNEL -> status.copy(audioChannel = value)
            CameraCommands.PID_VOCAL_BOOST -> status.copy(vocalBoost = value)
            CameraCommands.PID_ISO_LIMIT ->
                if (value in 0x02..0x09) status.copy(isoLimit = value) else status
            CameraCommands.PID_SELFIE_FLIP ->
                if (value == 0 || value == 1) status.copy(selfieFlip = value == 1) else status
            else -> status
        }
    }

    fun applyAudioDsp(payload: ByteArray, status: CameraStatus): Pair<CameraStatus, ByteArray?> {
        if (payload.isEmpty() || payload[0] != 0.toByte() || payload.size < 27) {
            return status to null
        }
        val blob = payload.copyOfRange(1, 27)
        return applyAudioBlob(blob, status) to blob
    }

    fun applyAudioBlob(blob: ByteArray, status: CameraStatus): CameraStatus {
        if (blob.size < 3) return status
        return status.applyingAudioBlob(blob)
    }

    /** `0x02/0x80` `@57` is the only unsolicited shooting-mode report. */
    fun reportsShootingMode(frame: DumlFrame): Boolean =
        frame.cmdSet == 0x02 && frame.cmdId == 0x80 && frame.payload.size >= 58

    fun parseSubscribe(payload: ByteArray): SubscribeItem? {
        if (payload.size < 24 || payload[0] != 0x02.toByte() || payload[1] != 0x06.toByte()) return null
        val nameLen = (payload[13].toInt() and 0xFF) or ((payload[14].toInt() and 0xFF) shl 8)
        if (nameLen <= 0 || nameLen >= 80 || 15 + nameLen + 8 > payload.size) return null
        val name = payload.decodeToString(15, 15 + nameLen)
        if (name.isEmpty()) return null
        val valueLenAt = 15 + nameLen + 6
        if (valueLenAt + 2 > payload.size) return null
        val valueLen = (payload[valueLenAt].toInt() and 0xFF) or ((payload[valueLenAt + 1].toInt() and 0xFF) shl 8)
        val valueAt = valueLenAt + 2
        if (valueAt + valueLen > payload.size) return null
        return SubscribeItem(name, payload.copyOfRange(valueAt, valueAt + valueLen))
    }

    fun packSubscribe(name: String, value: ByteArray, idx: Int = 0): ByteArray {
        val nb = name.encodeToByteArray()
        val inner = 2 + nb.size + 6 + 2 + value.size
        val out = ArrayList<Byte>(15 + nb.size + 8 + value.size)
        out.addAll(listOf(0x02, 0x06, 0x00, 0x00).map { it.toByte() })
        out.add((idx and 0xFF).toByte())
        out.add(((idx shr 8) and 0xFF).toByte())
        out.add(((idx shr 16) and 0xFF).toByte())
        out.add(((idx shr 24) and 0xFF).toByte())
        out.addAll(listOf(0, 0, 0).map { it.toByte() })
        out.add((inner and 0xFF).toByte())
        out.add(((inner shr 8) and 0xFF).toByte())
        out.add((nb.size and 0xFF).toByte())
        out.add(((nb.size shr 8) and 0xFF).toByte())
        out.addAll(nb.toList())
        repeat(6) { out.add(0) }
        out.add((value.size and 0xFF).toByte())
        out.add(((value.size shr 8) and 0xFF).toByte())
        out.addAll(value.toList())
        return out.toByteArray()
    }

    data class SubscribeItem(val name: String, val value: ByteArray)

    private fun u16(p: ByteArray, i: Int): Int =
        (p[i].toInt() and 0xFF) or ((p[i + 1].toInt() and 0xFF) shl 8)

    private fun i16(p: ByteArray, i: Int): Int {
        val u = u16(p, i)
        return if (u >= 0x8000) u - 0x10000 else u
    }
}
