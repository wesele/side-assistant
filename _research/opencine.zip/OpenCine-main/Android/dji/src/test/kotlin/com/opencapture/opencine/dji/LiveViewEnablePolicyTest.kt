package com.opencapture.opencine.dji

import com.opencapture.opencine.decoder.HevcDecoder

import com.opencapture.opencine.vocabulary.CamFov
import com.opencapture.opencine.vocabulary.CameraCommands
import com.opencapture.opencine.vocabulary.ConnectionPhase
import com.opencapture.opencine.vocabulary.SessionDropStormGuard
import com.opencapture.opencine.vocabulary.SessionRecoveryCopy
import com.opencapture.opencine.vocabulary.SessionRecoveryDecision
import com.opencapture.opencine.vocabulary.SessionRecoveryPolicy
import com.opencapture.opencine.vocabulary.SessionRecoveryUi
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue
import com.opencapture.opencine.media.LiveAccessUnit
import com.opencapture.opencine.media.LiveVideoCodec

class LiveViewEnablePolicyTest {
    @Test
    fun reconnectIsAllowedFromLive() {
        assertTrue(phaseAllowsReconnect(ConnectionPhase.LIVE))
        assertTrue(phaseAllowsReconnect(ConnectionPhase.FAILED))
        assertTrue(!phaseAllowsReconnect(ConnectionPhase.OPENING_DATALINK))
    }

    @Test
    fun handshakeMissDoesNotKickWhileSoftAPUp() {
        assertTrue(!LiveViewEnablePolicy.shouldKickAfterHandshakeTimeout(pathReady = true))
        assertTrue(LiveViewEnablePolicy.shouldKickAfterHandshakeTimeout(pathReady = false))
        assertTrue(!LiveViewEnablePolicy.shouldGiveUpOpenRetry(5))
        assertTrue(LiveViewEnablePolicy.shouldGiveUpOpenRetry(6))
        assertTrue(!LiveViewEnablePolicy.canSendHandshake(receiveArmed = false, connectionReady = true))
        assertTrue(LiveViewEnablePolicy.canSendHandshake(receiveArmed = true, connectionReady = true))
        assertTrue(
            LiveViewEnablePolicy.shouldCommitLiveHandshake(
                driverOwned = true,
                isClosed = false,
                isCancelled = false,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldCommitLiveHandshake(
                driverOwned = true,
                isClosed = true,
                isCancelled = false,
            ),
        )
        assertTrue(LiveViewEnablePolicy.shouldReuseDatalink(isClosed = false))
        assertTrue(!LiveViewEnablePolicy.shouldReuseDatalink(isClosed = true))
        assertTrue(
            LiveViewEnablePolicy.handshakeOpenTimeoutMs() > 30_000L,
            "30 s raced 20×350 ms × 4 binds",
        )
    }

    @Test
    fun watchdogDoesNotEnableEverySecondWhileStalled() {
        val state = LiveViewEnablePolicy.State()
        val enableAt = 10_000L
        val first =
            stalledSnap(
                now = enableAt + 1_000,
                lastEnableAt = enableAt,
                lastVideoAt = enableAt - 8_000,
                lastStatusAt = enableAt - 8_000,
                lastBleAt = enableAt + 800,
                lastRebuildAt = enableAt,
            )
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, first))
        val second = first.copy(now = enableAt + 2_000)
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, second))
    }

    @Test
    fun encoderPauseSendsOneEnableThenWaitsFiveSeconds() {
        val state = LiveViewEnablePolicy.State()
        val now = 20_000L
        val snap =
            stalledSnap(
                now = now,
                lastEnableAt = now - 10_000,
                lastVideoAt = now - 8_000,
                lastStatusAt = now - 200,
                lastBleAt = now - 100,
                lastRebuildAt = now - 70_000,
            )
        assertEquals(
            LiveViewEnablePolicy.Action.RESEND_ENABLE,
            LiveViewEnablePolicy.tick(state, snap),
        )
        val oneSecondLater = snap.copy(now = now + 1_000, lastEnableAt = now)
        assertEquals(
            LiveViewEnablePolicy.Action.NONE,
            LiveViewEnablePolicy.tick(state, oneSecondLater),
        )
        val fiveSecondsLater =
            snap.copy(
                now = now + 5_000,
                lastEnableAt = now,
                lastStatusAt = now + 5_000 - 200,
                lastBleNotifyAt = now + 5_000 - 100,
            )
        assertEquals(
            LiveViewEnablePolicy.Action.REBUILD_UDP,
            LiveViewEnablePolicy.tick(state, fiveSecondsLater),
        )
    }

    @Test
    fun gimbalThrowHoldsEncoderPauseEnable() {
        val state = LiveViewEnablePolicy.State()
        val now = 20_000L
        val snap =
            stalledSnap(
                now = now,
                lastEnableAt = now - 10_000,
                // Stalled (2 s) but inside gimbal video grace (stall + 3 s).
                // 8 s stale video lifts the hold so a stuck stick cannot block recover.
                lastVideoAt = now - 2_500,
                lastStatusAt = now - 200,
                lastBleAt = now - 100,
                lastRebuildAt = now - 70_000,
                lastGimbalThrowAt = now - 1_000,
            )
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, snap))
        val pastGrace =
            snap.copy(lastGimbalThrowAt = now - 3_100)
        assertEquals(
            LiveViewEnablePolicy.Action.RESEND_ENABLE,
            LiveViewEnablePolicy.tick(state, pastGrace),
        )
        val held =
            stalledSnap(
                now = now,
                lastEnableAt = now - 10_000,
                lastVideoAt = now - 8_000,
                lastStatusAt = now - 200,
                lastBleAt = now - 100,
                lastRebuildAt = now - 70_000,
                lastGimbalThrowAt = now - 8_000,
            ).copy(gimbalStickHeld = true)
        assertEquals(
            LiveViewEnablePolicy.Action.NONE,
            LiveViewEnablePolicy.tick(LiveViewEnablePolicy.State(), held),
            "finger on the stick must not GOP-cut",
        )
    }

    @Test
    fun foregroundRecoverSkipsWhenPictureIsFresh() {
        assertTrue(!LiveViewEnablePolicy.shouldRecoverAfterForeground(0.4))
        assertTrue(LiveViewEnablePolicy.shouldRecoverAfterForeground(2.0))
        assertTrue(LiveViewEnablePolicy.shouldRecoverAfterForeground(null))
        assertTrue(
            !LiveViewEnablePolicy.shouldRecoverAfterForeground(3.0, videoFresh = true),
        )
        assertTrue(!LiveViewEnablePolicy.shouldEscalateForegroundRecover(0.5))
        assertTrue(
            !LiveViewEnablePolicy.shouldEscalateForegroundRecover(2.0),
            "2s is still GOP-reset grace",
        )
        assertTrue(LiveViewEnablePolicy.shouldEscalateForegroundRecover(8.0))
        assertTrue(LiveViewEnablePolicy.shouldEscalateForegroundRecover(null))
        assertEquals(
            LiveViewEnablePolicy.HandshakeTimeoutStep.KEEP_SOCKET,
            LiveViewEnablePolicy.handshakeTimeoutStep(
                pathReady = true,
                rebindsUsed = 0,
                inboundDatagrams = 12,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 80,
                enableSends = 0,
                sinceEnableMs = 0,
                videoAgeMs = 40,
                sinceRebuildMs = null,
                hasPresentedPicture = true,
            ),
        )
    }

    @Test
    fun prepareAfterForegroundDoesNotHoldIdr() {
        val decoder = HevcDecoder()
        decoder.prepareAfterForeground()
        assertTrue(!decoder.awaitingIdr)
    }

    @Test
    fun resetClearsIdrHoldAndPicture() {
        val decoder = HevcDecoder()
        decoder.beginIDRHold()
        assertTrue(decoder.awaitingIdr)
        decoder.reset()
        assertTrue(!decoder.awaitingIdr)
        assertTrue(!decoder.hasFormat)
        assertTrue(!decoder.hasPicture.value)
        assertTrue(!decoder.isPresentationReady)
    }

    @Test
    fun afcAndZoomGraceHoldWatchdogUntilTheStageExpires() {
        val now = 20_000L
        val base =
            stalledSnap(
                now = now,
                lastEnableAt = now - 10_000,
                lastVideoAt = now - 3_000,
                lastStatusAt = now - 8_000,
                lastBleAt = now - 100,
                lastRebuildAt = now - 70_000,
            )
        val cases = listOf(
            "AF-C" to base.copy(lastFocusTrackAt = now - 2_200),
            "zoom" to base.copy(lastZoomAt = now - 1_000),
        )
        for ((control, snap) in cases) {
            val state = LiveViewEnablePolicy.State()
            assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, snap), "$control grace")
            assertEquals(
                LiveViewEnablePolicy.Action.REBUILD_UDP,
                LiveViewEnablePolicy.tick(state,
                    snap.copy(lastVideoPacketAt = now - 8_000, lastAccessUnitAt = now - 8_000)),
                "$control: a recent control cannot renew grace after the failed stage exceeds stall + grace",
            )
        }
    }

    @Test
    fun gopGraceHoldsEnableForEightSeconds() {
        val state = LiveViewEnablePolicy.State()
        val enableAt = 5_000L
        val snap =
            stalledSnap(
                now = enableAt + 3_000,
                lastEnableAt = enableAt,
                lastVideoAt = enableAt + 100,
                lastStatusAt = enableAt + 2_900,
                lastBleAt = enableAt + 2_900,
                lastRebuildAt = null,
            )
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, snap))
        assertTrue(
            LiveViewEnablePolicy.shouldHoldForGopReset(
                sinceEnableMs = 3_000,
                videoAgeMs = 2_900,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldHoldForGopReset(
                sinceEnableMs = 8_000,
                videoAgeMs = 8_000,
            ),
        )
    }

    @Test
    fun rebuildBackoffIsSixtySecondsWhenBleIsFresh() {
        val state = LiveViewEnablePolicy.State()
        val now = 30_000L
        val snap =
            stalledSnap(
                now = now,
                lastEnableAt = now - 10_000,
                lastVideoAt = now - 8_000,
                lastStatusAt = now - 8_000,
                lastBleAt = now - 100,
                lastRebuildAt = now - 10_000,
            )
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, snap))
        assertTrue(
            LiveViewEnablePolicy.shouldHoldRebuildAfterRecentUdp(
                sinceRebuildMs = 10_000,
                pathReady = true,
                bleAgeMs = 100,
                hadVideo = true,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldHoldRebuildAfterRecentUdp(
                sinceRebuildMs = 60_000,
                pathReady = true,
                bleAgeMs = 100,
                hadVideo = true,
            ),
        )
    }

    @Test
    fun firstPictureEscalatesToRejoinNotEndlessUdpRebuild() {
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 2,
                sinceEnableMs = 2_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.REBUILD_UDP,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 2,
                sinceEnableMs = 8_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.REJOIN,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 4,
                sinceEnableMs = 8_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.REJOIN,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 420,
                enableSends = 2,
                sinceEnableMs = 8_000,
                videoAgeMs = 8_000,
                sinceRebuildMs = 5_000,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 800,
                enableSends = 1,
                sinceEnableMs = 3_000,
                videoAgeMs = 200,
                sinceRebuildMs = null,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.RESEND_ENABLE,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 800,
                enableSends = 1,
                sinceEnableMs = 5_000,
                videoAgeMs = 200,
                sinceRebuildMs = null,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 800,
                enableSends = 1,
                sinceEnableMs = 5_000,
                videoAgeMs = 200,
                sinceRebuildMs = null,
                hasPresentedPicture = true,
            ),
        )
        assertTrue(!LiveViewEnablePolicy.shouldBeginIDRHoldOnEnable(true))
        assertTrue(LiveViewEnablePolicy.shouldBeginIDRHoldOnEnable(false))
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 370,
                enableSends = 2,
                sinceEnableMs = 2_000,
                videoAgeMs = 2_500,
                sinceRebuildMs = null,
            ),
        )
    }

    @Test
    fun firstPicturePokesRecordingFormatOnPocket3() {
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.POKE_RECORDING_FORMAT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 1,
                sinceEnableMs = 2_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
                needsRecordingFormatPoke = true,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 1,
                sinceEnableMs = 2_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
            ),
            "Pocket 4 IDR grace, not a 2s second enable",
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.POKE_RECORDING_FORMAT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 2,
                sinceEnableMs = 2_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
                needsRecordingFormatPoke = true,
            ),
            "poke before tearing UDP",
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 800,
                enableSends = 1,
                sinceEnableMs = 3_000,
                videoAgeMs = 200,
                sinceRebuildMs = null,
                needsRecordingFormatPoke = true,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.POKE_RECORDING_FORMAT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 800,
                enableSends = 1,
                sinceEnableMs = 5_000,
                videoAgeMs = 200,
                sinceRebuildMs = null,
                needsRecordingFormatPoke = true,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldPokeRecordingFormat(
                needsPoke = false,
                alreadyPoked = false,
                isRecording = false,
                hadVideo = false,
                enableSends = 1,
                sinceEnableMs = 2_000,
            ),
        )
        assertTrue(
            LiveViewEnablePolicy.shouldDeferRecordingFormatPoke(
                hasKnownRecordingFormat = false,
                sinceEnableMs = 2_000,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldDeferRecordingFormatPoke(
                hasKnownRecordingFormat = true,
                sinceEnableMs = 2_000,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldDeferRecordingFormatPoke(
                hasKnownRecordingFormat = false,
                sinceEnableMs = 8_000,
            ),
        )
    }

    @Test
    fun leftoverGopKeepsUdpOnlyWhileVideoIsFresh() {
        assertTrue(
            LiveViewEnablePolicy.shouldKeepUdpForLeftoverGop(
                noPicture = true,
                videoPackets = 375,
                videoAgeMs = 200,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldKeepUdpForLeftoverGop(
                noPicture = true,
                videoPackets = 375,
                videoAgeMs = 8_000,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldKeepUdpForLeftoverGop(
                noPicture = true,
                videoPackets = 375,
                videoAgeMs = null,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldKeepUdpForLeftoverGop(
                noPicture = false,
                videoPackets = 375,
                videoAgeMs = 200,
            ),
        )
    }

    @Test
    fun overlayMustNotDropLiveHevc() {
        assertTrue(
            LiveViewEnablePolicy.shouldIngestLiveVideo(
                ingestArmed = true,
                browsingMedia = true,
                operatorOverlayHeld = false,
            ),
            "#177: library covering the monitor is not a leftover-GOP gate",
        )
        assertTrue(
            LiveViewEnablePolicy.shouldIngestLiveVideo(
                ingestArmed = true,
                browsingMedia = false,
                operatorOverlayHeld = true,
            ),
            "#177: settings covering the monitor is not a leftover-GOP gate",
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldIngestLiveVideo(
                ingestArmed = false,
                browsingMedia = true,
                operatorOverlayHeld = true,
            ),
        )
    }

    @Test
    fun firstPictureDoesNotExitPlaybackUnlessCameraIsInGallery() {
        assertTrue(!LiveViewEnablePolicy.shouldExitPlaybackBeforeLiveEnable(inPlayback = false))
        assertTrue(LiveViewEnablePolicy.shouldExitPlaybackBeforeLiveEnable(inPlayback = true))
        assertTrue(LiveViewEnablePolicy.shouldClearForegroundRecoverWithoutRebuild(holdsMonitor = true))
        assertTrue(!LiveViewEnablePolicy.shouldClearForegroundRecoverWithoutRebuild(holdsMonitor = false))
        assertTrue(LiveViewEnablePolicy.shouldContinueFirstPictureAfterStrayPlayback(hasPicture = false))
        assertTrue(!LiveViewEnablePolicy.shouldContinueFirstPictureAfterStrayPlayback(hasPicture = true))
    }

    @Test
    fun rebuildRearmsIngestWhenItWasAccepting() {
        assertTrue(LiveViewEnablePolicy.shouldRearmLiveIngestAfterUDPRebuild(true))
        assertTrue(!LiveViewEnablePolicy.shouldRearmLiveIngestAfterUDPRebuild(false))
        assertTrue(!LiveViewEnablePolicy.shouldForceEnableAfterUDPRebuild(true))
        assertTrue(LiveViewEnablePolicy.shouldForceEnableAfterUDPRebuild(false))
    }

    @Test
    fun keepaliveDoesNotTearUdpDuringFirstPicture() {
        assertTrue(
            !LiveViewEnablePolicy.shouldKeepaliveRebuildUDP(
                flowNeedsRebuild = true,
                rebuildInFlight = false,
                sinceRebuildMs = null,
                sawPicture = false,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldKeepaliveRebuildUDP(
                flowNeedsRebuild = true,
                rebuildInFlight = false,
                sinceRebuildMs = 10_000,
                videoFresh = true,
                sawPicture = true,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldKeepaliveRebuildUDP(
                flowNeedsRebuild = true,
                rebuildInFlight = false,
                sinceRebuildMs = 10_000,
                videoFresh = false,
                sawPicture = true,
                statusFresh = true,
            ),
        )
        assertTrue(!LiveViewEnablePolicy.shouldForceEnableAfterUDPRebuild(hadVideo = true))
        assertTrue(LiveViewEnablePolicy.shouldForceEnableAfterUDPRebuild(hadVideo = false))
        assertTrue(
            !LiveViewEnablePolicy.shouldStartFeedRecovery(rebuildInFlight = true),
            "do not cancel a live UDP rebuild to start another",
        )
        assertTrue(LiveViewEnablePolicy.shouldStartFeedRecovery(rebuildInFlight = false))
        assertTrue(
            LiveViewEnablePolicy.shouldTreatLiveVideoAsStale(
                lastVideoPacketAgeMs = null,
                hadVideo = true,
            ),
            "rebuild wiped lastVideo; analog must lift",
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldTreatLiveVideoAsStale(
                lastVideoPacketAgeMs = null,
                hadVideo = false,
            ),
        )
        assertTrue(
            LiveViewEnablePolicy.shouldTreatLiveVideoAsStale(
                lastVideoPacketAgeMs = 1_600L,
                hadVideo = true,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldTreatLiveVideoAsStale(
                lastVideoPacketAgeMs = 400L,
                hadVideo = true,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldRepeatRecoverEnable(
                sinceEnableMs = 5_000L,
                sinceRebuildMs = null,
                pathReady = true,
                bleAgeMs = 200L,
                hadVideo = true,
                holdEnableCount = 1,
                videoAgeMs = 5_000L,
            ),
            "encoder-pause is FeedWatchdog.tick; extra 0x09/0xa8 GOP-cuts",
        )
        assertTrue(
            LiveViewEnablePolicy.shouldRepeatRecoverEnable(
                sinceEnableMs = 2_000L,
                sinceRebuildMs = 400L,
                pathReady = true,
                bleAgeMs = 200L,
                hadVideo = false,
                holdEnableCount = 1,
                videoAgeMs = null,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldRebuildAfterCommandTimeouts(
                timeoutsInWindow = 2,
                downlinkFresh = true,
                videoFresh = false,
                rebuildInFlight = false,
                sinceRebuildMs = null,
                statusFresh = true,
            ),
            "status on 9004 is encoder-pause; SET timeout must not tear UDP",
        )
        assertTrue(
            LiveViewEnablePolicy.shouldRebuildAfterCommandTimeouts(
                timeoutsInWindow = 2,
                downlinkFresh = true,
                videoFresh = false,
                rebuildInFlight = false,
                sinceRebuildMs = null,
                statusFresh = false,
            ),
        )
        assertTrue(!LiveViewEnablePolicy.shouldSendRecoverEnable(pathReady = true, decoderReady = false))
        assertTrue(LiveViewEnablePolicy.shouldSendRecoverEnable(pathReady = true, decoderReady = true))
        assertTrue(LiveViewEnablePolicy.shouldSendLiveViewPrepare(usesNanoLiveViewGate = false))
        assertTrue(!LiveViewEnablePolicy.shouldSendLiveViewPrepare(usesNanoLiveViewGate = true))
    }

    @Test
    fun firstPictureWaitsTwoSecondsThenResendsNotOneHertz() {
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 1,
                sinceEnableMs = 1_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.WAIT,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 1,
                sinceEnableMs = 2_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
            ),
        )
        assertEquals(
            LiveViewEnablePolicy.FirstPictureStep.RESEND_ENABLE,
            LiveViewEnablePolicy.firstPictureStep(
                videoPackets = 0,
                enableSends = 1,
                sinceEnableMs = 8_000,
                videoAgeMs = null,
                sinceRebuildMs = null,
            ),
        )
    }

    @Test
    fun recoveryPolicyDoesNotRetryAtOneHertz() {
        val policy = SessionRecoveryPolicy.monitor
        assertEquals(SessionRecoveryDecision.Retry(0), policy.decision(0, jitter = 0.5))
        val afterFirst = policy.decision(1, jitter = 0.5)
        assertTrue(afterFirst is SessionRecoveryDecision.Retry)
        assertEquals(500L, (afterFirst as SessionRecoveryDecision.Retry).afterMs)
        val afterSecond = policy.decision(2, jitter = 0.5)
        assertEquals(1_000L, (afterSecond as SessionRecoveryDecision.Retry).afterMs)
        assertEquals(SessionRecoveryDecision.Stop, policy.decision(8, jitter = 0.5))
        assertTrue(policy.state(0) is SessionRecoveryUi.Retrying)
        assertTrue(policy.state(8) is SessionRecoveryUi.WaitingForOperator)
    }

    @Test
    fun recoveryDetailCountsAttemptsWithoutNamingSisterApps() {
        val retrying = SessionRecoveryUi.Retrying(attempt = 3, maxAttempts = 8)
        val detail = SessionRecoveryCopy.detail(retrying, "Pocket 4 Pro")
        assertTrue(detail.contains("attempt 3 of 8"))
        assertTrue(!detail.contains("OpenZCine", ignoreCase = true))
    }

    @Test
    fun dropStormPausesAfterThreeDropsInTwoMinutes() {
        val guard = SessionDropStormGuard()
        assertTrue(!guard.noteDrop(0))
        assertTrue(!guard.noteDrop(15_000))
        assertTrue(guard.noteDrop(30_000))
        assertEquals(3, guard.dropsInWindow)
        guard.reset()
        assertEquals(0, guard.dropsInWindow)
    }

    @Test
    fun hevcIdrHoldDetectsCodecFromCsd() {
        val hevcCsd = byteArrayOf(0, 0, 0, 1, 0x40, 0x01, 0, 0, 0, 1, 0x42, 0x01)
        assertEquals(LiveVideoCodec.HEVC, LiveAccessUnit.detectCodec(hevcCsd, "32,33"))
        val avcCsd = byteArrayOf(0, 0, 0, 1, 0x67, 0x42, 0, 0, 0, 1, 0x68, 0xCE.toByte())
        assertEquals(LiveVideoCodec.AVC, LiveAccessUnit.detectCodec(avcCsd, "7,8"))
        assertTrue(LiveAccessUnit.isIdrPicture("20,33,34"))
        assertTrue(LiveAccessUnit.isIdrPicture("16,6,8"))
        assertTrue(LiveAccessUnit.isIdrPicture("5,7,8"))
        assertTrue(!LiveAccessUnit.isIdrPicture("1,33,34"))
        assertTrue(!LiveAccessUnit.isIdrPicture("8"))
        assertTrue(
            LiveAccessUnit.isIdrPicture("8", byteArrayOf(0, 0, 0, 1, 0x28, 0x01)),
            "HEVC IDR_N_LP must count as IDR even if JNI summarized it as AVC PPS",
        )
    }

    @Test
    fun leftoverPFramesAndIdrNlpDoNotConfigureAsAvc() {
        // Pocket leftover GOP: TRAIL_R / AUD / SUFFIX_SEI. No VPS/SPS/PPS.
        val leftover =
            byteArrayOf(
                0, 0, 0, 1, 0x02, 0x01,
                0, 0, 0, 1, 0x46, 0x01,
                0, 0, 0, 1, 0x50, 0x01,
            )
        assertNull(LiveAccessUnit.detectCodec(leftover, "1,35,40"))
        // HEVC IDR_N_LP first byte 0x28 == AVC PPS (nal_ref_idc=1). Must wait for VPS.
        val idrNlp = byteArrayOf(0, 0, 0, 1, 0x28, 0x01)
        assertNull(LiveAccessUnit.detectCodec(idrNlp, "20"))
        assertNull(LiveAccessUnit.detectCodec(idrNlp, "8"))
        // IDR then VPS in one AU still latches HEVC from 0x40, not AVC from 0x28.
        val idrThenVps = byteArrayOf(0, 0, 0, 1, 0x28, 0x01, 0, 0, 0, 1, 0x40, 0x01)
        assertEquals(LiveVideoCodec.HEVC, LiveAccessUnit.detectCodec(idrThenVps, "20,32"))
        assertEquals(LiveVideoCodec.AVC, LiveAccessUnit.detectCodec(byteArrayOf(0, 0, 0, 1, 0x68, 0xCE.toByte()), "8"))
    }

    @Test
    fun zoomChipLensesMatchCamFovStops() {
        assertEquals(217, CameraCommands.lensForZoomFactor(1.0))
        assertEquals(CamFov.lensPosition(2.0), CameraCommands.lensForZoomFactor(2.0))
        assertEquals(651, CameraCommands.lensForZoomFactor(3.0))
        assertEquals(CamFov.lensPosition(4.0), CameraCommands.lensForZoomFactor(4.0))
        assertEquals(1302, CameraCommands.lensForZoomFactor(6.0))
        assertEquals(2604, CameraCommands.lensForZoomFactor(12.0))
        val payload = CameraCommands.zoomLens(217)
        assertEquals(0x0A, payload[0].toInt() and 0xFF)
        assertEquals(0x4E, payload[1].toInt() and 0xFF)
        assertEquals(217, (payload[2].toInt() and 0xFF) or ((payload[3].toInt() and 0xFF) shl 8))
    }

    @Test
    fun idrHoldReleasesAfterGopGraceOnlyWhenUdpAndPictureExist() {
        assertTrue(
            !LiveViewEnablePolicy.shouldReleaseIDRHold(
                awaitingIDR = true,
                udpReceiveAlive = true,
                sinceEnableMs = 2_000,
                hasPresentedPicture = true,
            ),
            "still inside GOP grace",
        )
        assertTrue(
            LiveViewEnablePolicy.shouldReleaseIDRHold(
                awaitingIDR = true,
                udpReceiveAlive = true,
                sinceEnableMs = 8_000,
                hasPresentedPicture = true,
            ),
        )
        assertTrue(
            !LiveViewEnablePolicy.shouldReleaseIDRHold(
                awaitingIDR = true,
                udpReceiveAlive = true,
                sinceEnableMs = 8_000,
                hasPresentedPicture = false,
            ),
            "first picture stays held until IRAP",
        )
    }

    @Test
    fun fallbackWatchdogRequestsOneDecoderRepairThenRejoinsAtDeadline() {
        val state = LiveViewEnablePolicy.State()
        val now = 100_000L
        val snap = decoderSilentSnap(now)
        assertEquals(LiveViewEnablePolicy.Action.REBUILD_DECODER, LiveViewEnablePolicy.tick(state, snap))
        assertEquals(
            LiveViewEnablePolicy.Action.NONE,
            LiveViewEnablePolicy.tick(state, decoderSilentSnap(now + 1_000)),
        )
        assertEquals(
            LiveViewEnablePolicy.Action.NONE,
            LiveViewEnablePolicy.tick(state, decoderSilentSnap(now + 15_000)),
        )
        assertEquals(
            LiveViewEnablePolicy.Action.FULL_REJOIN,
            LiveViewEnablePolicy.tick(state, decoderSilentSnap(now + 16_000)),
        )
    }

    @Test
    fun fallbackWatchdogDoesNotPliForRendererStallWhenNativeOutputIsFresh() {
        val state = LiveViewEnablePolicy.State()
        val now = 100_000L
        val snap =
            decoderSilentSnap(now).copy(
                lastDecoderOutputAt = now,
                lastPresentedAt = now - 20_000,
            )
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, snap))
        assertEquals(LiveViewEnablePolicy.Stage.IDLE, state.stage)
    }

    @Test
    fun fallbackWatchdogDoesNotInventDecoderRepairWithoutNativeOutputClock() {
        val state = LiveViewEnablePolicy.State()
        val snap = decoderSilentSnap(100_000L).copy(decoderOutputExpected = false, lastDecoderOutputAt = null)
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, snap))
        assertEquals(LiveViewEnablePolicy.Stage.IDLE, state.stage)
    }

    @Test
    fun blockedRepairReadyDoesNotSpendADecoderRung() {
        val state = LiveViewEnablePolicy.State()
        val snap = decoderSilentSnap(100_000L).copy(repairReady = false)
        assertEquals(LiveViewEnablePolicy.Action.NONE, LiveViewEnablePolicy.tick(state, snap))
        assertEquals(LiveViewEnablePolicy.Stage.IDLE, state.stage)
        val ready = decoderSilentSnap(100_000L)
        assertEquals(LiveViewEnablePolicy.Action.REBUILD_DECODER, LiveViewEnablePolicy.tick(state, ready))
    }

    @Test
    fun unknownAccessUnitAgeDoesNotTreatRendererStallAsAssemblyStall() {
        val state = LiveViewEnablePolicy.State()
        val now = 100_000L
        val snap =
            decoderSilentSnap(now).copy(
                decoderOutputExpected = false,
                lastDecoderOutputAt = null,
                lastAccessUnitAt = null,
                lastPresentedAt = now - 3_000,
                lastVideoPacketAt = now,
            )
        assertEquals(
            LiveViewEnablePolicy.Action.NONE,
            LiveViewEnablePolicy.tick(state, snap),
            "nil AU age must not PLI a renderer-only stall",
        )
        assertEquals(LiveViewEnablePolicy.Stage.IDLE, state.stage)
    }

    @Test
    fun packetOnlyAssemblyStallUsesEnableLadderNotDecoderRebuild() {
        val state = LiveViewEnablePolicy.State()
        val now = 100_000L
        val snap =
            decoderSilentSnap(now).copy(
                decoderOutputExpected = false,
                lastDecoderOutputAt = null,
                lastAccessUnitAt = now - 3_000,
                lastPresentedAt = now - 3_000,
                lastVideoPacketAt = now,
            )
        assertEquals(LiveViewEnablePolicy.Action.RESEND_ENABLE, LiveViewEnablePolicy.tick(state, snap))
        assertEquals(
            LiveViewEnablePolicy.Action.NONE,
            LiveViewEnablePolicy.tick(state, snap.copy(now = now + 1_000, lastVideoPacketAt = now + 1_000)),
        )
        assertEquals(
            LiveViewEnablePolicy.Action.REBUILD_UDP,
            LiveViewEnablePolicy.tick(
                state,
                snap.copy(
                    now = now + 5_000,
                    lastVideoPacketAt = now + 5_000,
                    lastStatusAt = now + 5_000,
                    lastBleNotifyAt = now + 5_000,
                ),
            ),
        )
    }

    @Test
    fun blockedEnableDoesNotKeepASpentWatchdogRung() {
        val state = LiveViewEnablePolicy.State()
        val now = 20_000L
        val snap =
            stalledSnap(
                now = now,
                lastEnableAt = now - 10_000,
                lastVideoAt = now - 8_000,
                lastStatusAt = now - 200,
                lastBleAt = now - 100,
                lastRebuildAt = now - 70_000,
            )
        val before = state.capture()
        assertEquals(LiveViewEnablePolicy.Action.RESEND_ENABLE, LiveViewEnablePolicy.tick(state, snap))
        assertEquals(LiveViewEnablePolicy.Stage.RESEND_ENABLE, state.stage)
        state.restore(before)
        assertEquals(LiveViewEnablePolicy.Stage.IDLE, state.stage)
        assertEquals(0, state.encoderPauseEnables)
        assertEquals(LiveViewEnablePolicy.Action.RESEND_ENABLE, LiveViewEnablePolicy.tick(state, snap))
    }

    @Test
    fun fallbackUdpRebuildEscalatesToFullRejoin() {
        val state = LiveViewEnablePolicy.State()
        val now = 20_000L
        val snap =
            stalledSnap(
                now = now,
                lastEnableAt = now - 10_000,
                lastVideoAt = now - 8_000,
                lastStatusAt = now - 200,
                lastBleAt = now - 100,
                lastRebuildAt = now - 70_000,
            )
        assertEquals(LiveViewEnablePolicy.Action.RESEND_ENABLE, LiveViewEnablePolicy.tick(state, snap))
        val second =
            snap.copy(
                now = now + 5_000,
                lastEnableAt = now,
                lastStatusAt = now + 5_000 - 200,
                lastBleNotifyAt = now + 5_000 - 100,
            )
        assertEquals(LiveViewEnablePolicy.Action.REBUILD_UDP, LiveViewEnablePolicy.tick(state, second))
        val rejoin =
            snap.copy(
                now = now + 10_000,
                lastEnableAt = now,
                lastStatusAt = now + 10_000 - 200,
                lastBleNotifyAt = now + 10_000 - 100,
            )
        assertEquals(LiveViewEnablePolicy.Action.FULL_REJOIN, LiveViewEnablePolicy.tick(state, rejoin))
    }

    companion object {
        private fun stalledSnap(
            now: Long,
            lastEnableAt: Long,
            lastVideoAt: Long?,
            lastStatusAt: Long?,
            lastBleAt: Long?,
            lastRebuildAt: Long?,
            lastGimbalThrowAt: Long? = null,
        ): LiveViewEnablePolicy.Snapshot =
            LiveViewEnablePolicy.Snapshot(
                now = now,
                videoPackets = 40,
                lastVideoPacketAt = lastVideoAt,
                lastAccessUnitAt = lastVideoAt,
                lastStatusAt = lastStatusAt,
                lastBleNotifyAt = lastBleAt,
                lastRebuildAt = lastRebuildAt,
                lastEnableAt = lastEnableAt,
                pathReady = true,
                hasFormat = true,
                decoderErrors = 0,
                live = true,
                sawPicture = true,
                lastGimbalThrowAt = lastGimbalThrowAt,
            )

        private fun decoderSilentSnap(now: Long): LiveViewEnablePolicy.Snapshot =
            LiveViewEnablePolicy.Snapshot(
                now = now,
                videoPackets = 40,
                lastVideoPacketAt = now,
                lastAccessUnitAt = now,
                lastStatusAt = now,
                lastBleNotifyAt = now,
                lastRebuildAt = now - 70_000,
                lastEnableAt = now - 10_000,
                pathReady = true,
                hasFormat = true,
                decoderErrors = 0,
                live = true,
                sawPicture = true,
                lastDecoderOutputAt = now - 3_000,
                lastPresentedAt = now - 3_000,
                decoderOutputExpected = true,
                repairReady = true,
            )
    }
}
